import { AcPage } from './app.po';

describe('ac App', () => {
  let page: AcPage;

  beforeEach(() => {
    page = new AcPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
