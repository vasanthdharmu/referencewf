import { Component } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { TranslateService, LangChangeEvent, DefaultLangChangeEvent } from 'ng2-translate';

import { LoggerService } from 'app/shared/logger.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.template.html',
  styleUrls: ['./app.style.css']
})
export class AppComponent {

  public showmenu:any;

  constructor(public translate: TranslateService, public logger: LoggerService) {
    
    translate.addLangs(["en"]);
    translate.setDefaultLang('en');

  }

  ngOnInit() {
    
    let params = new URLSearchParams(window.location.search);
    this.showmenu = params.get('?showmenu');

  }
    
}