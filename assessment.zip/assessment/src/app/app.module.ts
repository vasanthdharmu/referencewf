import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, isDevMode } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Http, HttpModule, JsonpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { environment }    from 'environments/environment';
import { TranslateLoader, TranslateStaticLoader, TranslateModule } from "ng2-translate";

import { AppRoutingModule } from './app.routing.module';

import { AppService } from './shared/app.service';

import { AuiModule } from 'aui/components/aui.module';
import { SharedModule } from './shared/shared.module';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';

export function translateLoader(http: Http) {
	return new TranslateStaticLoader(http, './assets/i18n', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
		DashboardComponent,
		HeaderComponent,
		SidebarComponent,
		FooterComponent
  ],
  imports: [
		BrowserModule,
		BrowserAnimationsModule,
		FormsModule,
		ReactiveFormsModule,
		HttpModule,
		HttpClientModule,
		JsonpModule,
		AppRoutingModule,
		AuiModule,
		SharedModule.forRoot(),
		TranslateModule.forRoot({
			provide: TranslateLoader,
			useFactory: translateLoader,
			deps: [Http]
		}),
  ],
  providers: [
		AppService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {

 }
