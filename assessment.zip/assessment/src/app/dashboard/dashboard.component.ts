import { Component } from '@angular/core';

@Component({
  selector: 'ac-dashboard',
  templateUrl: './dashboard.template.html',
  styleUrls: [ './dashboard.style.css' ]
})
export class DashboardComponent {
}
