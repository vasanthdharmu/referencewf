import { Component } from '@angular/core';

@Component({
  selector: 'ac-footer',
  templateUrl: './footer.template.html',
  styleUrls: ['./footer.style.css']
})
export class FooterComponent {

}