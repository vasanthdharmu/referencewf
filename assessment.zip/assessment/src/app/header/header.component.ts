import { Component } from '@angular/core';

@Component({
  selector: 'ac-header',
  templateUrl: './header.template.html',
  styleUrls: ['./header.style.css']
})
export class HeaderComponent {

}
