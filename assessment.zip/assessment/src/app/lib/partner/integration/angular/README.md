SmartBridge Angular Adapter
---------------------------


This exposed library is for consuming teams to place within their Angular (recommend version 4 or higher) applications.


Acquiring library
-----------------

extract the source directly from Smart Connection from the `lib` folder. In the custom application's source, place the real source code within a folder structure `partner/integration/angular` which mirrors that of the the original source tree.



Linking
-------

The reference Angular 4 demo is stored in SmartConnection source at `app/typescripts/services/partner/integration/test/angular`


Development
-----------

Using the demo's `app.module.ts` main module, the following startup code will satisfy registration with the host SmartService bridge.

Example:

From within custom application:

Typically the initial modules can be ingested via code that resembles the following. This assumes a library `lib` folder
```Typescript
import {
    generateClientBridgeDelegateService,
    generateSmartServicesInjectorFactory
} from "./lib/partner/integration/angular/ng-bootstrap-smartservices";
```

```Typescript
import { SmartBridgeDelegateResponder, SmartBridgeDelegateService } from "./lib/partner/integration/angular/smartbridge-delegate";
```


Example
-------

How to bind a simple event from SmartConnection. In this trivial case, the user wants to click on the refresh icon and have customize action intercept and deal with that mouse click event.


```
        this.delegate.clientBridge.registerRefreshService( () => {
        // run custom behavior when the refresh button is clicked in the header bar surrounding the custom content.
            console.log("refresh handler flow..." );
        });
```
