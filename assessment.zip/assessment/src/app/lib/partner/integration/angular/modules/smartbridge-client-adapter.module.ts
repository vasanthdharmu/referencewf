import { NgModule, ModuleWithProviders, InjectionToken } from '@angular/core';
import { SmartBridgeDelegateResponder, SmartBridgeDelegateService } from "../services/smartbridge-delegate";
import {
    generateClientBridgeDelegateService,
    generateSmartServicesInjectorFactory
} from "../services/ng-bootstrap-smartservices";


export const GENERATE_SMART_SERVICES_INJECTOR_TOKEN = new InjectionToken('SmartServicesInjector');
export const GENERATE_CLIENT_BRIDGE_DELEGATE_SERVICE_TOKEN = new InjectionToken('SmartServicesClientBridgeDelegate');

export function _smartreportGenerateSmartServicesInjectorFactory(): any {
    return {
        provide: GENERATE_SMART_SERVICES_INJECTOR_TOKEN,
        useFactory: generateSmartServicesInjectorFactory
    }
}

export function _smartreportGenerateClientBridgeDelegateService(): any {
    return {
        provide: GENERATE_CLIENT_BRIDGE_DELEGATE_SERVICE_TOKEN,
        useFactory: generateClientBridgeDelegateService,
        deps: [GENERATE_SMART_SERVICES_INJECTOR_TOKEN]
    }
}

@NgModule({
    declarations: [
        // Pipes.
        // Directives.
    ],
    exports: [
        // Pipes.
        // Directives.
    ]
})
export class SmartbridgeClientAdapterModule {

    /**
     * Use in AppModule:
     */
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SmartbridgeClientAdapterModule,
            providers: [

               _smartreportGenerateSmartServicesInjectorFactory() as any,
               _smartreportGenerateClientBridgeDelegateService() as any,

                SmartBridgeDelegateResponder, SmartBridgeDelegateService
            ]
        };
    }

    /**
     * Use in features modules with lazy loading:
     */
    public static forChild(): ModuleWithProviders {
        return {
            ngModule: SmartbridgeClientAdapterModule,
            providers: [

                _smartreportGenerateSmartServicesInjectorFactory() as any,
                _smartreportGenerateClientBridgeDelegateService() as any,

                SmartBridgeDelegateResponder, SmartBridgeDelegateService
            ]

        };
    }

}
