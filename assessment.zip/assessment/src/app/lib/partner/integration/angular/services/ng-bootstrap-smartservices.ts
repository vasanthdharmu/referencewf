/**
 * the bootstrapping serves as a foundation for helping nested custom pages written in Angular 2/4 ( not AngularJS) to connect and register
 */
export function bootstrapSmartServices(): void {
    normalizeDomain();
}

// todo: maintenance update the list of supported Roles
// =========== resources =================
export enum UiRoleType {
    SmartTab,
    SmartReport
}

const viewPropertyMappingByUiRoleType: Map<UiRoleType, string> = new Map();
viewPropertyMappingByUiRoleType.set(UiRoleType.SmartTab, "smarttab");
viewPropertyMappingByUiRoleType.set(UiRoleType.SmartReport, "smartreport");

const supportedViewPropertyList: Array<string> = [];
viewPropertyMappingByUiRoleType.forEach((value, key) => {
    supportedViewPropertyList.push(value);
});
// /=========== resources =================


// discovers SmartServices component window which is denoted by an endorsed UI Role
export function interrogateEncompassingUiRoleContext(w: Window, UiRoleType: UiRoleType): Window | undefined {
    do {
        try {
            // role discovery
            const scannedUiRole = w.document.documentElement.dataset["uiRole"];
            if (scannedUiRole) {
                if (supportedViewPropertyList.indexOf(scannedUiRole) > -1) {
                    return w;
                }
            }

        } catch (e) {
            return;
        }
    } while (( w !== w.parent ) && (w = w.parent));

    return;
}


// discovers SmartServices host that powers the Bridge core services
export function interrogateFactoryContext(w: Window): Window {
    do {
        try {
            // role discovery
            if (["root"].indexOf(w.document.documentElement.dataset["ssueRole"]!) >= 0) {
                return w;
            }
        } catch (e) {
            // bridge forbidden
            return w;
        }
    } while (( w !== w.parent ) && (w = w.parent));

    return w;
}

// reveals real window that initiated or invoked the custom app, with the understanding that a custom page may be loaded via proxy or custom viewport (modal)
export function interrogateInvokerContext(w: Window): Window {
    do {
        try {

            // fall back to root unless contained by other client bridge
            if (["proxy", "root"].indexOf(w.document.documentElement.dataset["ssueRole"]!) >= 0) return w;

            // invoker case, detect true originator not in source-ordered frame hierarchy
            if (["modal"].indexOf((w.frameElement as HTMLFrameElement).dataset["uiRole"]!) >= 0) {
                const invokerBridge = (w.frameElement.ownerDocument.defaultView as any).ssue.partner.integration.client.findDelegate((w.frameElement as HTMLFrameElement).dataset["transientContextIdentifier"]!);
                // inside a SC-triggered viewport - however "owned" by a delegate
                if (invokerBridge) return invokerBridge.getSubscriberWindow();
            }

        } catch (e) {
            // bridge forbidden
            return w;
        }
    } while (( w !== w.parent ) && (w = w.parent));

    return w;
}


// +++++++++++ exported ++++++++++++++++++++

// functional style
export function generateSmartServicesInjectorFactory(): angular.auto.IInjectorService | undefined {

    const scBeaconWindow = interrogateFactoryContext(window);
    const noopInjector = {
        get(): any {
            return null
        }
    } as any;

    if (scBeaconWindow) {
        const ngRef: angular.IAngularStatic = (<any> scBeaconWindow)["angular"];

        if (ngRef) {
            const appBootstrapElem = ngRef.element(scBeaconWindow.document.body);
            return appBootstrapElem
                ? appBootstrapElem.injector() // bootstrap location
                : noopInjector;

        } else {
            return noopInjector
        }
    } else {
        return;
    }
}

// must be functional expression. factory stored in SmartServices core integration-client.module
export function generateClientBridgeDelegateService(injector: angular.auto.IInjectorService): any {
    return injector.get("SmartConnectionPartnerIntegrationClientBridgeDelegateService");
}


// ----------------------------
function normalizeDomain(): void {
    // policy for opening cross frame communication
    let _spExp, _spTok = ".";
    document.domain = ((_spExp = document.domain!.split(_spTok)) && _spExp!.length === 1
        ? _spExp.pop()! :
        [_spExp.pop(), _spExp.pop()].reverse().join(_spTok));
}

