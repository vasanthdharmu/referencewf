/**
 * the smart bridge delegate serves as a foundation for helping nested custom pages written in Angular 2/4 ( not AngularJS) to connect and register
 */
import { forwardRef, Inject, Injectable } from "@angular/core";
import { GENERATE_CLIENT_BRIDGE_DELEGATE_SERVICE_TOKEN } from "../modules/smartbridge-client-adapter.module";

// custom app must supply an emitter when establishing connect
export interface SmartBridgeDelegateResponseEmittable {
    // custom app pipe message to SmartServices core
    emit(data: any, result: boolean): void;
}


@Injectable()
export class SmartBridgeDelegateResponder implements SmartBridgeDelegateResponseEmittable {

    constructor() {
    }

    // pipe message to SmartServices core
    emit(data: any, resultFlag: boolean): void {

        /*
            var sc = this._virtualClientBridge.getServerWindow();
           data.result = resultFlag;
           return sc.postMessage(data, sc.location.origin);
           */
    }

}

/**
 * throws Exception when Bridge is not discovered
 */
@Injectable()
export class SmartBridgeDelegateService {

    public isValid: boolean = false; // ready to accept connect command by business layer
    public clientBridge: RegisteredClientBridgeCommand; // service can yield a single connected bridge

    constructor(@Inject(forwardRef(() => GENERATE_CLIENT_BRIDGE_DELEGATE_SERVICE_TOKEN)) public _clientBridgeDelegate: ClientBridgeDelegateService,
                public responseTunnel: SmartBridgeDelegateResponder) {

        // SC bridge detection        
        if (this._clientBridgeDelegate) {

            const detachedVirtualClientBridge = this._clientBridgeDelegate.connect(1, window, this.responseTunnel);

            if (detachedVirtualClientBridge) {
                this.isValid = true;
                this.clientBridge = detachedVirtualClientBridge.register();
                console.log("detachedVirtualClientBridge register success");
            } else {
                console.error('Cannot establish connection point', detachedVirtualClientBridge);
            }

        } else {
            console.log("SmartBridge unavailable within the browser constructed view");
            // SmartBridge unavailable within the browser constructed view
        }

    }

}


// ~~~~~~~~~~~ inlined interfaces, can't easily make imports work ~~~~~~~~~~~~~~~~~~~~~~~
// --- excerpts from AngularJS class stubs and interfaces from partner/integration ------

// ------- interface stubs from SmartConnection AngularJS code ----------
export interface ClientBridgeDelegateService {
    // Angular custom app will invoke a connect command to wire up and establish a virtual bridge
    connect(version: number, subscriberWindow: Window, emitter: SmartBridgeDelegateResponseEmittable): IVirtualClientBridge;
}


export interface IChannelSubscribable {
    getSubscriberWindow(): Window;

    setSubscriberWindow(win: Window): void;
}

export interface IPartnerCommandable {
    getCommand(): any;
}

export interface IVirtualClientBridge extends IChannelSubscribable, IPartnerCommandable {
    register(): RegisteredClientBridgeCommand;

    unregister(): boolean;

    setProxy(proxy: IVirtualProxyBridge): void; // bind to proxy
    getProxy(): IVirtualProxyBridge;

    setMessageDispatcher(messageDispatcher: IMessageDispatcher): void;

    getServerWindow(): Window;

    // exposed command for partners
    getCommand(): RegisteredClientBridgeCommand;

}


export interface IMessageDispatcher {
    (data: any, resultFlag: boolean): any;
}

// marker only function
export interface IResponderBaseEvent extends Function {

}

// partner custom defined handler
export interface IResponderPartnerHandlerEndpoint extends IResponderBaseEvent {
    (data: any, resultFlag: boolean): void;
}

// tightly enclosed as part of the eventing subsystem
export interface IResponderInvokedCallback extends IResponderBaseEvent {
    (response: any, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;
}

// exposed as on the subscriber side
export interface IRespond {
    respond: IResponderPartnerHandlerEndpoint;
}

export interface IEventedLambda {
    (event: MessageEvent): void;
}


// conceptual layer for messaging
export abstract class MessageRelayRunnerBase implements IRespond {


    // @@@@@@@@@@ accessors @@@@@@@@@@@@@@@@@@
    abstract setSubscriberWindow(win: Window): void;

    abstract getSubscriberWindow(): Window;

    abstract findManagedViewportWindow(identifier: string): Window | null;

    abstract setMessageDispatcher(messageDispatcher: IMessageDispatcher): void;

    abstract getTopicAttribute(): string;

    // inform Amadeus, using the client's own post
    // required: client's own dispatch routine is required for event sourcing
    abstract respond(data: any, resultFlag: boolean): void;

    // abstractions
    abstract getManagerWindow(): Window

    abstract listening(topic: string, boundHandler: IResponderInvokedCallback, shouldDestroyListenerAfterwardsFlag?: boolean): IEventedLambda;

}

//-----------------------------

// generalization
export interface IListenerMessageProcessor {
    onReceive(topic: string, cb: IResponderInvokedCallback, evt: MessageEvent): void;
}


export abstract class MessageProcessorBase {
    // util - bindable, deserialized structure
    abstract isNativeObject(x: any): boolean;

    // general unwrap, analyzes both structured or serialized; deals with parameterless messages
    abstract unwrapMessageEventData(evt: MessageEvent): any | undefined;
}


//-----------------------------

// generalization
export interface IListenerMessageProcessor {
    onReceive(topic: string, cb: IResponderInvokedCallback, evt: MessageEvent): void;
}

export interface IServiceProvisionable {
    isProvisioningValid(): boolean;

    setProvisioningValid(b: boolean): void;

    provision(): void;
}


export interface ManagedConfigurationResourceMetadataSchema {
    transientContextIdentifier: string; // caller or instance of bridge ID
    transientViewportContainerIdentifier: string | null; // physical identity of the (custom) viewport containing the bridge, if at all contained
}


// when starting a modal, certain decorative behaviors can be switched on . These are the general preferences
export interface IModalViewportCapabilities {
    isNavigationObserved?: boolean;
    isContentCompiled?: boolean; // Angular needs to treat the string bindings to evaluate expressions. beneficial for prompt
    isCloseable?: boolean; // is the X icon shown
    isDraggable?: boolean; // can modal be moved about
    isResizable?: boolean; // can modal size change
}

// powerhorse
export interface RegisteredClientBridgeCommand extends MessageRelayRunnerBase, IServiceProvisionable {

    getVirtualClientBridge(): IVirtualClientBridge;

    listening(topic: string, boundHandler: IResponderInvokedCallback, shouldDestroyListenerAfterwardsFlag?: boolean): IEventedLambda;


    isProvisioningValid(): boolean;

    setProvisioningValid(b: boolean): void;

    // set up standard process for clients
    provision(): void;


    // create a new history entry and simultaneous loads that corresponding URL
    addNavigationURL(title: string, subtitle: string, info: any, url: string): any;


    // deliver broadcast record to registered peers
    broadcastMessage(topic: string, data: any): void;

    // start accepting broadcasts
    registerBroadcastMessageEvent(topic: string, onReceiveEvent: IResponderInvokedCallback): void;

    // stop accepting broadcasts
    unregisterBroadcastMessageEvent(topic: string): void;

    // read access into the configuration state
    getManagedConfigurationResource(): ManagedConfigurationResourceMetadataSchema;


    transformToAbsoluteURL(relativeURL: string): string;


    // direct client message push via SC engine
    onBroadcastMessageReceivedEvent(ssueMessage: string, wrappedMessageContent: any): void;


    openModalDialog(identifier: string, title: string, subtitle: string | null,
                    widthDimension: number, widthUnitType: string,
                    heightDimension: number, heightUnitType: string,
                    url: string, postData: object | null, capabilitiesMap?: IModalViewportCapabilities): IOpenedModalInstance;


    closeModalDialog(identifier: string, isOpenerRefreshedFlag?: boolean): void;


    /**
     * an interactive prompt that allows confirmation, with widget decorations
     *
     * @param identifier - known key that helps when dealing with subsequent modal interactions
     * @param title - primary text in the titlebar
     * @param subtitle - optional footer at the bottom of the prompt
     * @param contentHTML - message shown inside prompt
     * @param widthDimension - width of the modal
     * @param widthUnitType - unitTypes may be px, %, or vw/vh (preferred)
     * @param heightDimension - height of the modal
     * @param heightUnitType - unitTypes may be px, %, or vw/vh (preferred)
     * @param {boolean} isAcknowledgeable
     * @param {boolean} isCancelable
     * @param {smartconnection.controller.IModalViewportCapabilities} capabilitiesMap
     * @returns {smartconnection.controller.IOpenedModalInstance}
     */
    openModalPrompt(identifier: string, title: string, subtitle: string | null,
                    contentHTML: string,
                    widthDimension: number, widthUnitType: string,
                    heightDimension: number, heightUnitType: string,
                    isAcknowledgeable: boolean,
                    isCancelable: boolean,
                    capabilitiesMap?: IModalViewportCapabilities): IOpenedModalInstance;

    registerModalPromptEvents(identifier: string, onOpenEvent: Function, onAcknowledgeEvent: Function, onCancelEvent: Function, onCloseEvent: Function): void;

    registerModalDialogEvents(identifier: string, onOpenEvent: Function, onRegisterEvent: Function, onLoadEvent: Function, onCloseEvent: Function): void;

    /* locate an opened modal, if it exists by general identifier ( instance or business assigned ID ) */

    /**
     * lookup a modal dialog or modal prompt entity
     * @param {string} identifier
     * @param {boolean} isFilteredByDialogType - chooses which collection to pull up. defaults to searching for a modal dialog, else prompt modals
     * @returns {smartconnection.controller.IOpenedModalConcept}
     */
    findOpenedModalInstance(identifier: string, isFilteredByDialogType?: boolean): IOpenedModalInstance | null;

    // adapting the help registration
    registerHelpService(helpServiceURL: string, helpServiceTooltip: string, serviceInvocationHandler: IResponderInvokedCallback): void;

    // abandon help altogether for client
    unregisterHelpService(): void;


    // accommodating a refresh
    registerRefreshService(serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterRefreshService(): void;


    //  filters
    registerFiltersChangedEvent(serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterFiltersChangedEvent(): void;


    //  locale update
    registerLocaleChangedEvent(serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterLocaleChangedEvent(): void;


    //  SSUE payload generic message transport layer
    registerSsuePayloadEvent(serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterSsuePayloadEvent(): void;

    // registration to show alert message
    registerGenerateAlertMessageService(alertMesageData: any, serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterGenerateAlertMessageService(): void;

    registerAlertMessageService(serviceInvocationHandler: IResponderInvokedCallback): void;

    generateAlertMessageService(alertMesageData: any);

    //register to clear global message
    registerClearAllAlertMessageService(serviceInvocationHandler: IResponderInvokedCallback): void;

    unregisterClearAllAlertMessageService(): void;
}


export interface IMessageDispatcher {
    (data: any, resultFlag: boolean): any;
}


// handles registration of special proxy listener within the client

export interface IVirtualProxyBridge {

    register(hostBridge: any): any;

    //setSubscriberWindow(win: Window): void;
    getServerWindow(): Window;

    // set accessors
    addConnector(connector: IProxySourceConnector): boolean;

    removeConnector(connector: IProxySourceConnector): boolean;

    unobserveConnector(connector: IProxySourceConnector): boolean;

    getConnectorsList(): Array<IProxySourceConnector>;

    getConnectorByWindow(win: Window): IProxySourceConnector | null;

    getClientBridgeCommand(): any;

    // partner support
    getCommand(): any;

    // foundry
    mapFactory<K extends object, V>(): WeakMap<K, V>;

    destroy(): void;

}

export interface INavigationTransitionContentSchema {
    contentTitle: string;
    contentUrl: string;

//    _resolvedUrl: string; // pre-processed URL - the contentUrl must be evaluated constantly
    contentSubtitle?: string;
    contentInfo?: any; // ancillary context
}


export interface INavigationMessageSchema {
    title: string;
    url: string;
    subtitle?: string;
    info?: any; // ancillary context
}

export interface ISsueContextFactory {

    setService (data: any): void;

    setCategory (data: any): void;

    setFilters (data: any): void;

    getFilterLabels(): Array<string>;

    setFilterLabels (data: any): void;

    setQueryString (data: any): void;

    applyQueryString (data: any): void;

    // template
    substitute (data: any): string;

    /* handles filterContext, ssueContext ( DEPRECATE ), personalizationRestPath, timestamp */
    apply (url: string): string;

    //json serialized
    //filter context to have service and category
    get (): string;

    //json serialized
    getValues (): string;

    getFilterValues (): string;

    updateContextValueCookie (): any;

    //json serialized
    getOld (): string;

    updateCookie (): void;

    dump (): void;

}

export abstract class SmartreportNavigatorTransitionAction {

    // transition model modifiers
    abstract addTransitionContent(o: INavigationTransitionContentSchema): void;

    abstract popTransitionContent(): INavigationTransitionContentSchema | null;

    abstract getTransitionContentsStack(): Array<INavigationTransitionContentSchema>;

    // looks like syntaxes differ by names, remap to different object
    abstract createTransitionContentFactory(o: INavigationMessageSchema): INavigationTransitionContentSchema;

}

// =========== declaration.d.ts ===================

// encapsulation for business context spec that brower -> server -> server .. communication uses
export interface FilterContextSchema {
    service: string;
    inventory?: Array<string>;
    segment?: Array<string>;
    partner?: Array<string>;
    customer?: Array<string>;
}


export interface ILocale {
    language: string;
    timezone: {
        abbreviation: string;
        baseOffsetMinutes: number;
        code: string;
        country: string;
        countryName: string;
        label: string;
    }
}

// messages bound for SC should start to have an envelope
export interface ISmartconnectionMessageEnvelope {
    caller: string; // trace
    type: string; // entity classifier
    sent: number; // timestamp
    isResponsible: boolean;  // caller awaits for response to be sent
}


// when starting a modal, certain decorative behaviors can be switched on
export interface IModalViewportCapabilities {
    isNavigationObserved?: boolean;
    isContentCompiled?: boolean; // Angular needs to treat the string bindings to evaluate expressions. beneficial for prompt
    isCloseable?: boolean;
    isDraggable?: boolean;
    isResizable?: boolean;
}


export interface IModalContextScope extends ng.IScope {
    // notation for accessing a DOM-exposed modal
    modalContentTransientContextIdentifier: string;
    modalRequestIdentifier: string; // atomic instance - may differ from caller identifier

    modalContentHeight: string | null;
    modalContentWidth: string | null;

    modalContentTitle: string; // prominent title
    modalContentSubtitle?: string; // optional, unlikely to be used

    modalContentUrl?: string;
    modalContentPost?: object | null;

    isAcknowledgeable: boolean; // optional flag that if false, can hide the OK button
    isCancelable: boolean; // optional flag that if false, can hide the cancel button

    capabilities: IModalViewportCapabilities; // property map of configurable behaviors

    // DOM layouts
    postFormLayoutId: string; // DOM pointer to FORM used when POSTING heavy data
    frameLayoutId: string; // DOM pointer to IFRAME triggering custom page

    // decorative text in the modal header, needs to activate to change
    isViewContentNavigationControllerVisible: boolean; // history selector widget shown
    viewContentCurrentNavigationTitle: string; // pulled from custom app's current title
    viewContentCurrentNavigationSubtitle: string | null; // pulled from custom app's optional subtitle
}


// AngularJS UI Bootstrap https://github.com/angular-ui/bootstrap
export interface IModalInstanceService {
    /**
     * A promise that is resolved when a modal is closed and rejected when a modal is dismissed.
     */
    result: ng.IPromise<any>;

    /**
     * A promise that is resolved when a modal gets opened after downloading content's template and resolving all variables.
     */
    opened: ng.IPromise<any>;

    /**
     * A promise that is resolved when a modal is rendered.
     */
    rendered: ng.IPromise<any>;

    /**
     * A promise that is resolved when a modal is closed and the animation completes.
     */
    closed: ng.IPromise<any>;

    /**
     * A method that can be used to close a modal, passing a result. If `preventDefault` is called on the `modal.closing` event then the modal will remain open.
     */
    close(result?: any): void;

    /**
     * A method that can be used to dismiss a modal, passing a reason. If `preventDefault` is called on the `modal.closing` event then the modal will remain open.
     */
    dismiss(reason?: any): void;

}

// SSUE decorates the unique handle of a modal instance from UI Bootstrap with some business specifics
export interface IOpenedModalInstance extends IModalInstanceService {
    scope: IModalContextScope; // the template-bound scope for the modal that was instantiated
    identifier: string; // business defined tag
    contentWindow: Window | null; // a modal if it is a dialog, likely will contain an embedded document from the server
    isCrossDomain: boolean; // is embedded page able to participate in CORS smoothly
}


export interface IOpenedModalConcept {
    // object associations
    reference: {
        modal: IOpenedModalInstance;
        source: Window; // same as below
    },
    // serializable
    state: {
        id: string;
        instance: string;
        created: number;
        source: Window;
        envelope?: ISmartconnectionMessageEnvelope;
    }
}


// Modal responds with a format
export interface IModalMessageResponseSchema {
    id: string;
    instance: string; // DOM instance
    recipient: string;
    reply: string;
    envelope?: ISmartconnectionMessageEnvelope;
}

// really a class
export interface ClientBridgeFactory {
    findInstance(w: Window): IVirtualClientBridge | null;

    getInstance(): IVirtualClientBridge;
}


// shape of the record compatible with the DK Queue Collection API
export interface ItemDualKeyable {
    state: {
        id: string;
        instance: string;
    }
}

export interface DualKeyQueueCollectionInstance<T extends ItemDualKeyable> {

    peek(): T | null;

    // unique check
    existsKey(key: string): boolean;

    enqueue(ticket: T): void;

    // extract item by ticket granted
    dequeue(ticket: T): void

    // store member search by property

    // by business defined constant
    findById(identifier: string): T | null;

    // by generated DOM ID
    findByInstance(identifier: string): T | null;

    // since a dialog can be instantiated by the bridge or dynamically through smartreports
    // it is possible to be supplied two varying sets of keys
    // might be instance of the DOM identifier that uniquely identifies a modal
    // or a business defined constant. neither is an error per se, just dual key entry mechanism
    find(key: string): T | null;
}


export interface ISmartconnectionRootScope extends ng.IRootScopeService {
    locale: ILocale;


    // retain top level content wrappers in the dashboard or single dashlet
    subscribers: Array<ISmartconnectionContentContainerScope>;


    modalCallersQueue: Array<IOpenedModalConcept>;
    promptCallersQueue: Array<IOpenedModalConcept>;

    getClientBridgeFactory(version: number): ClientBridgeFactory;

    queueOpenModalInstanceFactory(collection: Array<IOpenedModalConcept>): DualKeyQueueCollectionInstance<IOpenedModalConcept>;
}


export interface ISmartconnectionMainScope extends ng.IScope {
    $root: ISmartconnectionRootScope;
}

// content area's created scope
export interface ISmartconnectionContentContainerScope extends ng.IScope {

    containerData: Object;
    content: HTMLIFrameElement;
    contentCount: number;
    contentId: string;
    contentSubtitle: string;
    contentTitle: string;
    hasBack: boolean;
    hasClose: boolean;
    hasFilter: boolean;
    hasMax: boolean;
    hasMin: boolean;
    hasRefresh: boolean;
    hasRestore: boolean;
    hasSubscriberControlMenuLayout: boolean; // <<- deprecate please!!
    hasTitle: boolean;
    helpIcon: boolean; // poorly named flag. WHY
    helpTooltip: any; // unsure
    helpUrl: string;
    historyOpen: boolean;
    historyStack: Array<any>; // stores history
    iframeLoader: any;
    isLoading: boolean;
    isMax: boolean;
    isMin: boolean;
    isSubscriberHelpServiceActivated: boolean;
    loadingMessage: string;


    adjustHeight(data: any): void;

    back(): void;

    closeContent(): void;

    closeHistory(): void;

    createElement (fragment: any, owner: any): void;

    createFlash (url: string, owner: any): void;

    createIframe (url: string, owner: any): void;

    createImage (url: string, owner: any): void;

    createInclude (url: string, owner: any): void;

    createModule (url: string, fragment: any, owner: any): void;

    createTitlelessIframe (url: string, owner: any): void;

    createVideo (url: string, owner: any): void;

    formatHelpTooltip (url: string, fragment: any, owner: any): string;

    isSubscriberRoleSmartreport(w: Window): boolean;

    loadContainer(data: any, owner: any): void;

    maximizeContent(): void;

    minimizeContent(): void;

    nav(title: string, url: string): void;

    navContent(amt: any, type: any): void;

    openHistory(): void; // toggle open the history dropdown
    prepIframeLoader(): void; // get loader
    refreshContent(targetdRefreshableWindow: Window): void; //refresh
    reloadURL(): void;

    requiresContext(url: string): boolean;

    restoreContent(): void;

    revertHeight(): void;

    setContentSource(url: string): void;

    setHelp(data: any): void;

    showFilter(): void; // ui view
    showHelp(): void; // ui view
    toggleHistory(): void; //open or hide dropdown

}


// =========== /declaration.d.ts ===================


export abstract class RegisteredProxyBridgeCommand extends MessageRelayRunnerBase implements IServiceProvisionable {

    // ------------ override -----------------
    // window belongs to proxy
    abstract getManagerWindow(): Window;

    abstract removeEventListener(topic: string): void;


    // messaging nexus point - impl
    abstract listening(topic: string, boundHandler: IResponderInvokedCallback, shouldDestroyListenerAfterwardsFlag?: boolean): IEventedLambda;


    // can the driver operate??
    abstract isProvisioningValid(): boolean;

    abstract setProvisioningValid(b: boolean): void;

    // act of provisioning
    abstract provision(): void;


    // manual DI
    // bind core state service from SC
    abstract getContextService(): ISsueContextFactory;

    abstract setContextService(factory: ISsueContextFactory): void;

    // manual DI
    abstract getRootScope(): ISmartconnectionRootScope;

    abstract setRootScope(scope: ISmartconnectionRootScope): void;


    // Note: funneled calls from *any* child smartreport connector
    // registration process
    abstract onSubscribeListener(response: any, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;

    // trigger :: partner registers a notification processor for a window
    // will need to unregister on transitions or not
    abstract registerConnectorSubscribedEvent(w: Window, serviceInvocationHandler: IResponderPartnerHandlerEndpoint): void;


    // -------------------- internal event ---------------------

    //yields pre-existing observer for the window, if present
    abstract getPriorTransitionObserver(win: Window): SmartreportNavigatorTransitionAction | null;


}


export interface IProxySourceConnector {

    identifier: string;

    getSubscriberWindow(): Window;

    setSubscriberWindow(win: Window): void;

//                        setProxy(command: RegisteredProxyBridgeCommand);
//                        getProxy(): RegisteredProxyBridgeCommand;

    setProxy(command: any): void;

    getProxy(): any;

    provision(): boolean;

    getCommand(): SmartreportConnectorBridgeCommand;

    // detach
    destroy(): void;

    // should type the service
    getContextService(): any;

}

export abstract class SmartreportSourceConnector implements IProxySourceConnector {

    public identifier: string;

    // accounting
    abstract getCreationDate(): Date;

    // ancestor
    abstract getAncestorTransitionObserver(): SmartreportNavigatorTransitionAction | null;

    abstract getContextService(): ISsueContextFactory;

    abstract getSubscriberWindow(): Window;

    abstract setSubscriberWindow(win: Window): void;

    abstract getProxy(): RegisteredProxyBridgeCommand;

    abstract setProxy(command: RegisteredProxyBridgeCommand): void;

    abstract provision(): boolean;

    // physical destruction requested : unwatch
    abstract destroy(): void;

    // partner interceptors build off the command
    abstract getCommand(): SmartreportConnectorBridgeCommand;


    // ----------------------

    abstract deriveSsueLocale(): ILocale;

    abstract deriveSsueEnvironment(): { personalizationRestPath: string, theme: string };

}


/**
 * envelope authenticity. used for describing sender needs
 */
export interface ISmartreportMessageEnvelope extends ISmartconnectionMessageEnvelope {

}


// offered mutation transformation
export type MutationEventType = "add" | "update" | "replace" | "delete";

// supported handlers for object types that offer mutation
export type MutationServiceType = "filter";

// each mutation service implementation should likely specialize
export interface MutationDispatcherContextBase {

}


export interface IHashContextFilterEntity {
    [ key: string]: IContextFilterEntity
}

// example
export interface FilterMutationDispatcherContext extends MutationDispatcherContextBase, IHashContextFilterEntity {

}

// -- imported from Smartreport Context
// filter concept in serialized form -- supplied via session or forced directed param
export interface IContextFilterEntity {
    // low level operator
    relop: "eq" | "ne" | "contains" | "starts_with" | "lt" | "lte" | "gt" | "gte" | "range" | "isnull" | "isnotnull";
    // fine grained, powerful operator that carries more detail
    operatorType?: string;
    // seemingly nullable domain filters are valueless
    value?: any | Array<any>;
    // used by range
    value2?: any | Array<any>;
    readOnly?: boolean;
}


// -- /imported from Smartreport Context


// structure of the dispatched structure for all mutation commands to Smartreport
export interface MutationDispatcher {
    envelope: ISmartreportMessageEnvelope,
    type: MutationEventType;
    service: MutationServiceType;
    context: MutationDispatcherContextBase;
    constraint: IReportConstrainer;
}

// for queries and mutations, limit changes to a certain report on the view
export interface IReportConstrainer {
    report: string;
    view: string;
    itemId?: string;
}


export abstract class SmartreportConnectorBridgeCommand {

    // accessor
    abstract getConnector(): SmartreportSourceConnector;

    // correctly resolved URL for content, must be pre-processed
    abstract getNavigationTransitionContentResolvedURL(): string | null;

    // locate recently set content, if exists
    abstract getNavigationTransitionContent(): INavigationTransitionContentSchema | null;

    abstract getTransitionObserver(): SmartreportNavigatorTransitionAction;

    // ------------ override -----------------
    abstract cleanEvents(): void;


    // references SR
    abstract getManagerWindow(): Window;


    abstract listening(topic: string, boundHandler: IResponderInvokedCallback, shouldDestroyListenerAfterwardsFlag?: boolean): { (event: MessageEvent): void };


    abstract onSubscribed(): void;


    // ------------------- command SR actions
    // data resync'ed depending on active view
    abstract refresh(): void;

    // force a locale change
    abstract changeLocale(localeRecord: ILocale): void;

    // SR reacts to modified filters
    abstract changeFilters(filterContext: any): void;


    abstract mutateReportFilterState(mutationType: MutationEventType, data: IHashContextFilterEntity,
                                     reportConstrainer: IReportConstrainer,
                                     mutationResponseHandler: IResponderInvokedCallback): void;

    // ------------------- /command
    // help change
    abstract onSetHelp(response: any, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;

    abstract onLoadNav(response: INavigationMessageSchema, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;

    abstract onSetTitle(response: INavigationMessageSchema, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;

    /**
     * partner app just triggered navigation move, provided existing navigation token
     * @param transitionContent
     */
    abstract navigateTransitionContent(transitionContent: INavigationTransitionContentSchema): void;


    /**
     * when the navigation title is updated, supply callbacks
     * @param response
     * @param respond
     * @param event
     */
    abstract onSetNav(response: INavigationMessageSchema, respond: IResponderPartnerHandlerEndpoint, event: MessageEvent): void;

    // /nav react demanded

    // partner integration
    // adapting the help registration
    abstract registerSetNavigationService(navigationInvocationHandler: IResponderInvokedCallback): void;

    abstract registerLoadNavigationService(navigationInvocationHandler: IResponderInvokedCallback): void ;

    // Aspect : moment of transition, before tearing down connector
    abstract registerLoadNavigationAfterService(handlerEndpoint: IResponderPartnerHandlerEndpoint): void ;

    // recommend pick up title changes: helps in reflecting history UI
    abstract registerSetTitleService(navigationInvocationHandler: IResponderInvokedCallback): void;

    abstract registerReportFilterStateChangeService(reportStateChangeInvocationHandler: IResponderInvokedCallback): void;


    // if a modal is attached, inspect the behavior for mapping navigation state changes within its embedded custom page
    abstract getOpenModalInstanceNavigationObserverState(modalInstance: IOpenedModalInstance): boolean;

    // change default behavior of the modal to observe navigation changes and reflect them ( typically in the header portion )
    abstract setOpenModalInstanceNavigationObserverState(modalInstance: IOpenedModalInstance, state: boolean): boolean;

}

