// Public interface to SmartBridge Angular Client

export {
    IVirtualClientBridge,
    IProxySourceConnector,
    SmartBridgeDelegateResponder,
    SmartBridgeDelegateService
} from "./services/smartbridge-delegate";

export {
    SmartbridgeClientAdapterModule,

    // provided as
    _smartreportGenerateSmartServicesInjectorFactory,
    _smartreportGenerateClientBridgeDelegateService,

    // exposed token
    GENERATE_CLIENT_BRIDGE_DELEGATE_SERVICE_TOKEN,
    GENERATE_SMART_SERVICES_INJECTOR_TOKEN
} from "./modules/smartbridge-client-adapter.module";
