import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod, URLSearchParams, Jsonp, ResponseContentType } from '@angular/http';
import { HttpClient, HttpHeaders, HttpEventType, HttpRequest, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import { LoggerService } from 'app/shared/logger.service';
import { AppService } from 'app/shared/app.service';

@Injectable()

export class ApiService {

    routerConfig: any;

    constructor(public appService: AppService, public http: Http, public httpClient: HttpClient, public router: Router, public jsonp: Jsonp, public logger: LoggerService) {

    }


    getTVAAPI(url: string, body: any) {

        let requestOptions = {
            method: "GET",
            timeout: 10000,
            url: url + '&callback=tvaInstance.jsonpCallback', //'&callback=JSONP_CALLBACK' //tvaInstance.jsonpCallback
            body: body
        };

        return this.jsonp.get(url, requestOptions)
            .map((res: Response) => { res.json() });

    }

    getUrlBasic(url: string, body: any) {

        this.logger.info("Api Service.. making get call.");

        let username = (<any>window).acConfig.awsUsername;
        let password = (<any>window).acConfig.awsPassword;

        var headers = new Headers();
        headers.append("Authorization", "Basic " + btoa(username + ":" + password));
        var requestOptions = new RequestOptions({
            method: RequestMethod.Get,
            url: url,
            headers: headers,
            body: body
        });

        return this.http
            .request(new Request(requestOptions))
            .map((res: Response) => res.json());

    }


    getUrl(url: string, body: any) {

        this.logger.info("Api Service.. making get call.");
        var headers = new Headers();
        console.log("ssue_accessToken -- ", (<any>top).ssue_accessToken);
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        headers.append("Content-Type", "application/json");
        var requestOptions = new RequestOptions({
            method: RequestMethod.Get,
            url: url,
            headers: headers
        });

        return this.http
            .request(new Request(requestOptions))
            .map((res: Response) => res.json());

    }
    
    getPlainUrl(url: string, body: any) {

        this.logger.info("Api Service.. making get call.");
        var headers = new Headers();
        console.log("ssue_accessToken -- ", (<any>top).ssue_accessToken);
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
            method: RequestMethod.Get,
            url: url,
            headers: headers
        });

        return this.http
            .request(new Request(requestOptions))
            .map((res: Response) => res.text());

    }

    getAPI(url: string, body: any) {

        this.logger.info("Api Service.. making get call.");
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Content-Type", "application/json");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
            method: RequestMethod.Get,
            url: url,
            headers: headers
        });

        return this.http
            .request(new Request(requestOptions));

    }

    postBasic(url: string, body: any) {

        this.logger.info("API Service.. making post call.");

        let username = (<any>window).acConfig.awsUsername;
        let password = (<any>window).acConfig.awsPassword;

        var headers = new Headers();
        headers.append("Content-Type", "application/x-www-form-urlencoded");//application/json
        headers.append("Authorization", "Basic " + btoa(username + ":" + password));

        var requestOptions = new RequestOptions({
            method: RequestMethod.Post,
            url: url,
            headers: headers,
            body: body
        });

        return this.http
            .request(new Request(requestOptions));


    }

    postUrl(url: string, body: any) {

        this.logger.info("API Service.. making post call.");
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
            console.log((<any>top).ssue_accessToken);
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Content-Type", "application/json");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
            method: RequestMethod.Post,
            url: url,
            headers: headers,
            body: body
        });

        return this.http
            .request(new Request(requestOptions));

    }

    postFile(url: string, body: FormData) {
        this.logger.info("API Service.. making post file call.");
        var headers = new Headers();
        //headers.append("Content-Type", "multipart/form-data");     
        //headers.append('Accept', 'application/json');    
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        let options = new RequestOptions({ headers: headers });
        return this.http.post(url, body, options);
    }
    
    postFileProgress(url: string, body: FormData) {

        this.logger.info("API Service.. making post file call with progress.");
        var headers = new HttpHeaders();   
        if((<any>top).ssue_accessToken != undefined){
            headers = headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers = headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers = headers.append("loggedin", this.appService.get("cecID"));
        headers = headers.append("CUSTOMER", this.appService.get("cpyKey"));

        const req = new HttpRequest('POST', url, body, {
            headers: headers,
            reportProgress: true
        });
        return this.httpClient.request(req);

    }

    downloadFile(url: string, body: any){

        this.logger.info("API Service.. making download call.");
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Accept", "application/octet-stream");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        let options = new RequestOptions({ 
            responseType: ResponseContentType.Blob,
            headers: headers
        });
        return this.http.post(url, body, options);

    }
    

    putUrl(url: string, body: any) {

        this.logger.info("API Service.. making put call.");
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Content-Type", "application/json");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
            method: RequestMethod.Put,
            url: url,
            headers: headers,
            body: body
        });

        return this.http
            .request(new Request(requestOptions));


    }

    deleteUrl(url: string, body: any) {

        this.logger.info("API Service.. making delete call.");
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        headers.append("Content-Type","application/json");
        var requestOptions = new RequestOptions({
            method: RequestMethod.Delete,
            url: url,
            headers: headers,
            body: body
        });
        return this.http
            .request(new Request(requestOptions));

    }

    public handleError(error: Response | any) {

        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        this.logger.info(errMsg);
        return Observable.throw(errMsg);

    }
    
    getExternalAPI(url: string, body: any) {

        this.logger.info("Api Service.. making external get call.");
        var headers = new Headers();
        var requestOptions = new RequestOptions({
            method: RequestMethod.Get,
            url: url,
            headers: headers
        });

        return this.http
            .request(new Request(requestOptions));

    }

}