import { Injectable, Input, Output, EventEmitter } from '@angular/core';
import { LoggerService } from 'app/shared/logger.service';

export type InteralStateType = {
  [key: string]: any
};

@Injectable()
export class AppService {

  _state: InteralStateType = { };
  currentUser:any;
  constructor(public logger: LoggerService) {

    if(document.domain.match(/\w+[.]\w+$/) != null){
      document.domain = document.domain.match(/\w+[.]\w+$/).toString();
    }

    this.set("ssue_accessToken", "AZ2PiSFWFOG2kHMiS1CnxCExK0Gm");
    this.set("workFlowId", "AsWorkflowProcess");
    this.set("cecID", "vasadhar"); //vasadhar
    this.set("cpyKey", "97ac0a30-d6b1-11e8-b035-e33af77233a6"); //176691
    this.set("filterContext", "");
    // {"service":"caentitlement:ssue:services:cfassessments","customer":[176691],"assessment_type":[10110]}
    this.set("filterContextValue", "");
    // {"service":"caentitlement:ssue:services:cfassessments","customer":["Circle Solutions"],"assessment_type":["Health Check"]}
    this.set("domainFilter", "");
    this.set("assessmentId", null);
    this.set("customCommands", null);
    this.set("excludedSNMPs", null);
    this.set("excludedCLIs", null);
    this.set("editstep", 0);
    this.set("processID", "");
    this.set("assessmentData", null);

    console.log("top ssue", (<any>top).ssue);

    if ((<any>top).ssue && (<any>top).ssue != ""){

      this.logger.info("ccoId", (<any>top).ssue.common.api.access.ccoId);
      if((<any>top).ssue.common.api.access.ccoId != undefined && (<any>top).ssue.common.api.access.ccoId != ""){
        this.set("cecID", (<any>top).ssue.common.api.access.ccoId);
      }
      if((<any>top).ssue.common.api.access._filterContext != undefined && (<any>top).ssue.common.api.access._filterContext != ""){
        this.set("filterContext", (<any>top).ssue.common.api.access._filterContext); 
        this.set("cpyKey", (<any>top).ssue.common.api.access._filterContext.customer[0]);
      }
      
      if((<any>top).ssue.common.api.access._filterContextValue != undefined && (<any>top).ssue.common.api.access._filterContextValue != ""){
        this.set("filterContextValue", (<any>top).ssue.common.api.access._filterContextValue);
      }
      if((<any>top).ssue.common.api.access.domainFilter != undefined && (<any>top).ssue.common.api.access.domainFilter != ""){
        this.set("domainFilter", (<any>top).ssue.common.api.access.domainFilter);
      }

    }


  }

  updateSSUEFilter(){

      if ((<any>top).ssue && (<any>top).ssue != ""){
  
        this.logger.info("ccoId", (<any>top).ssue.common.api.access.ccoId);
        if((<any>top).ssue.common.api.access.ccoId != undefined && (<any>top).ssue.common.api.access.ccoId != ""){
          this.set("cecID", (<any>top).ssue.common.api.access.ccoId);
        }
        if((<any>top).ssue.common.api.access._filterContext != undefined && (<any>top).ssue.common.api.access._filterContext != ""){
          this.set("filterContext", (<any>top).ssue.common.api.access._filterContext); 
          this.set("cpyKey", (<any>top).ssue.common.api.access._filterContext.customer[0]);
        }
        if((<any>top).ssue.common.api.access._filterContextValue != undefined && (<any>top).ssue.common.api.access._filterContextValue != ""){
          this.set("filterContextValue", (<any>top).ssue.common.api.access._filterContextValue);
        }      
  
      }

  }

  getUnixTimeStamp(){
    return Math.floor(Date.now() / 1000);
  }


/*
 getUserIP(onNewIP) { //  onNewIp - your listener function for new IPs
  //compatibility for firefox and chrome
  var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
  var pc = new myPeerConnection({
      iceServers: []
  }),
  noop = function() {},
  localIPs = {},
  ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
  key;

  function iterateIP(ip) {
      if (!localIPs[ip]) onNewIP(ip);
      localIPs[ip] = true;
  }

   //create a bogus data channel
  pc.createDataChannel("");

  // create offer and set local description
  pc.createOffer(function(sdp) {
      sdp.sdp.split('\n').forEach(function(line) {
          if (line.indexOf('candidate') < 0) return;
          line.match(ipRegex).forEach(iterateIP);
      });

      pc.setLocalDescription(sdp, noop, noop);
  }, noop);

  //listen for candidate events
  pc.onicecandidate = function(ice) {
      if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
      ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
  };
}
*/

  // already return a clone of the current state
  get state() {
    return this._state = this._clone(this._state);
  }
  // never allow mutation
  set state(value) {
    throw new Error('do not mutate the `.state` directly');
  }


  get(prop?: any) {
    // use our state getter for the clone
    const state = this.state;
    return state.hasOwnProperty(prop) ? state[prop] : state;
  }

  set(prop: string, value: any) {
    // internally mutate our state
    //this.logger.info(prop+" == "+value);
    return this._state[prop] = value;
  }


  _clone(object) {
    // simple object clone
    return JSON.parse(JSON.stringify( object ));
  }
}
