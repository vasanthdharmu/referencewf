import { NgModule, ModuleWithProviders } from '@angular/core';
import { Http, HttpModule, RequestOptions, XHRBackend } from '@angular/http';
import { ApiService } from 'app/shared/api.service';
import { HttpService } from 'app/shared/http.service';
import { ValidationService } from 'app/shared/validation.service';
import { LoggerService } from 'app/shared/logger.service';
import { ConsoleLoggerService } from 'app/shared/console-logger.service';
/*
export function translateHttpServiceLoader(backend: XHRBackend, options: RequestOptions) {
  return new HttpService(backend, options);
}
*/

@NgModule({})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [
			{ provide: LoggerService, useClass: ConsoleLoggerService },
			ApiService,
			/*{
				provide: Http,
				useFactory: translateHttpServiceLoader,
				deps: [XHRBackend, RequestOptions]
			},
			*/
			//{ provide: Http, useFactory: (backend: XHRBackend, options: RequestOptions) => { return new HttpService(backend, options); }, deps: [XHRBackend, RequestOptions] },
			ValidationService			
	  ]
    };
  }
}