import { Component } from '@angular/core';

@Component({
  selector: 'ac-sidebar',
  templateUrl: './sidebar.template.html',
  styleUrls: ['./sidebar.style.css']
})
export class SidebarComponent {
  public open: any;
}
