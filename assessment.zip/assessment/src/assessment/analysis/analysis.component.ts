import { Component, ViewChild, Input, ElementRef } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { TranslateService } from 'ng2-translate';

@Component({
  styleUrls: ['./analysis.style.css'],
  selector:'analysis',
  templateUrl: './analysis.template.html',
  entryComponents: [  ]
})
export class AnalysisComponent{

  public assessmentId:any;
  public rulesStepData : any;  
  public detailsStepData : any;
  public detailsData:boolean = false;
  public isSubmitted:boolean =false;
  public confirmStepData : any;
  public stepper_content:any;
  private subscriptionConfirm: ISubscription;
  // public submitting:boolean =false;
  constructor(public translate: TranslateService,public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    //(<any>window).localStorage.clear();
    //(<any>window).sessionStorage.clear();    
    this.assessmentId = null;
    this.registerToSSUEApiAnalysis();

  }

  ngOnInit() {        
    this.stepper_content = document.getElementsByClassName("ssue-step-content");
  }

  ngOnDestroy() {
		this.subscriptionConfirm.unsubscribe();
	}

  setRulesStepData(data){
    this.logger.info("setRulesStepData", data);
    this.rulesStepData = data;    
  }  
  
  setDetailsStepData(data){
  	this.logger.info("detailsStepData", data);
  	this.detailsStepData = data;
    this.detailsData = true;    
    
  }

  setconfirmStepData(data){
    this.logger.info("setconfirmStepData", data);
    this.confirmStepData = data;    
  }

  public registerToSSUEApiAnalysis(){
    
    this.workflowapi.registerEvent('onCancel')
		.subscribe((response: any) => {
      this.assessmentService.backtoSSUE("CFAssessment:Projects");
    });
    
    this.workflowapi.registerEvent('previousStepData')
    .subscribe((response: any) => {
        if (this.stepper_content.length == 0) {
            return;
        }
        else{
          this.stepper_content[0].scrollTop=0; 
        }        
    });

    this.subscriptionConfirm = this.workflowapi.registerEvent('onConfirm')
    .subscribe((response: any) => {

      console.log("onConfirm *** Analysis");
      console.log("isSubmitted", this.isSubmitted);
      
      if( !this.isSubmitted ){

        this.isSubmitted = true;
        console.log("isSubmitted:inside", this.isSubmitted);
        let postData:any = {

        };
        let workflowData = response.payload;
        this.logger.info("workflowData", workflowData);
        if(workflowData.step1 != null && workflowData.step2 != null){
          postData.collectionJobId = JSON.parse(workflowData.step1).collectionDetails[0].collectionJobId;
          postData.deviceList = JSON.parse(workflowData.step1).devices;
          let includedICs = JSON.parse(workflowData.step2).includedICs;
          let icList = [];
          for(let IC of includedICs) {
            icList.push(IC.name);
          }
          postData.ruleList = icList;   
          // if(!this.submitting)
            this.startAnalysis(postData);
        }

      }

    });

  }
  
  public startAnalysis(postData){
    // this.submitting=true;
    this.logger.info("postData", postData);
      this.apiService.postUrl((<any>window).acConfig.postAnalysisAPI, JSON.stringify(postData)).subscribe(
        (result) => {
              // this.submitting=false;
              let respData = result.json();
              if(result.status === 202){
                this.translate.get('NOTIFICATIONSUCCESS.ANALYSIS.STARTANALYSIS').subscribe((res: string) => {
                  let alertMetaData = {
                      "name": "startanalysis",
                      "title": "Start Analysis",
                      "type": "SUCCESS",
                      "content": res
                  }
                  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);	
                });
                  this.assessmentService.backtoSSUE("CFAssessment:Projects");
                  //this.workflowapi.clearStorage();
                  //(<any>window).localStorage.clear();
                  //(<any>window).sessionStorage.clear();
              }           	
              else{
                this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.STARTANALYSIS').subscribe((res: string) => {
                  let alertMetaData = {
                      "name": "startanalysisfailure",
                      "title": "Error on Start Analysis",
                      "type": "DANGER",
                      "content": res
                  }
                  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);	
                });
              }
      },
      (err) => {
              // this.submitting=false;
              let errinfo = err.json();
              this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.STARTANALYSIS').subscribe((res: string) => {
                let alertMetaData = {
                    "name": "startanalysisfailure",
                    "title": "Error on Start Analysis",
                    "type": "DANGER",
                    "content": res
                }
              this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            });
      });

	}
  
}