import { Component, ViewChild, ElementRef, ViewEncapsulation, Pipe, PipeTransform, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ISubscription } from "rxjs/Subscription";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { GridOptions } from 'ag-grid/main';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { CuiTableOptions } from 'aui/components/cui-table';

@Component({
    selector: 'analysis-final',
    templateUrl: './analysis.final.template.html',
    styleUrls: ['./analysis.final.style.css'],
    encapsulation: ViewEncapsulation.None,
})
export class AnalysisConfirmComponent {

    private subscriptionAllStepsData: ISubscription;

    public assessmentConfirmForm: FormGroup;
    public selectedDevicesgridOptions: GridOptions;
    public columnDefs: any[];
    public icgridOptions: GridOptions;
    public iccolumnDefs: any[];
    public cmdgridOptions: GridOptions;
    public cmdcolumnDefs: any[];
    public icsearchText: string;
    public searchText: string;
    public popupdata: any;
    public allstepData: any;
    public step1Data: any;
    public ste2Data: any;
    public customCommandTableOptions: CuiTableOptions;
    public customCommands: Array<any> = [];
    public periodList = [{ "value": "10080", "name": "7 days" },
        { "value": "8640", "name": "6 Days" },
        { "value": "7200", "name": "5 Days" },
        { "value": "5760", "name": "4 Days" },
        { "value": "4320", "name": "3 Days" },
        { "value": "2880", "name": "2 Days" },
        { "value": "1440", "name": "1 Day" },
        { "value": "60", "name": "1 Hr" },
        { "value": "10", "name": "10 Min" }];



    @Output() confirmStepData: EventEmitter<any> = new EventEmitter();

    // public excluded_commands = [{id:1, command:"cmd 1"},{id:2, command:"cmd 2"},{id:1, command:"cmd 3"}];
    // public custom_commands = [{id:1, command:"cmd 1",ostypes:["iOS","123"], name:"Command Name 1", mode:"CLI"},{id:2, command:"cmd 2",ostypes:["iOS","123"],name:"Command Name 2", mode:"SNMP"},{id:1, command:"cmd 3",ostypes:["iOS","123"],name:"Command Name 3", mode:"CLI"}];

    public selectedDevices = [{ deviceId: "24635066", ipaddress: "192.168.1.1", deviceType: "System", deviceVersion: "0.1234", productFamily: "Family 12345" },
        { deviceId: "24635066", ipaddress: "192.168.1.1", deviceType: "System", deviceVersion: "0.1234", productFamily: "Family 12345" }];

    constructor(public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public workflowapi: workflowApi) {


        this.selectedDevicesgridOptions = <GridOptions>{
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No devices to list</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };

        this.icgridOptions = <GridOptions>{
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createICColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No IC to list</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };

        this.cmdgridOptions = <GridOptions>{
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createCMDColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No Custom Commands added by you</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };

        this.customCommandTableOptions = new CuiTableOptions({
            "bordered": true,
            "striped": false,
            "hover": false,
            "wrapText": false,
            "padding": "regular",
            "selectable": false,
            "dynamicData": true,
            "columns": [
                {
                    "name": "Command Name",
                    "key": "command"
                },
                {
                    "name": "Command Type",
                    "key": "mode"
                },
                {
                    "name": "OS Type",
                    "key": "ostypes"
                },
                {
                    "name": "Version",
                    "key": "version"
                },
                {
                    "name": "Repetition",
                    "key": "repetition"
                },
                {
                    "name": "Frequency",
                    "key": "frequency"
                }
            ]
        });

        this.registerToSSUEApiFinal();

    }

    ngOnDestroy() {
		this.subscriptionAllStepsData.unsubscribe();
	}

    ngOnInit() {
        this.loadConfirmForm();
    }

    preLoad() {

        //this.selectedDevicesgridOptions.api.setRowData(this.step1Data.devices);
        // this.icgridOptions.api.setRowData(this.icList); 
    }

    loadConfirmForm() {

        this.assessmentConfirmForm = new FormGroup({
            // 'acceptPrerequistie': new FormControl('', Validators.required),
            // 'searchText':new FormControl()
        });

    }

    public isValidated() {

        this.logger.info("this.assessmentConfirmForm.valid", this.assessmentConfirmForm.valid);
        if (this.assessmentConfirmForm.valid) {
            return true;
        }
        return false;

    }

    public createColumnDefs() {
        this.columnDefs = [
            {
                headerName: "Device ID", field: "deviceId", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceId", headerTooltip: "Device Id",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Name", field: "deviceSysname", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceSysname", headerTooltip: "Device Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "IP Address", field: "ipAddress", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "ipAddress", headerTooltip: "IP Address",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Type", field: "deviceType", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceType", headerTooltip: "Device Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Version", field: "swVersion", width: 200, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "swVersion", headerTooltip: "Device Version",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Product Family", field: "productFamily", width: 250, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "productFamily", headerTooltip: "Product Family",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
        ];

        return this.columnDefs;
    }

    public createICColumnDefs() {

        this.iccolumnDefs = [
            {
                headerName: "IC Name", field: "name", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "name", headerTooltip: "IC Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "IC Type", field: "visibility", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "visibility", headerTooltip: "IC Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "OS Type", field: "osType", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "osType", headerTooltip: "OS Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "NMS Area", field: "nmsArea", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "nmsArea", headerTooltip: "NMS Area",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Architecture Type", field: "architecture", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "architecture", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "IC Description", field: "summary", width: 200, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Status", field: "status", width: 100, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "status", headerTooltip: "Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            }
        ];
        return this.iccolumnDefs;

    }
    public createCMDColumnDefs() {

        this.cmdcolumnDefs = [
            {
                headerName: "Command Name", field: "command", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "command", headerTooltip: "Command Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Command Type", field: "mode", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "mode", headerTooltip: "Command Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "OS Type", field: "ostypes", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "ostypes", headerTooltip: "OS Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Version", field: "version", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "version", headerTooltip: "Version",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Repetition", field: "repetition", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "repetition", headerTooltip: "Repetition",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Frequency", field: "frequency", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "frequency", headerTooltip: "Frequency",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            }
        ];
        return this.cmdcolumnDefs;

    }

    public showDialogPop(dialog, data) {
        this.popupdata = data;
        dialog.width = "50%";
        dialog.height = "50%";
        dialog.showDialog();
    }

    public logSelectedTab(evt) {
        // console.log(evt);
    }

    public emitStepDataOnChange(data: any) {
        this.confirmStepData.emit(data);

    }

    public registerToSSUEApiFinal() {

        this.subscriptionAllStepsData = this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                console.log("allStepsData", response);
                this.allstepData = response.allStepsData;
                this.step1Data = JSON.parse(this.allstepData.step1);
                this.ste2Data = this.allstepData.step2 ? JSON.parse(this.allstepData.step2) : null;                                
                if (this.ste2Data != null) {
                    let url = (<any>window).acConfig.getDevicesAPI + this.appService.get("cpyKey") + '/collector/' + this.step1Data["applianceId"];
                    this.apiService.getAPI(url, '').subscribe(
                        data => {
                            this.step1Data["listDevices"] = [];
                            if(this.selectedDevicesgridOptions != null && this.selectedDevicesgridOptions.api != null){
                                this.selectedDevicesgridOptions.api.setRowData([]);
                            }
                            let respData = data.json();
                            let devices = this.step1Data["devices"];
                            let deviceSelected = [];
                            for (let device of devices) {
                                deviceSelected.push(parseInt(device));
                            }
                            respData.forEach(deviceDetails => {
                                if (deviceSelected.indexOf(deviceDetails.deviceId) > -1) {
                                    this.step1Data.listDevices.push(deviceDetails);
                                }
                            });
                            if(this.selectedDevicesgridOptions != null && this.selectedDevicesgridOptions.api != null){
                                this.selectedDevicesgridOptions.api.setRowData(this.step1Data.listDevices);
                            }
                        },
                        err => {
                            if(this.selectedDevicesgridOptions!=null && this.selectedDevicesgridOptions.api!=null)
                                this.selectedDevicesgridOptions.api.setRowData([]);
                            console.error(err);
                        }
                        , () => { }
                    );
                    if(this.icgridOptions!=null && this.icgridOptions.api!=null)
                        this.icgridOptions.api.setRowData(this.ste2Data!=null ? this.ste2Data.includedICs : []);
                    if(this.cmdgridOptions!=null && this.cmdgridOptions.api!=null)
                        this.cmdgridOptions.api.setRowData(this.step1Data.commandSet!=null ?JSON.parse(this.step1Data.commandSet):[]);                      
                }
                if (this.step1Data.commandSet != null) {
                    this.customCommands = JSON.parse(this.step1Data.commandSet);
                }
            });

    }

    public getOptionValue(value, inputArray) {

        for (let input of inputArray) {
            if (input.value == value) {
                return input.name;
            }
        }
        return "";

    }

}



