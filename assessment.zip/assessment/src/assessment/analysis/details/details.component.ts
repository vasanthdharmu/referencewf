import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { DatePipe } from '@angular/common';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { TranslateService } from 'ng2-translate';
import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';
import { ProjectLinkComponent } from 'assessment/analysis/details/projectlink.component';

@Component({
    selector: 'analysis-details',
    templateUrl: './details.template.html',
    styleUrls: ['./details.style.css'],
    entryComponents: [FusionToaster, ProjectLinkComponent],
    encapsulation: ViewEncapsulation.None,
})

export class DetailsComponent implements OnInit {
    public assessmentData: any = {};
    public assessmentName: any;
    public loaderAssessmentData: boolean = false;
    public loadData: boolean = false;
    public assessmentBasicForm: FormGroup;
    public formelements: any;
    public scriptTestResult: any;
    public selectedNodesLength: any;
    public gridOptions: GridOptions;
    public rowData: any[];
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;
    public showActions: any;
    public showToolPanel: any;
    @Output() detailsStepData: EventEmitter<any> = new EventEmitter();

    @ViewChild('dialogProjectList') dialogProjectList;

    constructor(public translate: TranslateService, public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
        this.registerToSSUEApi();
    }

    public registerToSSUEApi() {

        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {

            });

    }

    ngOnInit() {

        this.loadBasicForm();
        let params = new URLSearchParams(window.location.search);
        //if(params.rawParams != ""         
        this.assessmentName = params.get('?assessmentName');
        let status = decodeURIComponent(params.get('status'));
        if (status != "null") {
            this.loadAssessmentData(this.assessmentName);
        }
        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            rowModelType: 'infinite',
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no available projects</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };
        this.getAssessments();

    }

    loadAssessmentData(assessmentName) {

        this.loaderAssessmentData = true;
        this.apiService.getAPI((<any>window).acConfig.getAssessmentListAmxAPI + assessmentName, '').subscribe(  // api for project details
            data => {
                let respData = data.json();
                this.logger.info("respData", respData);
                if (respData.collectionDetails) {
                    let deviceNames = [];
                    if (respData.devices) {
                        for (let device of respData.devices) {
                            deviceNames.push(device.deviceName);
                        }
                    }
                    this.loadData = true;
                    this.assessmentData = respData;
                    this.assessmentData.deviceNames = deviceNames;
                    this.assessmentData.createdTime = this.dateFormat(this.assessmentData.createdTime);
                    this.assessmentData.collectionDurationLabel = this.durationFormat(respData.duration);
                    this.assessmentData.startCollection = (respData.schedule == "" || respData.schedule == null) ? "Now" : "Later";
                    // this.loadCollectionDurationList(this.assessmentData.assessmentType, this.assessmentData.platform, this.assessmentData.collectionDuration);
                    this.loaderAssessmentData = false;
                    this.assessmentBasicForm.patchValue({
                        'projectName': respData.name
                    });
                    if (respData.catalogName) {

                    }
                    this.emitStepDataOnChange(JSON.stringify(this.assessmentData));
                } else {
                    this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOCOLLECTION').subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "selectcollectionfailure",
                            "title": "Error on Selecting Collection",
                            "type": "DANGER",
                            "content": res
                        }
                        this.loaderAssessmentData = false;
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                }
            },
            err => {
                this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOPROJECT').subscribe((res: string) => {
                    this.loaderAssessmentData = false;
                    let alertMetaData = {
                        "name": "getprojectdetailfailure",
                        "title": "Error on Project Details",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });
                console.error(err);
            }
            , () => { }
        );

    }

    loadCollectionDurationList(assessmentType, platform, selectedduration) {
        this.apiService.getAPI((<any>window).acConfig.getCollectionDurationAPI + assessmentType + '/platforms/' + platform + '/', '').subscribe(
            data => {
                let respData = data.json();
                this.logger.info("collection duration", respData);
                if (respData.length == 0) {
                    this.assessmentData.collectionDurationLabel = "None";
                }
                respData.forEach(duration => {
                    if (selectedduration == duration.value) {
                        this.assessmentData.collectionDurationLabel = duration.name;
                    }
                });
            },
            err => {
                this.assessmentData.collectionDurationLabel = "None";
            }
            , () => { }
        );
    }
    loadBasicForm() {
        let projectName = "";
        let tomorrowDate = new Date(new Date().getTime() + 86400000).toISOString().slice(0, 10);
        this.assessmentBasicForm = new FormGroup({
            'projectName': new FormControl(projectName)
        });
    }
    public fetchProjectList() {
        let dialog = this.dialogProjectList;
        dialog.width = "80%"; 
        dialog.height = "95%";
        dialog.showDialog();
    }

    public onProjectSelection(id, status) {

        let dialog = this.dialogProjectList;
        let editLink = '/assessment/analysis?assessmentName=' + id + '&status=' + status;
        this.router.navigateByUrl(editLink);
        this.loadAssessmentData(id);
        dialog.cancelAction();
    }

    public onRowSelected($event) {
        let selectedNodes = this.gridOptions.api.getSelectedNodes();
        this.selectedNodesLength = selectedNodes.length;
    }

    getAssessments() {
        let url = (<any>window).acConfig.getAssessmentListAPI; // api call for loading pop up project list
        this.apiService.getUrl(url, '').subscribe(
            data => {
                this.logger.info("assessment list", data);
                console.log("analysis: getAssessments", this.gridOptions);
                if (this.gridOptions.api != null) {
                    this.gridOptions.api.setRowData(this.refineData(data, "draft"));
                    this.gridOptions.api.hideOverlay();
                    this.gridOptions.api.sizeColumnsToFit();
                }
            },
            err => console.error(err)
            , () => { }
        );

    }

    public createColumnDefs() {

        this.columnDefs = [
            {
                headerName: "Project Name", field: "name", width: 300, sortingOrder: ['asc', 'desc'], cellRendererFramework: ProjectLinkComponent, pinned: true,
                tooltipField: "name", headerTooltip: "Project Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Assessment Status", field: "status", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "status", headerTooltip: "Assessment Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Job Status", field: "jobStatus", width: 250, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "jobStatus", headerTooltip: "Job Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Created Date", field: "createdTime", width: 300, sortingOrder: ['asc', 'desc'], cellRenderer: this.formatDate, pinned: true,
                tooltipField: "createdTime", headerTooltip: "Created Date", suppressSorting: true, suppressFilter: true
            },
        ];
        return this.columnDefs;

    }

    formatDate(params) {
        const datepipe: DatePipe = new DatePipe('en-US');
        return datepipe.transform(params.data.createdTime, 'yMMMdjms');
    }

    public calculateRowCount() {
        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }
    public close() {
        let dialog = this.dialogProjectList;
        dialog.cancelAction();
    }
    public emitStepDataOnChange(data: any) {
        this.detailsStepData.emit(data);
    }
    public icManagerRedirect() {
        let crateICLink = '/assessment/createic';
        this.router.navigateByUrl(crateICLink);
    }
    refineData(data, status) {
        let popUpData = [];
        for (let project of data) {
            if (project.status.toLowerCase() != status && project.jobStatus == 'Extraction-Completed') {
                popUpData.push(project);
            }
        }
        return popUpData;
    }
    dateFormat(params) {
        const datepipe: DatePipe = new DatePipe('en-US');
        return datepipe.transform(params, 'yMMMdjms');
    }
    durationFormat(duration) {
        if (duration / 60 < 1) {
            return duration + " Min";
        }
        else if (duration / 60 == 1) {
            return duration / 60 + " Hr";
        }
        else if (duration / 60 > 1 && duration / 60 < 24) {
            return duration / 60 + " Hr";
        }
        else
            return (duration / (60 * 24)) + " Days";
    }

    public getOptionValue(value, inputArray) {

        for (let input of inputArray) {
            if (input.value == value) {
                return input.name;
            }
        }
        return "";

    }
}
