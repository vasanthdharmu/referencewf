import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'project-link',
    template: `<a (click)="onProjectSelection()">{{params.data.name}}</a>`
})

export class ProjectLinkComponent implements ICellRendererAngularComp  {
    public params: any;
    constructor(public router: Router) {    
    }
    agInit(params: any): void {
        this.params = params;
    }
    refresh(): boolean {
        return false;
    }
    public onProjectSelection() {
        this.params.context.componentParent.onProjectSelection(this.params.data.name,this.params.data.status);
    }
}