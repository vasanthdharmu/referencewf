import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'select-ic',
    template: `<a (click)="showICDetails()">{{params.data.name}} </a>`
})

export class ICNameLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {    
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public showICDetails() {		
        
        this.params.context.componentParent.showICDetails(this.params.data);
        
    }
}