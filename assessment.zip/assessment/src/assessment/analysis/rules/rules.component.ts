import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod, URLSearchParams, Jsonp } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from "rxjs/Subscription";
import { GridOptions } from 'ag-grid/main';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

import { CuiTableOptions } from 'aui/components/cui-table';
import { ICNameLinkComponent } from 'assessment/analysis/rules/icnamelink.component';

import { AceEditorComponent } from 'ng2-ace-editor';
import { TranslateService } from 'ng2-translate';
import "brace/mode/python";

@Component({
	selector: 'rules',
    templateUrl: './rules.template.html',
    styleUrls: [ './rules.style.css' ],
    encapsulation: ViewEncapsulation.None,
})
export class RulesComponent {

	private subscriptionAllStepsData: ISubscription;

	public gridOptions:GridOptions;
	public rowData: any[];
	public columnDefs: any[];
	public rowCount: string;
	public tableDataSource: any[];
	public rowModelPaginationType:string;

	public ICList:Array<any> = [];
	public excludedICs:Array<any> = [];
	public includedICs:Array<any> = [];	
	public mode: string;
	public selectedIC: any = "";

	public deviceForm: FormGroup;
	public devices = [];
	public scriptResult: any;

	public scriptTestResult: any = "<xml></xml>";

	@Output() rulesStepData: EventEmitter<any> = new EventEmitter();

	@ViewChild('dialogTestScript') dialogTestScript;

	public scripttext:string = "";
	public scriptoptions:any = {maxLines: 1000, printMargin: false};
	
	public customCommandTableOptions: CuiTableOptions;
	public customCommands:Array<any> = [];
	public loaderICDetails:boolean = false;
	constructor(public http:Http,public translate: TranslateService, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public workflowapi: workflowApi) {
		
		this.registerToSSUEApi();

		//this.rowModelPaginationType = "inMemory";

		// we pass an empty gridOptions in, so we can grab the api out
		this.gridOptions = <GridOptions>{
			context: {
				componentParent: this
			},		
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No ICs</span>',
			overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
		};  
			  
	}

	ngOnDestroy() {
		this.subscriptionAllStepsData.unsubscribe();
	}

	public registerToSSUEApi(){

		this.subscriptionAllStepsData =  this.workflowapi.registerEvent('allStepsData')
		.subscribe((response: any) => {

		  let workflowData = response.allStepsData;
		  let icSubSet = JSON.parse(workflowData.step1).icSubSet;
		  this.selectedIC = "";
		  if(icSubSet != null && icSubSet.length > 0){
			this.mode = "list";		  
			this.loadICs(icSubSet);	
			this.loadDevices();
		  }else{
			this.loadICGrid([]);
		  }

		});

	}

	ngOnInit() {
        
		this.loadModel();

		this.deviceForm = new FormGroup({
			'device': new FormControl(''),
			'script': new FormControl('')
		});

		this.loadCustomCommandTable();

	}

	public loadCustomCommandTable(){
		
			this.customCommandTableOptions = new CuiTableOptions({
			  "bordered": true,
			  "striped": false,
			  "hover": false,
			  "wrapText": false,
			  "padding": "regular",
			  "selectable": false,
			  "dynamicData": true,
			  "columns": [  
				{
				  "name": "Command Name",       
				  "key": "command"
				},
				{
				  "name": "Command Type",         
				  "key": "mode"
				},
				{
				  "name": "OS Type",         
				  "key": "ostypes"
				},
				{
				  "name": "Repetition",         
				  "key": "repetition"
				},
				{
				  "name": "Frequency",         
				  "key": "frequency"
				}
			  ]
			});

	}

	public onDeviceChange(event){

		this.deviceForm.patchValue({'device': event.value});

	}

	public loadICs(icList){	

		let url = (<any>window).acConfig.getICListAPI;
		let body = [
				{
					"attribute":"name",
					"value": icList
				}
			];

		this.apiService.postUrl(url, body).subscribe(
			result => {

				if (result.status === 200) {
					let respData = result.json();
					this.ICList = respData;
					this.loadICGrid(respData);
				}else{
					this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOIC').subscribe((res: string) => {
						let alertMetaData = {
							"name": "loadic",
							"title" : "Getting IC Details Failure",
							"type":"DANGER",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.loadICGrid([]);
				}

			},
			err => {
				console.log("error loading ic", err);		
				this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOIC').subscribe((res: string) => {	
					let alertMetaData = {
					"name": "loadic",
					"title" : "Getting IC Details Failure",
					"type":"DANGER",
					"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.loadICGrid([]);
			}
			,() => {}
		);
		

	}

	public loadICGrid(data){
		if(this.gridOptions!=null && this.gridOptions.api!=null){
			if(data.length > 0 ){
				this.gridOptions.api.setRowData(data);
				this.gridOptions.api.hideOverlay();
				this.gridOptions.api.sizeColumnsToFit();
				this.gridOptions.api.forEachNode( (node) => {				
					node.setSelected(true);				
				});
			}else{
				this.gridOptions.api.setRowData([]);
				this.gridOptions.api.showNoRowsOverlay();
			}
		}
	}

	public loadModel(){

		let modelurl = (<any>window).acConfig.getNetworkModelAPI;
		this.apiService.getUrl(modelurl, '').subscribe(
			data => {
				this.scriptResult = data;
			},
			err => {
				
			}
			,() => {}
		);

	}

	public createColumnDefs() {
		
		this.columnDefs = [
			{
				headerName: "",
				field: "selectAllICs",
				width: 50,
				headerCheckboxSelection: true,
				headerCheckboxSelectionFilteredOnly: true,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},
			{headerName: "IC Name", field: "name", width: 150, sortingOrder: ['asc','desc'], cellRendererFramework:ICNameLinkComponent, pinned: true, tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
			},
			{headerName: "Created Date", field: "created",width: 150, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},
			{headerName: "IC Type", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "visibility", headerTooltip: "IC Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "OS Type", field: "osType",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "osType", headerTooltip: "OS Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "nmsArea", headerTooltip: "NMS Area",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Architecture Type", field: "architecture",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "architecture", headerTooltip: "Architecture Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
				},
			{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
		];
		return this.columnDefs;
  
	}
  
	public calculateRowCount() {
		if (this.gridOptions.api && this.rowData) {
			var model = this.gridOptions.api.getModel();
			var totalRows = this.rowData.length;
			var processedRows = model.getRowCount();
			this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
	}
	

	public onModelUpdated() {
		this.calculateRowCount();
	}

	public onReady(event) {
		this.calculateRowCount();
	}

	public containsObject(name, list) {
		let i;
		for (i = 0; i < list.length; i++ )
		{
			if (list[i].name == name)
			{
				return true;
			}
		}
		return false;
	}

	public onRowSelected($event) {

		this.excludedICs = [];
		this.includedICs = [];
		this.gridOptions.api.forEachNode( (node) => {
			
			if(!node.isSelected() && !this.containsObject(node.data.name, this.excludedICs)){
				this.excludedICs.push(node.data);
			}
			if(node.isSelected() && !this.containsObject(node.data.name, this.includedICs)){
				this.includedICs.push(node.data);
			}

		});
		let ICs = {
			"excludedICs": this.excludedICs,
			"includedICs": this.includedICs
		}
		this.emitStepDataOnChange(JSON.stringify(ICs));

	}

	public showICDetails(ICData){

		this.mode = "details";

		this.loadICDetails(ICData.name);

		/*
		this.selectedIC = ICData;
		this.logger.info("this.selectedIC", this.selectedIC);
		this.scripttext = atob(ICData.script);
		this.deviceForm.patchValue({'script': ICData.script});
		this.customCommands = ICData.collectionInfo;
		*/
	}

	public loadICDetails(ICName){

				this.loaderICDetails = true;

				let url = (<any>window).acConfig.getICDetailsAPI + ICName;
				this.apiService.getAPI(url, '').subscribe(
					data => {
		
						this.loaderICDetails = false;
						if(data.status == 200){
							
							this.selectedIC = data.json();
							console.log("this.selectedIC", this.selectedIC);
							//this.devices = [{"value": "Device 1", "name": "Device 1"}, {"value": "Device 2", "name": "Device 2"}, {"value": "Device 3", "name": "Device 3"}];
							this.customCommands = this.selectedIC.collectionInfo;
							this.deviceForm.patchValue({'script': this.selectedIC.script});
							this.scripttext = atob(this.selectedIC.script);
		
						}else{
		
							this.loaderICDetails = false;
							let alertMetaData = {
								"name": "viewic",
								"title" : "View IC",
								"type":"Error",
								"content": data.statusText
							}    
							this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);		
						}
						
		
					},
					err => {
						console.log("err", err);
						this.loaderICDetails = false;
						this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.VIEWIC').subscribe((res: string) => {
							let alertMetaData = {
								"name": "viewic",
								"title" : "View IC",
								"type":"Error",
								"content": res
							}    
							this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);			
						});
					}
					,() => {}
				);
				
		
	}

	resetScriptData(){
		this.scripttext = "";
		//this.scriptResult = [];
		this.deviceForm.patchValue({'device': '', 'script':''});
	}

	loadDevices(){

		this.resetScriptData();
		this.devices = [];
		this.devices = [{"value": "Device 1", "name": "Device 1"}, {"value": "Device 2", "name": "Device 2"}, {"value": "Device 3", "name": "Device 3"}];		

	}

	public ICSelectionChange(event, rowIndex){

		let target = event.target || event.srcElement || event.currentTarget;
		if(rowIndex == "all"){
			if(target.checked){
				this.gridOptions.api.selectAll();
			}else{
				this.gridOptions.api.deselectAll();
			}
		}else{
			var rowNode = this.gridOptions.api.getRowNode(rowIndex);
			if(rowNode != undefined){
				if(target.checked){
					rowNode.setSelected(true);
				}else{
					rowNode.setSelected(false);
				}
			}
		}
		
	}

	public showScriptTestResult(){
		
		this.scriptTestResult = "<show-status><server>10.106.211.174</server><type>CLI</type><command>show-status</command><rows><row><HostName>unity-cucm</HostName><Date>Mon Mar 6, 2017 13:26:26</Date><Locale>en_US.UTF-8</Locale><ProductVersion>10.5.1.10000-7</ProductVersion><TimeZone></TimeZone><PlatformtVersion></PlatformtVersion></row><row><MemTotal>8062644K</MemTotal><MemFree>222392K</MemFree><MemUsed>7840252K</MemUsed><MemCached>3854996K</MemCached><MemShared>0K</MemShared></row><row><Uptime> 13:26:27</Uptime><UpDays>73</UpDays><UpHours>3:58</UpHours><NumUsers>1</NumUsers><LoadAverage>1.00, 0.62, 0.31</LoadAverage><CpuIdle>87.82</CpuIdle><CpuSystem>06.09</CpuSystem><CpuUser>06.09</CpuUser><IOWait></IOWait><IRQ></IRQ></row></rows></show-status>";
		let dialog = this.dialogTestScript;
		dialog.width = "80%";
		dialog.height = "70%";
		dialog.showDialog();

	}

	public onCloseTestScriptPopup(){

	}

	public saveDeviceScript(){

	}

	public emitStepDataOnChange(data:any) {

		this.rulesStepData.emit(data);
		
	}

	onScriptChange(code) {
        this.logger.info("new code", code);
    }
		
}