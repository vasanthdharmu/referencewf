import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'assessment-root',
  templateUrl: './assessment.template.html',
  styleUrls: ['./assessment.style.css']  
})
export class AssessmentComponent {
  
  constructor(public router: Router) {
  
	
  } 
  
  ngOnInit() {	
	
	  
  }

}