import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule, JsonpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SmartbridgeClientAdapterModule } from "app/lib/partner/integration/angular/smartbridge-client-adapter";
import { AssessmentService } from './services/assessment.service';
import { XmlPipe } from './services/xml.pipe';

import { AuiModule } from 'aui/components/aui.module';
import { WorkflowManagerModule } from 'workflow-manager/workflowmanager.module';

import { AgGridModule } from 'ag-grid-angular';
import { WorkflowModule, workflowApi } from '@ssue-ui/cisco-workflow';

import { AssessmentRouting } from './assessment.routing';
import { AssessmentComponent } from './assessment.component';
import { AceEditorModule } from 'ng2-ace-editor';

import { DndListModule } from 'ngx-drag-and-drop-lists';

import { SSUEComponent } from './ssue/ssue.component';

import { InitiateAssessmentComponent } from './initiateassessment/initiateassessment.component';

import { BasicComponent } from './initiateassessment/basic/basic.component';
import { CollectorComponent } from './initiateassessment/collector/collector.component';
import { GridActionComponent } from './initiateassessment/collector/include-collection/gridaction.component';
import { ExcludeDataComponent } from './initiateassessment/collector/exclude-data/excludedata.component';
import { ExcludeCLIComponent } from './initiateassessment/collector/exclude-cli/excludecli.component';
import { IncludeCollectionComponent } from './initiateassessment/collector/include-collection/includecollection.component';
import { ConfirmComponent } from './initiateassessment/confirm/confirm.component';
import { ScheduleComponent } from './initiateassessment/schedule/schedule.component';
import { VerifyComponent } from './initiateassessment/verify/verify.component';

import { EditAssessmentComponent } from './editassessment/editassessment.component';
import { ListAssessmentComponent } from './listassessment/listassessment.component';
import { CloneProjectComponent } from './listassessment/cloneproject/cloneproject.component';
import { reportTableFilter } from './initiateassessment/report-filter.pipe';

import { EditProjectNameLinkComponent } from './listassessment/editprojectnamelink.component';
import { EditStatusLinkComponent } from './listassessment/editstatuslink.component';

import { ViewAssessmentComponent } from './viewassessment/viewassessment.component';

import { AnalysisComponent } from './analysis/analysis.component';
import { RulesComponent } from './analysis/rules/rules.component';
import { ICNameLinkComponent } from './analysis/rules/icnamelink.component';
import { DetailsComponent } from './analysis/details/details.component';
import { AnalysisConfirmComponent } from './analysis/analysisfinal/analysis.final.component';

import { FilterPipe } from './services/assessment.searchpipe';
import { ProjectLinkComponent } from './analysis/details/projectlink.component';

import { CreateICComponent } from './icmanager/createic/createic.component';
import { ICDetailsComponent } from './icmanager/createic/icdetails/icdetails.component';
import { CollectionDetailsComponent } from './icmanager/createic/collectiondetails/collectiondetails.component';
import { ICScriptComponent } from './icmanager/createic/icscript/icscript.component';
import { EditICComponent } from './icmanager/editic/editic.component';
import { AsPidLinkComponent } from './initiateassessment/basic/aspidlink.component';

import { ListICComponent } from './icmanager/listic/listic.component';
import { EditICNameLinkComponent } from './icmanager/listic/editicnamelink.component';
import { CloneICComponent } from './icmanager/cloneic/cloneic.component';

import { ListAssessmentTypesComponent } from './assessmenttypes/listassessmenttypes/listassessmenttypes.component';
import { AssessmentTypeNameLinkComponent } from './assessmenttypes/listassessmenttypes/assessmenttypenamelink.component';
import { ICCountFilterComponent } from './assessmenttypes/listassessmenttypes/iccountfilter.component';
import { ICCountFloatingFilterComponent } from './assessmenttypes/listassessmenttypes/iccountfloatingfilter.component';
import { ListICOfAssessmentComponent } from './assessmenttypes/listicofassessment/listicofassessment.component';
import { AssessmentICNameLinkComponent } from './assessmenttypes/listicofassessment/assessmenticnamelink.component';
import { CreateAssessmentTypeComponent } from './assessmenttypes/createassessmenttype/createassessmenttype.component';

import { AssessmentManagerComponent } from './assessmentmanager/assessmentmanager.component';
import { AssessmentTypeDetailsComponent } from './assessmenttypes/createassessmenttype/assessmenttypedetails/assessmenttypedetails.component';
import { AssessmentTypeConfirmComponent } from './assessmenttypes/createassessmenttype/assessmenttypeconfirm/assessmenttypeconfirm.component';
import { AssessmentTypeIcDetailsComponent } from './assessmenttypes/createassessmenttype/assessmenttypeicdetails/assessmenttypeicdetails.component';

import { ListPublicICsComponent } from './assessmenttypes/listpublicics/listpublicics.component';
import { ListAssessmentTypesPopupComponent } from './assessmenttypes/listassessmenttypespopup/listassessmenttypespopup.component';
import { AssessmentTypeNameLinkPopupComponent } from './assessmenttypes/listassessmenttypespopup/assessmenttypenamelinkpopup.component';
import { RemoveICLinkComponent } from './assessmenttypes/createassessmenttype/assessmenttypedetails/removeIC.component';

import { TestScriptComponent } from './testscript/testscript.component';
import { SsidConfigurationComponent } from './ssidconfiguration/ssidconfiguration.component';

@NgModule({
  imports: [
    CommonModule,
    AssessmentRouting,
    HttpModule,
	  FormsModule,
	  ReactiveFormsModule,
	  JsonpModule,
	  AgGridModule.withComponents([
      EditProjectNameLinkComponent,
      EditStatusLinkComponent,
      ICNameLinkComponent,
      EditICNameLinkComponent,
      AssessmentTypeNameLinkComponent,
      ICCountFilterComponent,
      ICCountFloatingFilterComponent,
      AssessmentICNameLinkComponent,
      AssessmentTypeNameLinkPopupComponent
	  ]),
    AuiModule,
    WorkflowManagerModule,
    SmartbridgeClientAdapterModule.forChild(),
    WorkflowModule,
    AceEditorModule,
    DndListModule
  ],
  declarations: [
    XmlPipe,
    AssessmentComponent,
    SSUEComponent,
    InitiateAssessmentComponent,
    EditAssessmentComponent,
    ListAssessmentComponent,
    EditProjectNameLinkComponent,
    EditStatusLinkComponent,
    BasicComponent,
    CollectorComponent,
    GridActionComponent,
    ExcludeDataComponent,
    ExcludeCLIComponent,
    IncludeCollectionComponent,
    ConfirmComponent,
    ScheduleComponent,
    VerifyComponent,
    reportTableFilter,
    ViewAssessmentComponent,
    AnalysisComponent,
    RulesComponent,
    ICNameLinkComponent,
    DetailsComponent,
    AnalysisConfirmComponent,
    FilterPipe,
    ProjectLinkComponent,
    CreateICComponent,
    ICDetailsComponent,
    CollectionDetailsComponent,
    ICScriptComponent,
    EditICComponent,
    AsPidLinkComponent,
    ListICComponent,
    EditICNameLinkComponent,
    CloneICComponent,
    ListAssessmentTypesComponent,
    AssessmentTypeNameLinkComponent,
    ICCountFilterComponent,
    ICCountFloatingFilterComponent,
    ListICOfAssessmentComponent,
    CloneProjectComponent,
    AssessmentICNameLinkComponent,
    CreateAssessmentTypeComponent,
    AssessmentManagerComponent,
    AssessmentTypeDetailsComponent,
    AssessmentTypeConfirmComponent,
    AssessmentTypeIcDetailsComponent,
    ListPublicICsComponent,
    ListAssessmentTypesPopupComponent,
    AssessmentTypeNameLinkPopupComponent,
    RemoveICLinkComponent,
    TestScriptComponent,
    SsidConfigurationComponent
  ],
  providers: [
    AssessmentService,
    workflowApi
  ],
  entryComponents: [
        ProjectLinkComponent,
        AsPidLinkComponent,
        GridActionComponent,
        RemoveICLinkComponent
   ],
  bootstrap: [ AssessmentComponent ]
})
export class AssessmentModule {
}