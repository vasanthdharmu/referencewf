import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssessmentComponent } from './assessment.component';

import { InitiateAssessmentComponent } from './initiateassessment/initiateassessment.component';
import { EditAssessmentComponent } from './editassessment/editassessment.component';
import { ViewAssessmentComponent } from './viewassessment/viewassessment.component';
import { SSUEComponent } from './ssue/ssue.component';

import { AnalysisComponent } from './analysis/analysis.component';
import { CreateICComponent } from './icmanager/createic/createic.component';
import { EditICComponent } from './icmanager/editic/editic.component';
import { CloneICComponent } from './icmanager/cloneic/cloneic.component';
import { ListAssessmentComponent } from './listassessment/listassessment.component';
import { ListICComponent } from './icmanager/listic/listic.component';

import { ListAssessmentTypesComponent } from './assessmenttypes/listassessmenttypes/listassessmenttypes.component';
import { ListICOfAssessmentComponent } from './assessmenttypes/listicofassessment/listicofassessment.component';
import { CreateAssessmentTypeComponent } from './assessmenttypes/createassessmenttype/createassessmenttype.component';

import { AssessmentManagerComponent } from './assessmentmanager/assessmentmanager.component';
import { CloneProjectComponent } from './listassessment/cloneproject/cloneproject.component';

import { TestScriptComponent } from './testscript/testscript.component';
import { SsidConfigurationComponent } from './ssidconfiguration/ssidconfiguration.component';

const routes: Routes = [
  {
	path: '', component: AssessmentComponent,
    children: [
      { path: 'initiate', component: InitiateAssessmentComponent  },
      { path: 'edit', component: EditAssessmentComponent  },
      { path: 'cloneproject', component: CloneProjectComponent  },
      { path: 'ssue', component: SSUEComponent  },
      { path: 'view', component: ViewAssessmentComponent  },
      { path: 'analysis', component: AnalysisComponent  },
      { path: 'createic', component: CreateICComponent  },
      { path: 'editic', component: EditICComponent  },
      { path: 'list', component: ListAssessmentComponent  },
      { path: 'listic', component: ListICComponent  },
      { path: 'cloneic', component: CloneICComponent  },
      { path: 'listassessmenttypes', component: ListAssessmentTypesComponent  },
      { path: 'listicofassessment', component: ListICOfAssessmentComponent  },
      { path: 'createassessmenttype', component: CreateAssessmentTypeComponent  },
      { path: 'assessmentmanager', component: AssessmentManagerComponent  },
      { path: 'testscript', component: TestScriptComponent  },
      { path: 'ssidconfiguration', component: SsidConfigurationComponent  }
    ]
  }
];

export const AssessmentRouting: ModuleWithProviders = RouterModule.forChild(routes);
