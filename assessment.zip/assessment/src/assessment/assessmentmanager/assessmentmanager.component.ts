import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

@Component({
  selector: 'assessment-manager',
  templateUrl: './assessmentmanager.template.html',
  styleUrls: [ './assessmentmanager.style.css' ],
  encapsulation: ViewEncapsulation.None,
})
export class AssessmentManagerComponent {  

    constructor(public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {
        
    }

}