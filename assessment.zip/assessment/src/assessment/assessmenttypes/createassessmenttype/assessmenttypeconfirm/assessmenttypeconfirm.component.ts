import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

@Component({
    selector: 'assessment-confirm',
    templateUrl: './assessmenttypeconfirm.template.html',
    styleUrls: ['./assessmenttypeconfirm.style.css']
})

export class AssessmentTypeConfirmComponent implements OnInit {

    public assessmentConfirmForm: FormGroup;
    public allstepData: any;
    public step1Data: any;
    public ste2Data: any;
    public isSubmit: boolean;
    public gridOptionsIC: GridOptions;
    public rowData: any[];
    public selectedNodesLength: any;
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;
    public showToolPanel: any;
    @Output() confirmStepData: EventEmitter<any> = new EventEmitter();

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    }

    ngOnInit() { 
        this.registerToSSUEApi();
        this.loadBasicForm();
        this.gridOptionsIC = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            rowModelType: 'infinite',
            columnDefs: this.createICColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no selected IC(s)</span>',
            overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>',
        };
    }
    loadBasicForm() {
        this.assessmentConfirmForm = new FormGroup({
            'name': new FormControl(''),
            'description': new FormControl(''),
            'visibility': new FormControl('')
        });
    }

    public emitStepDataOnChange(data: any) {
        this.confirmStepData.emit(data);
    }

    public registerToSSUEApi() {

        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                console.log("allStepsData", response);
                this.allstepData = response.allStepsData;
                this.step1Data = JSON.parse(this.allstepData.step1);
                this.ste2Data = this.allstepData.step2 ? JSON.parse(this.allstepData.step2) : null;
                console.log(this.step1Data);
                console.log(this.ste2Data);
                this.gridOptionsIC.api.setRowData(this.ste2Data);
                this.gridOptionsIC.api.hideOverlay();
                this.gridOptionsIC.api.sizeColumnsToFit();
            });

    }
    public createICColumnDefs() {
        let columnDefs = [
            {
                headerName: "IC Name", field: "name", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "IC Name", headerTooltip: "IC Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Architecture Type", field: "architecture", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Architecture Type", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Feature", field: "feature", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Feature", headerTooltip: "Feature",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "OS", field: "osType", width: 100, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "OS", headerTooltip: "OS",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Visibility", field: "visibility", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Visibility", headerTooltip: "Visibility",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            }
        ];
        return columnDefs;
    }
    public calculateRowCount() {
        if (this.gridOptionsIC.api && this.rowData) {
            var model = this.gridOptionsIC.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }
    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }

}