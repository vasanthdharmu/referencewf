import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

@Component({
    selector: 'assessment-basicdetails',
    templateUrl: './assessmenttypedetails.template.html',
    styleUrls: ['./assessmenttypedetails.style.css']
})

export class AssessmentTypeDetailsComponent implements OnInit {

    public assessmentTypeBasicForm: FormGroup;
    public formelements: any;
    public assessmentData: any = {};
    public formComplete: boolean = false;
    public icDuplicate: boolean = false;
    public allstepData: any;
    public step1Data: any;
    public show: boolean = true;
    public isError: boolean = false;
    public errorMessage: String = "";
    public visibilityList = [{ "value": "Public", "name": "Public", "selected": true }, { "value": "Private", "name": "Private" }];
    @Output() AssessmentDetailsStepData: EventEmitter<any> = new EventEmitter();

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
        this.registerToSSUEApi();
    }

    ngOnInit() {
        this.assessmentData.visibility = "public";
        this.loadBasicForm();
    }

    loadBasicForm() {
        this.assessmentTypeBasicForm = new FormGroup({
            'name': new FormControl('', Validators.required),
            'description': new FormControl(''),
            'contributor': new FormControl(this.appService.get("cecID")),
            'visibility': new FormControl('')
        });
    }

    public emitStepDataOnChange(data: any) {
        this.AssessmentDetailsStepData.emit(data);
    }

    public toggle() {
        this.show = !this.show;
        if (this.show) {
            this.assessmentData.visibility = "public";
        }
        else {
            this.assessmentData.visibility = "private";
        }
        this.isValidated();
    }

    selectChange(formControlName, formControlField) {
        this.assessmentTypeBasicForm.patchValue({ [formControlName]: formControlField.value });
        this.assessmentData[formControlName] = this.assessmentTypeBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    setValue(formControlName) {
        this.assessmentData[formControlName] = this.assessmentTypeBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    isValidated() {
        if (this.assessmentTypeBasicForm.valid && !this.isError) {
            this.emitStepDataOnChange(JSON.stringify(this.assessmentData));
            this.formComplete = true;
        }
        else {
            this.emitStepDataOnChange(false);
            this.formComplete = false;
        }
    }


    checkAssessmentName(formControlName) {
        this.isError = false;
        this.errorMessage ="";
        var name = this.assessmentTypeBasicForm.controls[formControlName].value.trim();
        if (name != "" && name.length < 3) {
            this.isError = true;
            this.errorMessage = "Assessment Type should have min 3 letters";
            this.isValidated();
        }
        else if (/^[a-zA-Z0-9- _]*$/.test(name)) {
            var firstChar = this.assessmentTypeBasicForm.controls[formControlName].value.charAt(0);
            if ("-,".indexOf(firstChar) != -1) {
                this.isError = true;
                this.errorMessage = "Assessment Type should started with letters or digits or _";
            }
            else {
                let url = (<any>window).acConfig.getCatalogDetailsAPI + this.assessmentTypeBasicForm.controls[formControlName].value;
                url = encodeURI(url);
                this.apiService.getAPI(url, '').subscribe(
                    data => {
                        
                        if (data.status == 200) {
                            this.isError = true;
                            this.errorMessage = "Assessment Type already exist.";
                        }
                        else{
                            this.isError = false;
                            this.errorMessage = "";
                        }
                        this.isValidated();
                    },
                    err => {
                        if (err.status == 404) {
                            this.isError = false;
                            this.errorMessage = "";
                        }
                        else{
                            this.isError = true;
                            this.errorMessage = "Invalid Assessment Type";
                        }                       
                        this.isValidated();
                    }
                    , () => { }
                );
            }
        }
        else {
            this.isError = true;
            this.errorMessage = "Assessment Type can contain only letters, digits, _ , - and space";
            this.isValidated();
        }
    }

    public registerToSSUEApi() {
        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                this.allstepData = response.allStepsData;
                this.step1Data = JSON.parse(this.allstepData.step1);
                this.updateForm(this.step1Data);
            });
    }

    updateForm(formData) {
        this.assessmentTypeBasicForm.patchValue({ 'name': formData.name });
        this.assessmentTypeBasicForm.patchValue({ 'description': formData.description });
        this.assessmentTypeBasicForm.patchValue({ 'visibility': formData.visibility });
    }
}