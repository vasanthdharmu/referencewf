import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'remove-ic-link',
    template: `<a (click)="removeIC()" class="icon-trash"></a>`
})

export class RemoveICLinkComponent implements ICellRendererAngularComp  {
    public params: any;
    constructor(public router: Router) {    
    }
    agInit(params: any): void {
        this.params = params;
    }
    refresh(): boolean {
        return false;
    }
    public removeIC() {
        this.params.context.componentParent.removeIC(this.params.data);
    }
}