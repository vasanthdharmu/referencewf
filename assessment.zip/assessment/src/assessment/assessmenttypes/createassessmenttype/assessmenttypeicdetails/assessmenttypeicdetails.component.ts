import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { RemoveICLinkComponent } from 'assessment/assessmenttypes/createassessmenttype/assessmenttypedetails/removeIC.component';


@Component({
    selector: 'assessment-ic-details',
    templateUrl: './assessmenttypeicdetails.template.html',
    styleUrls: ['./assessmenttypeicdetails.style.css'],
    entryComponents: [RemoveICLinkComponent],
})

export class AssessmentTypeIcDetailsComponent implements OnInit {

    public gridOptions: GridOptions;
    public gridOptionsIC: GridOptions;
    public rowData: any[];
    public selectedNodesLength: any;
    public removeDisable: boolean = false;
    public showIc = false;
    public icList = [];
    public showActions = false;
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;
    public showToolPanel: any;
    @ViewChild('dialogICList') dialogICList;
    @Output() icDetailsStepData: EventEmitter<any> = new EventEmitter();

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
        this.registerToSSUEApi();
    }

    ngOnInit() {
        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            rowModelType: 'infinite',
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no IC(s)</span>',
            overlayLoadingTemplate: '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>',
        };
        this.getICList();
        this.gridOptionsIC = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            rowModelType: 'infinite',
            columnDefs: this.createICColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no selected IC(s)</span>',
            overlayLoadingTemplate: '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>',
        };
    }

    public emitStepDataOnChange(data: any) {
        this.icDetailsStepData.emit(data);
    }

    public registerToSSUEApi() {
        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                //console.log("allStepsData", response);
            });

    }

    public addIC() {
        let dialog = this.dialogICList;
        dialog.width = "75%";
        dialog.height = "98%";
        dialog.showDialog();
        this.showActions = false;
        this.gridOptions.api.forEachNode( (node) => {
            if ( this.icList.indexOf(node.data) != -1 ) {
                node.setSelected(true);
            }else{
                node.setSelected(false);
            }
        });
    }

    public close() {
        let dialog = this.dialogICList;
        dialog.cancelAction();
    }

    public createColumnDefs() {
        let columnDefs = [
            {
                headerName: "",
                field: "selectAllIC",
                width: 50,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                checkboxSelection: true,
                pinned: true,
                suppressFilter: true
            },
            {
                headerName: "IC Name", field: "name", width: 275, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "IC Name", headerTooltip: "IC Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Architecture Type", field: "architecture", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Architecture Type", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Feature", field: "feature", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Feature", headerTooltip: "Feature",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "OS", field: "osType", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "OS", headerTooltip: "OS",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            }
        ];
        return columnDefs;
    }
    public createICColumnDefs() {
        let columnDefs = [
            {
                headerName: "",
                field: "selectAllIC",
                width: 50,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                checkboxSelection: true,
                pinned: true,
                suppressFilter: true
            },
            {
                headerName: "IC Name", field: "name", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "IC Name", headerTooltip: "IC Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Architecture Type", field: "architecture", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Architecture Type", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Feature", field: "feature", width: 200, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Feature", headerTooltip: "Feature",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "OS", field: "osType", width: 100, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "OS", headerTooltip: "OS",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Visibility", field: "visibility", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "Visibility", headerTooltip: "Visibility",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "", width: 50, cellRendererFramework: RemoveICLinkComponent, pinned: true,
                tooltipField: "Delete", headerTooltip: "Delete",
            },
        ];
        return columnDefs;
    }

    getICList() {
        let url = (<any>window).acConfig.getUserICListAPI; // api call for loading pop up project list
        this.apiService.getUrl(url, '').subscribe(
            data => {
                this.logger.info("ic list", data);
                this.gridOptions.api.setRowData(data);
                this.gridOptions.api.hideOverlay();
                this.gridOptions.api.sizeColumnsToFit();
            },
            err => console.error(err)
            , () => { }
        );

    }
    public onRowSelected($event) {
        let selectedNodes = this.gridOptions.api.getSelectedNodes();
        if (selectedNodes.length > 0) {
            this.showIc = true;
        }
        else {
            this.showIc = false;
        }

    }
    public onRowSelectedIC($event) {
        this.removeDisable = false;
        let selectedNodes = this.gridOptionsIC.api.getSelectedNodes();
        if (selectedNodes.length > 0) {
            this.removeDisable = true;
        }
    }

    public addSelectedIC() {
        let gridData = this.gridOptions.api.getSelectedNodes();
        if (gridData.length > 0) {
            this.icList.length = 0;
            gridData.forEach(ic => {
                this.icList.push(ic.data);
            });
            this.gridOptionsIC.api.setRowData(this.icList);
            this.gridOptionsIC.api.hideOverlay();
            this.gridOptionsIC.api.sizeColumnsToFit();
            this.close();
            this.emitICStepData(JSON.stringify(this.icList));
        }
        else {
            this.icList.length = 0;
            this.gridOptionsIC.api.setRowData(this.icList);
            this.gridOptionsIC.api.hideOverlay();
            this.gridOptionsIC.api.sizeColumnsToFit();
            this.close();
            this.emitICStepData(false);
        }
    }
    public emitICStepData(data: any) {
        this.icDetailsStepData.emit(data);
    }
    public calculateRowCount() {
        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }
    public removeIC(data) {
        let index = this.icList.indexOf(data);
        if (index > -1) {
            this.icList.splice(index, 1);
        }
        this.gridOptionsIC.api.setRowData(this.icList);
        this.gridOptionsIC.api.hideOverlay();
        this.gridOptionsIC.api.sizeColumnsToFit();
        this.gridOptionsIC.api.refreshCells();
        this.emitICStepData(JSON.stringify(this.icList));
    }
    public removeIc() {
        let selectedNodes = this.gridOptionsIC.api.getSelectedNodes();
        selectedNodes.forEach(ic => {
            this.removeIC(ic.data);
        });
        this.removeDisable = false;
    }
}