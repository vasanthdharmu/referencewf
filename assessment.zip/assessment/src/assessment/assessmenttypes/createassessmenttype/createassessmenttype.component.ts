import { Component, ViewChild, Input, ElementRef } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { TranslateService } from 'ng2-translate';

@Component({
    selector: 'create-assessment-type',
    styleUrls: ['./createassessmenttype.style.css'],
    templateUrl: './createassessmenttype.template.html'
})
export class CreateAssessmentTypeComponent {

    public AssessmentDetailsStepData: any;
    public confirmStepData: any;
    public AssessmentDetailsData: boolean = false;
    public enableConfirmStep: boolean = false;
    public icDetailsStepData: any;
    public isSubmit: boolean = false;
    private subscriptionConfirm: ISubscription;
    constructor(public translate: TranslateService, public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
        (<any>window).localStorage.clear();
        (<any>window).sessionStorage.clear();
        this.registerToSSUEApi();
    }

    ngOnInit() {

    }

    ngOnDestroy() {
		this.subscriptionConfirm.unsubscribe();
	}

    setAssessmentDetailsStepData(data) {
        if (!data) {
            this.AssessmentDetailsData = data;
        }
        else {
            this.AssessmentDetailsStepData = data;
            this.AssessmentDetailsData = true;
        }
        this.setConfirmStepData(this.confirmStepData);
    }

    setIcDetailsStepData(data) {
        this.icDetailsStepData = data;
        this.enableConfirmStep = false;
        if (JSON.parse(this.icDetailsStepData).length > 0) {
            this.enableConfirmStep = true;
        }
        this.setConfirmStepData(this.confirmStepData);
    }

    setConfirmStepData(data) {
        if (data != null && data.length > 0 && this.AssessmentDetailsData && this.enableConfirmStep) {
            this.isSubmit = true;
            this.confirmStepData = data;
        }
        else {
            this.isSubmit = false;
        }

    }
    public registerToSSUEApi() {
        this.workflowapi.registerEvent('onCancel')
            .subscribe((response: any) => {
                this.assessmentService.backtoSSUE("CFAssessment:ICManager");
                this.workflowapi.clearStorage();
            });

         this.subscriptionConfirm = this.workflowapi.registerEvent('onConfirm')
            .subscribe((response: any) => {

                let responsedata = response.payload;
                let assessmentTypeData: any;

                if (responsedata != null && responsedata.step1 != null && responsedata.step2 != null) {
                    assessmentTypeData = { "catalog": JSON.parse(responsedata.step1) };
                    let icData = JSON.parse(responsedata.step2);
                    let icName = [];
                    icData.forEach(ic => {
                        icName.push(ic.name);
                    });
                    assessmentTypeData.catalog["icSubset"] = icName;
                    assessmentTypeData.catalog["icSubset_tag"] = "ic";
                    assessmentTypeData.catalog["status"] = "active";
                    console.log(assessmentTypeData);
                    this.saveAssessmentType(assessmentTypeData);
                }
                else {
                    this.translate.get('NOTIFICATIONFAILURE.CLONEPROJECT.MANDATORY').subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "errorcreateIC",
                            "title": "Mandatory fields",
                            "type": "INFO",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });

                }
            });
    }

    public saveAssessmentType(postData) {
        this.apiService.postUrl((<any>window).acConfig.postAssessmentTypeAPI, JSON.stringify(postData)).subscribe(
            (result) => {
                let respData = result.json();
                if (result.status === 200) {
                    this.translate.get('NOTIFICATIONSUCCESS.ASSESSMENTTYPE.CREATED',{assessmenttypename:respData.name}).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "createAssessment",
                            "title": "Create Assessment",
                            "type": "SUCCESS",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:ICManager"); 
                    this.workflowapi.clearStorage();
                    (<any>window).localStorage.clear();
                    (<any>window).sessionStorage.clear();
                }
                else {
                    this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPE.SAVEERROR').subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "createAssessmentTypeFailure",
                            "title": "Error on assessment type creation",
                            "type": "DANGER",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                }
            },
            (err) => {
                let errinfo = err.json();
                this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPE.SAVEERROR').subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "errorcreateAssessmentType",
                        "title": "Error on assessment type creation",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });

            });

    }

}