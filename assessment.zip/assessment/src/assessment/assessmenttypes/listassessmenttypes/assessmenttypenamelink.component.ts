import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'edit-assessment-user',
    template: `<a (click)="gotoLink()">{{ params.data.name.split("-").join(" ") }}</a>`
})

export class AssessmentTypeNameLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {    
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {
        
        let link = '/assessment/ssue?operation=editassessmenttype&AssessmentTypeName=' + this.params.data.name;
        this.router.navigateByUrl(link);   
        
    }
}