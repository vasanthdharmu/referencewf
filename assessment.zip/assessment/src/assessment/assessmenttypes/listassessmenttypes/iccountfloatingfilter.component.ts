import {AfterViewInit, Component} from "@angular/core";

import {IFloatingFilter, IFloatingFilterParams, SerializedNumberFilter} from "ag-grid";
import {AgFrameworkComponent} from "ag-grid-angular";

export interface ICCountFloatingFilterChange {
    model: SerializedNumberFilter
}

export interface ICCountFloatingFilterParams extends IFloatingFilterParams<SerializedNumberFilter, ICCountFloatingFilterChange> {
    value: number
}

@Component({
    template: `
        <input type="text" [(ngModel)]="currentValue" (ngModelChange)="valueChanged()" class="ag-floating-filter-input" style="padding-top: 7px;"/>`
})
export class ICCountFloatingFilterComponent implements IFloatingFilter<SerializedNumberFilter, ICCountFloatingFilterChange, ICCountFloatingFilterParams>, AgFrameworkComponent<ICCountFloatingFilterParams>, AfterViewInit {
    private params: ICCountFloatingFilterParams;
    public currentValue: number;

    agInit(params: ICCountFloatingFilterParams): void {
        this.params = params;
        this.currentValue = 0;
    }

    valueChanged() {
        this.params.onFloatingFilterChanged({model: this.buildModel()});
        //this.params.onFloatingFilterChanged()
    }

    ngAfterViewInit(): void {
        this.valueChanged();
    }

    onParentModelChanged(parentModel: SerializedNumberFilter): void {
        if (!parentModel) {
            this.currentValue = 0;
        } else {
            this.currentValue = parentModel.filter
        }
    }

    buildModel(): SerializedNumberFilter {
        if (this.currentValue === 0) {
            return null;
        }
        return {
            filterType: 'number',
            type: 'equals',
            filter: this.currentValue,
            filterTo: null
        };
    }
}