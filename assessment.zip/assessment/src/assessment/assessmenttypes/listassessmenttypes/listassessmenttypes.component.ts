import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router, NavigationEnd } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { AssessmentTypeNameLinkComponent } from 'assessment/assessmenttypes/listassessmenttypes/assessmenttypenamelink.component';
//import { ICCountFilterComponent } from 'assessment/assessmenttypes/listassessmenttypes/iccountfilter.component';
//import { ICCountFloatingFilterComponent } from 'assessment/assessmenttypes/listassessmenttypes/iccountfloatingfilter.component';

@Component({
  selector: 'list-assessment-types',
  templateUrl: './listassessmenttypes.template.html',
  styleUrls: [ './listassessmenttypes.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class ListAssessmentTypesComponent {  

  public selectedNodesLength:any;

  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public showActions: any;

	constructor(public datePipe: DatePipe,public translate: TranslateService, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {
			
	}

  	ngOnInit(){
		
		this.gridOptions = <GridOptions>{
			context: {
                componentParent: this
			},
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no Assessment types</span>',
			overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'		
		}; 

		this.getAssessmentTypeList();
	
  	}


	public onRowSelected($event) {

		let selectedNodes = this.gridOptions.api.getSelectedNodes();	
		this.selectedNodesLength = selectedNodes.length;

	}


	deleteAssessmentType(){
		
		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		let name = [];
		let status = [];
		for (let node of selectedNodes){
			name.push(node.data.name);
			status.push(node.data.visibility);
		}
		let deleteLink = '/assessment/ssue?operation=deleteassessmenttype&name=' + name.join("|") + '&visibility=' + status.join("|");		
		this.router.navigateByUrl(deleteLink);

	}
	  
	getAssessmentTypeList(){		

		let url = (<any>window).acConfig.getAssessmentTypeListAPI;

		this.apiService.getAPI(url, '').subscribe(
			result => {

				if (result.status === 200) {					
					let respData = result.json();
					if(respData.length > 0){
						this.logger.info("assessment type list", respData);
						this.gridOptions.api.setRowData(respData);
						this.gridOptions.api.hideOverlay();
						this.gridOptions.api.sizeColumnsToFit();
					}else{
						this.gridOptions.api.setRowData([]);
						this.gridOptions.api.showNoRowsOverlay();
					}
				}else{
					this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPE.GETLISTERROR',{detail:result.statusText}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "listassessmenttypefailure",
							"title": "List Assessment type Failure",
							"type": "INFO",
							"content": res
						}
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					})
					this.gridOptions.api.setRowData([]);
					this.gridOptions.api.showNoRowsOverlay();
				}

			},
			err => {
				this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPE.GETLISTERROR',{detail:err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "listassessmenttypefailure",
						"title": "List Tssessment type Failure",
						"type": "INFO",
						"content": res
					}
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.gridOptions.api.setRowData([]);
				this.gridOptions.api.showNoRowsOverlay();
			}
			,() => {}
		);

	}  
  
  	public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectAllAssessmentTypes",
				width: 50,
				headerCheckboxSelection: false,
				headerCheckboxSelectionFilteredOnly: false,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},            			
			{headerName: "Name", field: "name",width: 200, sortingOrder: ['asc','desc'], cellRendererFramework:AssessmentTypeNameLinkComponent, comparator: this.stringComparator, pinned: true,
				tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "IC Count", field: "icSubset",width: 150, sortingOrder: ['asc','desc'], 
				cellRenderer:this.formatICubset, comparator: this.numberComparator, suppressFilter: true, pinned: true, 
				tooltipField: "icSubset", headerTooltip: "No Of IC’s",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Created By", field: "owner",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "owner", headerTooltip: "Created By",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Visibility", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Created Date", field: "created",width: 200, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},			
			{headerName: "Modified Date", field: "updated",width: 200, pinned: true,
				tooltipField: "updated", headerTooltip: "Modified Date", suppressSorting: true
			}
			/*
			,{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}*/
		];
		return this.columnDefs;

	}

	public numberComparator(valueA, valueB, nodeA, nodeB, isInverted) {
			if ((valueA === null && valueB === null) || (valueA === undefined && valueB === undefined)) {
				return 0;
			}		
			if (valueA === null) {
				return -1;
			}
			if (valueB === null) {
				return 1;
			}
		
			return valueA.length - valueB.length;
	}

	public stringComparator(valueA: any, valueB: any, nodeA: any, nodeB: any, isInverted: any) {
		if ((valueA === null && valueB === null) || (valueA === undefined && valueB === undefined)) {
			return 0;
		}
	
		if (valueA === null || valueA === undefined) {
			return -1;
		}
		if (valueB === null || valueB === undefined) {
			return 1;
		}
	
		var upperValueA = valueA.toUpperCase();
		var upperValueB = valueB.toUpperCase();
		return upperValueA === upperValueB ? 0 : (upperValueA > upperValueB) ? 1 : -1;
	}

	public formatCreatedDate(params){

		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.created, 'yMMMdjms');

	}

	public formatModifiedDate(params){
		
		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.updated, 'yMMMdjms');

	}

	public formatICubset(params){
		
		return parseInt(params.data.icSubset.length);

	}

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
		
    }	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
		this.calculateRowCount();
	}
	
}