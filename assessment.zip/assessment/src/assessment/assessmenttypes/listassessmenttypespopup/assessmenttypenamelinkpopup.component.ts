import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'assessment-type-popup',
    template: `<a (click)="gotoLink()">{{ params.data.name }}</a>`
})

export class AssessmentTypeNameLinkPopupComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {    
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {
        
        this.params.context.componentParent.getICList(this.params.data.name);

    }
}