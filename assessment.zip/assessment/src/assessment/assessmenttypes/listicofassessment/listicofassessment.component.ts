import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { FusionAlert } from 'aui/components/notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from 'aui/components/notification-alert/alertanchor.directive';

import { AssessmentICNameLinkComponent } from 'assessment/assessmenttypes/listicofassessment/assessmenticnamelink.component';

@Component({
  selector: 'list-ic-of-assessment',
  templateUrl: './listicofassessment.template.html',
  styleUrls: [ './listicofassessment.style.css' ],
  encapsulation: ViewEncapsulation.None,
  entryComponents: [ FusionAlert ],
  providers: [ DatePipe ]
})
export class ListICOfAssessmentComponent {  

  public selectedNodesLength:any;

  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public loaderSaveButton: boolean = false;

  public showActions: any;
  public assessmentTypeName: string = "";
  public assessmentTypeDetails: any = "";
  public icListOfAssessment: any = [];
  public icListSelected: any = [];
  public icListSelectedToRemove: any = [];
  @ViewChild('dialogPublicICList') dialogPublicICList;
  @ViewChild('dialogAssessmentTypeList') dialogAssessmentTypeList;

  @ViewChild(AlertAnchorDirective) alertAnchor;
  @ViewChild('deletefusionalert') deletefusionalert:ElementRef;

	constructor(public translate: TranslateService, public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {
			
	}

  	ngOnInit(){
		
		this.gridOptions = <GridOptions>{
			context: {
                componentParent: this
            },
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no ICs</span>',
			overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'		
		};

		let params = new URLSearchParams(window.location.search);
        this.assessmentTypeName = decodeURIComponent(params.get('AssessmentTypeName'));
		this.getICList(this.assessmentTypeName);
	
  	}


	public onRowSelected($event) {

		this.icListSelected = [];
		this.icListSelectedToRemove = [];
		let selectedNodes = this.gridOptions.api.getSelectedNodes();	
		this.selectedNodesLength = selectedNodes.length;
		this.gridOptions.api.forEachNode( (node) => {
			if(!node.isSelected() && !this.containsObject(node.data.name, this.icListSelected)){
				this.icListSelected.push(node);
			}
			if(node.isSelected() && !this.containsObject(node.data.name, this.icListSelectedToRemove)){
				this.icListSelectedToRemove.push(node);
			}
		});

	}

	public containsObject(name, list) {
		let i;
		for (i = 0; i < list.length; i++ )
		{
			if (list[i].name == name)
			{
				return true;
			}
		}
		return false;
	}
	  
	getICList(assessmentTypeName){

		if(assessmentTypeName != ""){

			let url = (<any>window).acConfig.getCatalogDetailsAPI + assessmentTypeName;

			this.apiService.getAPI(url, '').subscribe(
				result => {

					if (result.status === 200) {

						let respData = result.json();
						this.assessmentTypeDetails = respData;
						if(respData.icSubset.length > 0){
							
							this.icListOfAssessment = Object.assign({}, respData.icSubset);
							this.loadICs(respData.icSubset);							

						}else{
							this.loadICGrid([]);
						}

					}else{
						this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.ICLOADING',{issue:result.statusText}).subscribe((res: string) => {
							let alertMetaData = {
								"name": "listicofassessmentfailure",
								"title": "List IC of Assessment Failure",
								"type": "INFO",
								"content": res
							}
							this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
						});
						this.loadICGrid([]);

					}

				},
				err => {
					this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.ICLOADING',{issue:err._body}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "listicofassessmentfailure",
							"title": "List IC of Assessment Failure",
							"type": "INFO",
							"content": res
						}
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.loadICGrid([]);

				}
				,() => {}
			);
			
		}

	}  

	public loadICs(icList){
		
		this.gridOptions.api.showLoadingOverlay();
		let url = (<any>window).acConfig.getICListAPI;
		let body = [
				{
					"attribute":"name",
					"value": icList
				}
			];

		this.apiService.postUrl(url, body).subscribe(
			result => {

				if (result.status === 200) {
					let respData = result.json();
					this.loadICGrid(respData);
				}else{
					this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.ICLOADING',{issue:result.statusText}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "listicofassessmentfailure",
						"title" : "List IC of Assessment Failure",
						"type":"DANGER",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
					this.loadICGrid([]);
				}

			},
			err => {
				this.translate.get('NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.ICLOADING',{issue:err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "listicofassessmentfailure",
						"title" : "List IC of Assessment Failure",
						"type":"DANGER",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.loadICGrid([]);
			}
			,() => {}
		);

	}

	public loadICGrid(data){
		
		if(data.length > 0){

			this.gridOptions.api.setRowData(data);
			this.icListSelected = data;
			//this.icListSelected = Object.assign({}, data);
			this.gridOptions.api.hideOverlay();
			this.gridOptions.api.sizeColumnsToFit();

		}else{

			this.gridOptions.api.setRowData([]);
			this.gridOptions.api.showNoRowsOverlay();

		}

	}

	onUpdateAssessmentType(purpose){

		this.loaderSaveButton = true;
		let icSubset = [];
		this.icListSelected.forEach(ic => {
			icSubset.push(ic.data.name);
		});			
		let deleteICubset = [];
		this.icListSelectedToRemove.forEach(ic => {
			deleteICubset.push(ic.data.name);
		});
		this.updateAssessmentType(icSubset, deleteICubset, purpose, '');

	}

	updateAssessmentType(icSubset, deleteICubset, purpose, assessmentType){

		let postData ={
			"catalog":{
				"add_ic" : icSubset,   
				"delete_ic" : deleteICubset
			}
		};

		// let successmessage = "Sucessfully Updated IC(s) to your Assesment Type " + this.assessmentTypeName;
		// let failuremessage = "Problem with updating ICs to your Assessment type " + this.assessmentTypeName;
		var messagepropsuccess="NOTIFICATIONSUCCESS.ASSESSMENTTYPEPOPUP.UPDATED";
		var messagepropfailure="NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.UPDATED";
		var assessmenttype_name=this.assessmentTypeName;
		
		let url = (<any>window).acConfig.putAssessmentTypeAPI + this.assessmentTypeName;
		this.apiService.putUrl(url, JSON.stringify(postData)).subscribe(
			result => {
				if (result.status === 200) {					
					
					let respData = result.json();
					this.icListOfAssessment = Object.assign({}, respData.icSubset);
					//this.loadICs(respData.icSubset);
					this.getICList(this.assessmentTypeName);
					this.onCancelICSelection();
					
					switch(purpose){
						case "add":
							messagepropsuccess="NOTIFICATIONSUCCESS.ASSESSMENTTYPEPOPUP.ADD";
							messagepropfailure="NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.ADD";
							assessmenttype_name=this.assessmentTypeName;
							
							// successmessage = "Sucessfully added IC(s) to your Assesment Type " + this.assessmentTypeName;
							// failuremessage = "Problem with adding ICs to your Assessment type " + this.assessmentTypeName;
							  break;
						case "delete":
							messagepropsuccess="NOTIFICATIONSUCCESS.ASSESSMENTTYPEPOPUP.DELETE";
							messagepropfailure="NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.DELETE";
							assessmenttype_name=this.assessmentTypeName;

							// successmessage = "Sucessfully deleted IC(s) from your Assesment Type " + this.assessmentTypeName;
							// failuremessage = "Problem with deleting ICs from your Assessment type " + this.assessmentTypeName;
							break;
						case "import":
							messagepropsuccess="NOTIFICATIONSUCCESS.ASSESSMENTTYPEPOPUP.IMPORT";
							messagepropfailure="NOTIFICATIONFAILURE.ASSESSMENTTYPEPOPUP.IMPORT";
							assessmenttype_name=assessmentType;
							
							// successmessage = "Sucessfully imported IC(s) from selected Assesment Type " + assessmentType;
							// failuremessage = "Problem with importing ICs from selected Assesment Type " + assessmentType;
							break;		  
					}
					this.translate.get(messagepropsuccess,{assessmentdata:assessmentType}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "updateassessmentype",
							"title": "Update Assessment Type Success",
							"type": "SUCCESS",						
							"content": res
						}
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);					
					});
					this.loaderSaveButton = false;

				} else {

					this.onCancelICSelection();
					this.translate.get(messagepropfailure,{assessmentdata:assessmentType}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "updateassessmentype",
							"title": "Update Assessment Type Failure",
							"type": "DANGER",
							"content": res
						}
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.loaderSaveButton = false;

				}

			},
			(err) => {
				this.onCancelICSelection();
				this.translate.get(messagepropfailure,{assessmentdata:" " + err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "updateassessmentype",
						"title": "Update Assessment Type Failure",
						"type": "DANGER",
						"content": res
					}
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
                this.loaderSaveButton = false;
		});
		
	}

	backtoList(){
		this.assessmentService.backtoSSUE("CFAssessment:ICManager");
	}

	icSelectionChange(event){
		this.icListSelected = event;
		//this.icListSelected = Object.assign({}, event);
	}

	OnAssessmentTypeSelection(event){

		if(event != ""){

			const icListSelectedArray = Object.keys(this.icListOfAssessment).map(i => this.icListOfAssessment[i]);
			let icSubset = [];
			icListSelectedArray.forEach(ic => {
				icSubset.push(ic);
			});

			let existingicSubset = [];
			event.icSubset.forEach(ic => {
				if(icListSelectedArray.indexOf(ic) == -1){
					icSubset.push(ic);
				}else{
					existingicSubset.push(ic);
				}
			});	
			
			if(existingicSubset.length > 0){
				this.translate.get("NOTIFICATIONINFO.ASSESSMENTTYPEPOPUP.TYPESELECTION",{assessmentdata:existingicSubset.join(", ")}).subscribe((res: string) => {
				//let message = "IC(s)" + existingicSubset.join(", ") +" are there in your assessment type already.";
					let alertMetaData = {
						"name": "icalreadyexistinginassessmenttype",
						"title": "IC is already existing in assessment type",
						"type": "INFO",
						"content": res
					}
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});

			}

			if(icSubset.length > icListSelectedArray.length){
				this.updateAssessmentType(icSubset, [], 'import', event.assessmentType);
			}
			this.onCancelAssessmentTypeSelection();

		}

	}

	public onCancelICSelection(){
		
		this.showActions = false;
		let dialog = this.dialogPublicICList;
		dialog.cancelAction();
		
	}

	public onCancelAssessmentTypeSelection(){
		
		this.showActions = false;
		let dialog = this.dialogAssessmentTypeList;
		dialog.cancelAction();
		
	}

	public showICListDialog(){
		
		let dialog = this.dialogPublicICList;
		this.icListOfAssessment = Object.assign({}, this.icListOfAssessment);
		dialog.width = "80%";
		dialog.height = "70%";
		dialog.showDialog();

	}

	public showAssessmentTypeDialog(){
		
		let dialog = this.dialogAssessmentTypeList;		
		dialog.width = "80%";
		dialog.height = "70%";
		dialog.showDialog();

	}

	deleteconfirmation(){		
		this.translate.get("NOTIFICATIONINFO.ASSESSMENTTYPEPOPUP.DELETE").subscribe((res: string) => {
			let deletefusionalert = this.deletefusionalert.nativeElement;	
			let buttons =  [{
				label: "Yes",
			}, {
				label: "No"
			}];
			this.alertAnchor.createAlert(FusionAlert,"warning",res,"",deletefusionalert, buttons);
		});
			  
	  }
	
	  onDeleteAlertButtonClick(event){
		
		let target = event.target || event.srcElement || event.currentTarget;                    
		switch(target.innerHTML){
		  case "Yes":
			  this.onUpdateAssessmentType('delete');
			  break;
		  case "No":
		  	  this.showActions = false;			  
			  break;
		}
	
	  }
  
  	public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectICsOfAssessment",
				width: 50,
				headerCheckboxSelection: true,
				headerCheckboxSelectionFilteredOnly: true,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},            			
			{headerName: "IC Name", field: "name",width: 250, sortingOrder: ['asc','desc'], pinned: true, /*cellRendererFramework:AssessmentICNameLinkComponent,*/
				tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Architecture Type", field: "architecture",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "architecture", headerTooltip: "Architecture Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Feature", field: "feature",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "feature", headerTooltip: "Feature",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "OS", field: "osType",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "osType", headerTooltip: "OS",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Visibility", field: "visibility",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "visibility", headerTooltip: "Visibility",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
			/*
			,{headerName: "Created Date", field: "created",width: 150, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},						
			{headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "nmsArea", headerTooltip: "NMS Area",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},			
			{headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
		  	},
			{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
			*/
		];
		return this.columnDefs;

	}

	public formatDate(params){

		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.created, 'yMMMdjms');

	}

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
		
    }	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
		this.calculateRowCount();
    }
	
}