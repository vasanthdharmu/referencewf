import { Component, ViewChild, ElementRef, ViewEncapsulation, Input, Output, EventEmitter, SimpleChange } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

@Component({
  selector: 'list-public-ics',
  templateUrl: './listpublicics.template.html',
  styleUrls: [ './listpublicics.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class ListPublicICsComponent {  

  public selectedNodesLength:any;
  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public ICList:Array<any> = [];
  @Input() icListOfAssessment:any = [];
  @Output() icSelectionChange: EventEmitter<any> = new EventEmitter();
  public icListSelectedPopup:Array<any> = [];

  	constructor(public translate: TranslateService,public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {	
		
		this.gridOptions = <GridOptions>{
			context: {
				componentParent: this,
				icListSelectedPopup: this.icListSelectedPopup
			},
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no ICs</span>',
			overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>',
			getRowClass: function(params){
				if(params.context.icListSelectedPopup.indexOf(params.node.data.name) != -1){
					return 'ic-selected';
				}
			}
		};

  	}

  	ngOnInit(){		

		//this.loadICs();
	
	}
	  
	ngOnChanges(changes: {[propKey: string]: SimpleChange}) {
		
		let log: string[] = [];
		for (let propName in changes) {
			let changedProp = changes[propName];
			if (changedProp.isFirstChange()) {
			} else {
				let from = JSON.stringify(changedProp.previousValue);
				const icListSelectedPopupArray = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);
				this.icListSelectedPopup = icListSelectedPopupArray;
				this.gridOptions.context.icListSelectedPopup = icListSelectedPopupArray;	
				//this.gridOptions.api.redrawRows();
				this.loadICs();
			}
		}
		
	}


	public onRowSelected($event) {

		let selectedNodes = this.gridOptions.api.getSelectedNodes();	
		this.selectedNodesLength = selectedNodes.length;
		this.icSelectionChange.emit(selectedNodes);
	}


	public loadICs(){	
		
		this.gridOptions.api.showLoadingOverlay();
		let url = (<any>window).acConfig.getUserICListAPI;
		/*let url = (<any>window).acConfig.getICListAPI;
		let body = [
				{
					"attribute":"visibility",
					"value": ['public']
				}
			];

		this.apiService.postUrl(url, body).subscribe(*/
		this.apiService.getAPI(url, '').subscribe(
			result => {

				if (result.status === 200) {
					let respData = result.json();
					this.ICList = respData;
					this.loadICGrid(respData);
				}else{
					this.translate.get('NOTIFICATIONFAILURE.LISTPUBLICIC.LOADINGIC',{data:result.statusText}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "loadpublicic",
							"title" : "Getting Public IC Details Failure",
							"type":"DANGER",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.loadICGrid([]);
				}

			},
			err => {
				this.translate.get('NOTIFICATIONFAILURE.LISTPUBLICIC.LOADINGIC',{data:err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "loadpublicic",
						"title" : "Getting Public IC Details Failure",
						"type":"DANGER",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.loadICGrid([]);
			}
			,() => {}
		);
		

	}
		
	public loadICGrid(data){
		
		if(data != null && data.length > 0){
			this.gridOptions.api.setRowData(data);
			this.gridOptions.api.hideOverlay();
			this.gridOptions.api.sizeColumnsToFit();	
			this.gridOptions.api.forEachNode( (node) => {
				if(this.icListSelectedPopup.indexOf(node.data.name) != -1){
					node.setSelected(true);
				}
			});		
		}else{
			this.gridOptions.api.setRowData([]);
			this.gridOptions.api.showNoRowsOverlay();
		}

	}

	
  
  	public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectAllPublicICs",
				width: 50,
				headerCheckboxSelection: true,
				headerCheckboxSelectionFilteredOnly: true,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},            			
			{headerName: "IC Name", field: "name",width: 250, sortingOrder: ['asc','desc'], pinned: true, /*cellRendererFramework:AssessmentICNameLinkComponent,*/
				tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Architecture Type", field: "architecture",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "architecture", headerTooltip: "Architecture Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Feature", field: "feature",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "feature", headerTooltip: "Feature",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "OS", field: "osType",width: 250, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "osType", headerTooltip: "OS",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
			/*,
			{headerName: "Created Date", field: "created",width: 150, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},
			{headerName: "IC Type", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "visibility", headerTooltip: "IC Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "nmsArea", headerTooltip: "NMS Area",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
		  	},
			{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
			*/
		];
		return this.columnDefs;

	}

	public formatDate(params){

		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.created, 'yMMMdjms');

	}

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
		
    }	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
		this.calculateRowCount();
    }
	
}