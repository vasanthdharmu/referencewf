import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';
import { AsPidLinkComponent } from 'assessment/initiateassessment/basic/aspidlink.component';
import { GridOptions } from 'ag-grid/main';
@Component({
  selector: 'edit-assessment',
  templateUrl: './editassessment.template.html',
  styleUrls: [ './editassessment.style.css'],
  entryComponents: [FusionToaster, AsPidLinkComponent]
})
export class EditAssessmentComponent {

  public assessmentBasicForm: FormGroup;
  public asPidForm: FormGroup;
  public assessmentId: any;
  public assessmentStatus: any;
  public assessmentDetails: any;

  public filteredList = [];
  public selected = [];
    public asPID = [];
  public loaderSaveButton: boolean;
  public isSaveDisabled: boolean;

  public loaderLookup: boolean = false;
  public loaderASPID: boolean = false;
    
  public periodList = [{ "value": "10080", "name": "7 days" },
  { "value": "8640", "name": "6 Days" },
  { "value": "7200", "name": "5 Days" },
  { "value": "5760", "name": "4 Days" },
  { "value": "4320", "name": "3 Days" },
  { "value": "2880", "name": "2 Days" },
  { "value": "1440", "name": "1 Day" },
  { "value": "60", "name": "1 Hr" },
  { "value": "10", "name": "10 Min" }];

  public timeZoneList = [{ "value": "IST", "name": "IST" },
  { "value": "PST", "name": "PST" },
  { "value": "UTC", "name": "UTC" }];

  public collectionDuration = [];
  public loaderCollectionDuration: boolean;

  public startCollection = [{"value": "Now", "name": "Now"}, {"value": "Later", "name": "Later"}];
  public showCollectionDate: boolean = false;

    public gridOptions: GridOptions;
    public rowData: any[];
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;
    @ViewChild('dialogAsPidList') dialogAsPidList;
  constructor(public translate: TranslateService,public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    this.loaderLookup = false;

  }

  ngOnInit(){

    let params = new URLSearchParams(window.location.search);
    this.assessmentId = params.get('?assessmentId'); //127532
    this.assessmentStatus = params.get('status');
    this.appService.set("assessmentId", "");
    if(this.assessmentId != "" && this.assessmentId != null && this.assessmentId != undefined){
      this.appService.set("assessmentId", this.assessmentId);
    }
    this.loadBasicForm();
    this.loadAsPidForm();
    this.gridOptions = <GridOptions>{
    context: {
        componentParent: this
    },
    paginationPageSize: 10,
    pagination: true,
    enableFilter: true,
    floatingFilter: true,
    columnDefs: this.createColumnDefs(),
    overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no available projects</span>',
    overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
};
  }


  loadBasicForm(){
    
      let projectName = "";//For " + this.appService.get("filterContextValue").customer;
      this.assessmentBasicForm = new FormGroup({
        'asProjectID': new FormControl(''),
        'usersAllowed': new FormControl(''),
        'description': new FormControl(''),
        'startCollection': new FormControl('Now'),
        'startCollectionDate': new FormControl(''),
        'startCollectionTime': new FormControl(''),
        'period': new FormControl(''),
        'timeZone': new FormControl('')
        });
      this.updateFormValues();
      
  }

  loadAsPidForm() {

      this.asPidForm = new FormGroup({
          'asProjectID': new FormControl(this.appService.get("cecID"))
      });      

  }

  onStartCollectionChange(selectedCollection){
    this.showCollectionDate = false;
    if(this.assessmentBasicForm.controls.startCollection.value == "Later"){
      this.showCollectionDate = true;
    }
  }  

  updateFormValues(){

    if(this.appService.get("assessmentId") != ""){

      this.selected = [];

      this.apiService.getAPI((<any>window).acConfig.editAssessmentAPI + decodeURIComponent(this.appService.get("assessmentId")), '').subscribe(

        data => {

            let respData = data.json();
            this.logger.info("respData", respData);

            this.assessmentDetails = respData;
            let startCollectionDateandTime = this.assessmentDetails.schedule;
            let startCollectionDate = (startCollectionDateandTime != "" && startCollectionDateandTime != null) ? startCollectionDateandTime.split(" ")[0] : "";
            let startCollectionTime = (startCollectionDateandTime != "" && startCollectionDateandTime != null) ? startCollectionDateandTime.split(" ")[1] : "";
            let startCollection = (startCollectionDateandTime != "" && startCollectionDateandTime != null) ? "Later": "Now";

            this.assessmentBasicForm.patchValue({
              'description': this.assessmentDetails.description,
              'asProjectID': this.assessmentDetails.pid,
              'startCollection': this.assessmentDetails.startCollection,
              'startCollectionDate': startCollectionDate,
              'startCollectionTime': startCollectionTime,
              'period': this.assessmentDetails.duration
            });

            this.getASPID('asProjectID', (<any>window).acConfig.getTVAAPI + '&cecId=' + this.appService.get("cecID"), this.assessmentDetails.pid);
            
            this.updateInputArrays(startCollection, this.startCollection);

            this.updateInputArrays(this.assessmentDetails.duration, this.periodList);

            if(startCollection == "Later"){
              this.showCollectionDate = true;
            }
            this.selected.push(this.assessmentDetails.owner);

            this.assessmentDetails.members.forEach(user => {
              if(this.selected.indexOf(user) == -1){
                this.selected.push(user);
              }
            });

        },
        err => {
           console.error(err);
        }
        ,() => {}
      );      

    }


  }

  updateInputArrays(formdata, inputArray){

    for(let input of inputArray) {
      delete input["selected"];
      if(input.value == formdata)
        {
          input["selected"] = true;
        }
    }

  }

  public onSave(){

    this.loaderSaveButton = true;
    if( this.isValidated() ){


      let url = (<any>window).acConfig.updateAssessmentAPI + decodeURIComponent(this.appService.get("assessmentId"));

      let postData = this.assessmentDetails;
      postData.members = this.selected;
      postData.description = this.assessmentBasicForm.controls.description.value;
      postData.pid = this.assessmentBasicForm.controls.asProjectID.value;
      console.log("postData", postData);
      this.apiService.putUrl(url, postData).subscribe(
        (result) => {

        this.loaderSaveButton = false;
        if(result.status === 200){
          this.translate.get("NOTIFICATIONSUCCESS.EDITASSESSMENT.UPDATE",{projectname:decodeURIComponent(this.appService.get("assessmentId"))}).subscribe((res: string) => {
            let alertMetaData = {
              "name": "updateproject",
              "title" : "Update Project Success",
              "type":"SUCCESS",
              "content": res
            }    
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          });
            this.assessmentService.backtoSSUE("CFAssessment:Projects");

        }else{

            let alertMetaData = {
              "name": "updateproject",
              "title" : "Update Project Success",
              "type":"INFO",

              "content": result.statusText         
            }    
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

        }        
        
       },
       (err) => {
          this.translate.get("NOTIFICATIONFAILURE.EDITASSESSMENT.UPDATE",{error:err._body}).subscribe((res: string) => {
            this.loaderSaveButton = false;
            let alertMetaData = {
              "name": "updateproject",

              "title" : "Update Project Failure",
              "type":"DANGER",
              "content":res        

            }    
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          });
            //this.assessmentService.backtoSSUE("CFAssessment:Projects");

      });

    }

  }

  public onCancel(){    
    this.assessmentService.backtoSSUE("CFAssessment:Projects");

  }



  public isValidated(){


    if(this.assessmentBasicForm.valid && this.selected.length > 0){
      this.isSaveDisabled = false;
      return true;
    }else{
      this.isSaveDisabled = true;
      return false;
    }

  }

  filter() {
    
    let query = this.assessmentBasicForm.controls.usersAllowed.value;

    let options = "";
    
    if(this.selected.indexOf(query) != -1){
      query = "";
      this.assessmentBasicForm.patchValue({'usersAllowed': ''});
      //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","Same user has been added already. Please look up for different user.",toaster,"");
      this.translate.get("NOTIFICATIONFAILURE.EDITASSESSMENT.SAMEUSER").subscribe((res: string) => {
        let alertMetaData = {
          "name": "initiateassessment",
          "title" : "User Lookup",
          "type":"INFO",
          "content": res
        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
      });
    }


    if (query !== "" && query.length >= 2){

      this.loaderLookup = true;
      this.apiService.getExternalAPI((<any>window).acConfig.getUsersAPI + '?q=' + query + '&h=1000000000','').subscribe( //?q=manikandan&h=1000000000

        data => {
          
          this.logger.info("user api", data);

          if(data['_body'] != ""){

            let respdata = data.json();
            let userObj = [];
            let users = respdata.suggest['user-suggest'];
            users.forEach(useroption => {
              useroption.options.forEach(user => {              
                userObj.push({"cecID": user._source.cecid,"name": user._source.name + "(" + user._source.cecid + ")"});
              });
            });

            this.logger.info("userObj", userObj);
            this.filteredList = userObj;
            this.loaderLookup = false;

          }else{
            this.loaderLookup = false;
            //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","User suggestion API is down. Please try after some time.",toaster,"");
            this.translate.get("NOTIFICATIONFAILURE.EDITASSESSMENT.APIDOWN").subscribe((res: string) => {
            let alertMetaData = {
              "name": "initiateassessment",
              "title" : "User Lookup",
              "type":"INFO",
              "content": res
            }    
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          });
          }

        },
        err => { 
          this.loaderLookup = false; 
          //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","User suggestion API is down. Please try after some time.",toaster,"");
          this.translate.get("NOTIFICATIONFAILURE.EDITASSESSMENT.APIDOWN").subscribe((res: string) => {
            let alertMetaData = {
              "name": "initiateassessment",
              "title" : "User Lookup",
              "type":"INFO",
              "content": res
            }    
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          });

          this.logger.info(err); 
        }
        ,() => {}
      );

    }else{    
        this.filteredList = [];
    }
    

  }  

  select(item, event){


    this.isValidated();
    
    if(this.selected.indexOf(item.cecID) == -1){
      this.selected.push(item.cecID);   
    }else{
      this.translate.get("NOTIFICATIONFAILURE.EDITASSESSMENT.SAMEUSER").subscribe((res: string) => {
        let alertMetaData = {
          "name": "editassessmentuserlookup",
          "title" : "User Lookup",
          "type":"INFO",
          "content": res

        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
      });
    }
    
    this.filteredList = [];
    this.assessmentBasicForm.patchValue({'usersAllowed': ''});

  }

  remove(item, event){

    this.selected.splice(this.selected.indexOf(item),1);
    this.isValidated();


  }

  public getOptionValue(value, inputArray) {
    
    for (let input of inputArray) {
        if (input.value == value) {
            return input.name;
        }
    }
    return "";
    
  }
    
    public fetchAsPidList() {
        let dialog = this.dialogAsPidList;
        dialog.width = "60%";
        dialog.height = "90%";
        dialog.showDialog();
    }
    public createColumnDefs() {
        this.columnDefs = [
            {
                headerName: "Project Id", field: "projectId", width: 200, sortingOrder: ['asc', 'desc'], cellRendererFramework: AsPidLinkComponent, pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Project Name", field: "projectName", width: 300, sortingOrder: ['asc', 'desc'], pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Type", field: "projectType", width: 300, sortingOrder: ['asc', 'desc'], pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
        ];
        return this.columnDefs;
    }
    public showPids(formControlName) {
        this.getASPID('asProjectID', (<any>window).acConfig.getTVAAPI + '&cecId=' + this.asPidForm.controls[formControlName].value, "");
        this.assessmentBasicForm.patchValue({ 'nceCECID ': this.asPidForm.controls[formControlName].value });
    }
    
    getASPID(id, url, selectedID) {

        this.loaderASPID = true;
        this.apiService.getTVAAPI(url, '').subscribe(
            data => {

            },
            err => {
                console.error("tva:error", err);
                this[id] = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
                this.loaderASPID = false;
            }
            , () => { }
        );

        (<any>window).tvaInstance.jsonpCallback = (command, data) => {
            this.gridOptions.api.setRowData(data.projectSnapShot);
            this.gridOptions.api.hideOverlay();
            this.gridOptions.api.sizeColumnsToFit();
            this.logger.info("tva data projectSnapShot", data.projectSnapShot);
            this.asPID = [];
            let i = 0;
            let projectSnapShot = data.projectSnapShot;
            if (projectSnapShot != undefined) {
                projectSnapShot.forEach(project => {
                    if (project.projectStatus == 'Active' && project.endCustomerName != "UNKNOWN") {
                        let selected = false;
                        if (selectedID != "" && selectedID == project.projectId) {
                            selected = true;
                        }
                        let projectentry = { "value": project.projectId, "name": project.projectName + " (" + project.projectId + ")", "selected": selected };
                        this.asPID.push(projectentry);
                        i++;
                    }
                    if (i == 0) {
                        this.asPID = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
                    }
                });
            } else {
                this.asPID = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
            }
            this[id] = this.asPID;
            this.logger.info("as pid list", this[id]);
            this.loaderASPID = false;
        };

    }

    public calculateRowCount() {
        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }
    public onProjectSelection(id) {
        this.assessmentBasicForm.patchValue({ 'asProjectID': id });
        let dialog = this.dialogAsPidList;
        dialog.cancelAction();
    }
    public close() {
        let dialog = this.dialogAsPidList;
        dialog.cancelAction();
    }
}