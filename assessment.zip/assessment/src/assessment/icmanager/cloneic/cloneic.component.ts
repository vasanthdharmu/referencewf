import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';

@Component({
	selector: 'clone-ic',
    templateUrl: './cloneic.template.html',
    styleUrls: [ './cloneic.style.css' ],
    encapsulation: ViewEncapsulation.None,
})
export class CloneICComponent {

	public icBasicForm: FormGroup;
	public icDuplicate: boolean = false;
	public loaderICDetails: boolean = true;
	public selectedIC: any;
	public loaderSaveButton: boolean = false;
	
	@ViewChild('dialogCloneIC') dialogCloneIC;	

	constructor(public translate: TranslateService, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
			  
	}

	ngOnInit() {

		this.icBasicForm = new FormGroup({
            'name': new FormControl('', Validators.required)
		});
		this.loadICDetails();
		this.showCloneIC();

	}

	public loadICDetails(){

		let params = new URLSearchParams(window.location.search);
		let ICName = params.get('?ICName');
		let url = (<any>window).acConfig.getICDetailsAPI + ICName;
		this.apiService.getAPI(url, '').subscribe(
			data => {

				this.loaderICDetails = false;
				if(data.status == 200){
					
					this.selectedIC = data.json();
					this.icBasicForm.patchValue({ 'name': this.selectedIC.name.split("-").join(" ") + " copy" });
					this.checkIcName();

				}else{

					this.translate.get('NOTIFICATIONFAILURE.CLONEIC.GETICDETAILSTOCLONE', {message: data.statusText}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "cloneic",
							"title" : "Get IC to Clone",
							"type":"Error",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});								
					this.assessmentService.backtoSSUE("CFAssessment:ICManager");

				}
				

			},
			err => {
				this.loaderICDetails = false;
				this.translate.get('NOTIFICATIONFAILURE.CLONEIC.GETICDETAILSTOCLONE', {message: err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "cloneic",
						"title" : "Get IC to Clone",
						"type":"Error",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);		
				});	
				this.assessmentService.backtoSSUE("CFAssessment:ICManager");				
			}
			,() => {}
		);
		

	}

	public showCloneIC(){
		
		let dialog = this.dialogCloneIC;
		dialog.width = "300px";
		dialog.height = "300px";
		dialog.showDialog();

	}

	public onCancelCloneIC(){

		let dialog = this.dialogCloneIC;
		dialog.cancelAction();
		this.assessmentService.backtoSSUE("CFAssessment:ICManager");
	}
	
	public onSave(){

		this.loaderSaveButton = true;

		let params = new URLSearchParams(window.location.search);
		let ICName = params.get('?ICName');
		let postData = {
			"ic": this.selectedIC
		};

		postData.ic.name = this.icBasicForm.controls.name.value;
		postData.ic.visibility = "private";
		postData.ic.status = "active";
		delete postData.ic.owner;
		delete postData.ic.version;
		delete postData.ic.created;
		delete postData.ic.updated;	
		
		console.log("postData", postData);
		
		let url = (<any>window).acConfig.postIC;
		this.apiService.postUrl(url, JSON.stringify(postData)).subscribe(
            (result) => {

				if (result.status === 201) {
					
					this.translate.get('NOTIFICATIONSUCCESS.CLONEIC.SAVECLONEIC', {fromICName: ICName.split("-").join(" "), newICName: postData.ic.name}).subscribe((res: string) => {

						let alertMetaData = {
							"name": "cloneic",
							"title" : "Clone IC Success",
							"type":"SUCCESS",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

					});
					
					this.loaderSaveButton = false;
					this.assessmentService.backtoSSUE("CFAssessment:ICManager");

				}else{

					this.translate.get('NOTIFICATIONFAILURE.CLONEIC.SAVECLONEIC', {ICName: ICName.split("-").join(" ")}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "cloneic",
							"title" : "Clone IC Failure",
							"type":"DANGER",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});					
					this.loaderSaveButton = false;
					this.assessmentService.backtoSSUE("CFAssessment:ICManager");

				}

			},
			(err) => {
				if(err.status === 400){
					if(JSON.parse(err._body).code=="IC_DUPLICATE_NAME"){
						this.translate.get('NOTIFICATIONFAILURE.CLONEIC.ICNAMEEXITS', {ICName: ICName.split("-").join(" ")}).subscribe((res: string) => {
							let alertMetaData = {
								"name": "cloneic",
								"title" : "Clone IC Failure",
								"type":"DANGER",
								"content": res
							}    
							this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
						});
					}
					else{
						this.translate.get('NOTIFICATIONFAILURE.CLONEIC.SAVECLONEIC', {ICName: err._body}).subscribe((res: string) => {
							let alertMetaData = {
								"name": "cloneic",
								"title" : "Clone IC Failure",
								"type":"DANGER",
								"content": res
							}    
							this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
						});
					}
				}
				
				this.loaderSaveButton = false;
				this.assessmentService.backtoSSUE("CFAssessment:ICManager");
				
		});
		

	}

	checkIcName() {

        if (this.icBasicForm.controls.name.value != "") {
            let url = (<any>window).acConfig.getICDetailsAPI + this.icBasicForm.controls.name.value.split(" ").join("-");
            this.apiService.getAPI(url, '').subscribe(
                data => {                    
                    if (data.status == 200) {
                        this.icDuplicate = true;
                    }else{
						this.icDuplicate = false;
					}
                },
                err => {
                    this.icDuplicate = true;
                    if (err.status == 404) {
                        this.icDuplicate = false;
                    }
                    console.error(err);
                }
                , () => { }
            );
		}
		
    }
		
}