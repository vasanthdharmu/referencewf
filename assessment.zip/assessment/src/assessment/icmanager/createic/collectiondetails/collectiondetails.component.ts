import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

@Component({
  selector: 'collection-details',
  templateUrl: './collectiondetails.template.html',
  styleUrls: [ './collectiondetails.style.css' ]
})

export class CollectionDetailsComponent implements OnInit{

	@Output() collectionDetailsStepData: EventEmitter<any> = new EventEmitter();
	public selectedOSTypes;
    public selectedProductFamily;
    public selectedFeature;
	
	constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
		this.registerToSSUEApi();
	}

	ngOnInit() {
  		
	}
	
	public emitStepDataOnChange(data:any) {
		this.collectionDetailsStepData.emit(data);
	}

	getCustomCommandsForCollection(event){
		this.emitStepDataOnChange(event);
	}

	public registerToSSUEApi(){
		
		this.workflowapi.registerEvent('allStepsData')
		.subscribe((response: any) => {
			let step1Data = JSON.parse(response.allStepsData.step1);
			this.selectedOSTypes = Object.assign({}, step1Data.osType);
            this.selectedProductFamily = Object.assign({}, step1Data.productFamily);
            this.selectedFeature = Object.assign({}, step1Data.feature);
		});

	}
	
}
