import { Component, ViewChild, Input, ElementRef } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

@Component({
    styleUrls: ['./createic.style.css'],
    selector: 'createic',
    templateUrl: './createic.template.html',
    entryComponents: []
})
export class CreateICComponent {

    public ICDetailsStepData: any;
    public collectionDetailsStepData: any;
    public scriptStepData: any;
    public ICDetailsData:boolean = false;
    public enableScriptStep:boolean = false;
    public isSubmit:boolean = false;
    private subscriptionConfirm: ISubscription;
    constructor(public translate: TranslateService,public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

        (<any>window).localStorage.clear();
        (<any>window).sessionStorage.clear();
        this.registerToSSUEApi();

    }

    ngOnInit() {        

    }

    ngOnDestroy() {
        this.subscriptionConfirm.unsubscribe();
    }

    setICDetailsStepData(data) {
        if(!data){
            this.ICDetailsData = data;
        }
        else{
            this.ICDetailsStepData = data;
            this.ICDetailsData = true;
        }
        this.setScriptStepData(this.scriptStepData);
    }

    setCollectionDetailsStepData(data) {
        this.collectionDetailsStepData = data;
        this.enableScriptStep = false;
        if(JSON.parse(this.collectionDetailsStepData).length > 0){
            this.enableScriptStep = true;
        }
        this.setScriptStepData(this.scriptStepData);
    }

    setScriptStepData(data) {
        if(data!=null && data.length>0 && this.ICDetailsData && this.enableScriptStep){
            this.isSubmit=true;
            this.scriptStepData = data;
        }
        else{
            this.isSubmit=false;           
        }   
        
    }

    public registerToSSUEApi(){
        
        this.workflowapi.registerEvent('onCancel')
            .subscribe((response: any) => {
            this.assessmentService.backtoSSUE("CFAssessment:ICManager");
            this.workflowapi.clearStorage();
        });

        this.subscriptionConfirm =  this.workflowapi.registerEvent('onConfirm')
            .subscribe((response: any) => {

                let responsedata=response.payload;
                let icData:any;

                if(responsedata!=null && responsedata.step1!=null && responsedata.step2!=null && responsedata.step3!=null){
                    console.log(responsedata.step1);
                    icData ={"ic":JSON.parse(responsedata.step1)};
                    icData.ic["collectionInfo"]=JSON.parse(responsedata.step2);
                    icData.ic["script"]=responsedata.step3;

                    icData.ic["technology"]=["all"];
                    icData.ic["status"]="active";
                    icData.ic["legacySource"]="CNA";
                    console.log(icData);
                    this.saveIC(icData);
                }   

                else{   
                    this.translate.get('NOTIFICATIONINFO.CREATEIC.MANDATORY').subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "errorcreateIC",
                            "title" : "Mandatory fields",
                            "type":"INFO",
                            "content": res         
                        }    
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });

                }
            });
    
    }

    public saveIC(ICdata) {
        this.apiService.postUrl((<any>window).acConfig.postIC, JSON.stringify(ICdata)).subscribe(
            (result) => {
                let resultInfo = result.json();
                if (result.status === 201) {
                    this.appService.set("assessmentData", JSON.stringify(result.json()));
                    this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));
                    let icname = resultInfo.name;
                    this.translate.get('NOTIFICATIONSUCCESS.CREATEIC.CREATED', { icname: resultInfo.name }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "createIC",
                            "title": "IC created",
                            "type": "SUCCESS",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:ICManager");
                    this.workflowapi.clearStorage();
                    (<any>window).localStorage.clear();
                    (<any>window).sessionStorage.clear();
                }
                else {
                    this.translate.get('NOTIFICATIONFAILURE.CREATEIC.ERROR', { icname: resultInfo.name }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "errorcreateIC",
                            "title": "Error on IC creation",
                            "type": "DANGER",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                }
            },
            (err) => {
                let errinfo = err.json();
                if (err.status === 400) {
                    this.translate.get('NOTIFICATIONFAILURE.CREATEIC.ERROR', { error: errinfo.recommended }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "errorcreateIC",
                            "title": errinfo.message,
                            "type": "DANGER",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                }
                else {
                    this.translate.get('NOTIFICATIONFAILURE.CREATEIC.ERROR', { error: errinfo.recommended }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "errorcreateIC",
                            "title": "Error on IC creation",
                            "type": "DANGER",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                }

            });
    }

}