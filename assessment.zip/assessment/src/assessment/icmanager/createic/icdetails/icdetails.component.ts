import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

@Component({
    selector: 'ic-details',
    templateUrl: './icdetails.template.html',
    styleUrls: ['./icdetails.style.css']
})

export class ICDetailsComponent implements OnInit {

    public icBasicForm: FormGroup;
    public formelements: any;
    public icData: any = {};
    public formComplete: boolean = false;
    public icDuplicate: boolean = false;
    public osTypeList = [];
    public productFamilyList = [];
    public productFamily = [];
    public featureList = [];
    public feature = [];
    public nmsArea = [];
    public scopeTypeList = [];
    public visibilityList = [{ "value": "Public", "name": "Public", "selected": true }, { "value": "Private", "name": "Private" }];
    public architectureTypeList = [];
    public allstepData: any;
    public step1Data: any;
    public show: boolean = true;
    public isError: boolean = false;
    public errorMessage: String = "";
    @Output() ICDetailsStepData: EventEmitter<any> = new EventEmitter();

    public nmsAreaSelection: any = {};
    public scopeSelection: any = {};
    public architectureTypeSelection: any = {};
    public featureSelection: any = {};
    public osTypeSelection: any = [];
    public productFamilySelection: any = [];
    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
        this.registerToSSUEApi();
    }

    ngOnInit() {
        this.icData.visibility = "public";
        this.loadBasicForm();
    }

    loadBasicForm() {
        this.icBasicForm = new FormGroup({
            'name': new FormControl('', Validators.required),
            'nmsArea': new FormControl('', Validators.required),
            'scope': new FormControl('', Validators.required),
            'osType': new FormControl('', Validators.required),
            'productFamily': new FormControl('', Validators.required),
            'summary': new FormControl(''),
            'contributor': new FormControl(this.appService.get("cecID")),
            'visibility': new FormControl(''),
            'architecture': new FormControl('', Validators.required),
            'feature': new FormControl('', Validators.required)
        });
        this.getIcMetadata();
        this.getArchitectureTypes();
    }

    public emitStepDataOnChange(data: any) {
        this.ICDetailsStepData.emit(data);
    }

    public toggle() {
        this.show = !this.show;
        if (this.show) {
            this.icData.visibility = "public";
        }
        else {
            this.icData.visibility = "private";
        }
        this.isValidated();
    }

    selectChange(formControlName, formControlField) {
        this.icBasicForm.patchValue({ [formControlName]: formControlField.value });
        this.icData[formControlName] = this.icBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    multiselectChange(formControlName, formControlField) {
        let multiselected = [];
        for (let selected of formControlField) {
            multiselected.push(selected.value);
        }
        this.icBasicForm.patchValue({ [formControlName]: multiselected });
        this.icData[formControlName] = this.icBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    setValue(formControlName) {
        this.icData[formControlName] = this.icBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    isValidated() {
        if (this.icBasicForm.valid && !this.isError) {
            this.emitStepDataOnChange(JSON.stringify(this.icData));
            this.formComplete = true;
        }
        else {
            this.emitStepDataOnChange(false);
            this.formComplete = false;
        }
    }

    getIcMetadata() {
        this.apiService.getAPI((<any>window).acConfig.getIcMetaData, '').subscribe(
            data => {
                let respData = data.json();
                let nmsList = [];
                let osList = [];
                let scopeList = [];
                let productList = [];
                respData.nmsArea.forEach((nms, index) => {
                    nmsList.push({ "value": nms, "name": nms });
                });
                respData.osType.forEach((osType, index) => {
                    osList.push({ "value": osType, "name": osType });
                });
                respData.scope.forEach((scope, index) => {
                    scopeList.push({ "value": scope, "name": scope });
                });
                this.productFamily = respData.productFamily;
                this.feature = respData.feature;
                this.nmsArea = nmsList;
                this.osTypeList = osList;
                this.scopeTypeList = scopeList;
            },
            err => {
                console.error(err);
            }
            , () => { }
        );
    }

    getArchitectureTypes() {
        this.apiService.getAPI((<any>window).acConfig.getArchitectureTypes, '').subscribe(
            data => {
                let respData = data.json();
                let architectureList = [];
                respData.forEach((architecture, index) => {
                    architectureList.push({ "value": architecture.type, "name": architecture.type });
                });
                this.architectureTypeList = architectureList;
            },
            err => {
                console.error(err);
            }
            , () => { }
        );
    }

    getProductFamilyList(formControlField) {
        this.productFamilyList.length = 0;
        formControlField.forEach((os, index) => {
            if (this.productFamily[os.value] != undefined) {
                this.productFamily[os.value].forEach((product, index) => {
                    this.productFamilyList.push({ "value": product, "name": product });
                });
            }
        });
        if (this.step1Data != undefined) {
            this.updateMultiSelect(this.step1Data.productFamily, this.productFamilyList, "productFamilySelection");
        } else {
            this.updateMultiSelect('', this.productFamilyList, "productFamilySelection");
        }

    }
    getFeatureList(formControlField) {
        this.featureList.length = 0;
        let selectedFeature = [];
        let osSelected = this.icBasicForm.controls['osType'].value;
        osSelected.forEach((os, index) => {
            formControlField.forEach((product, index) => {
                if (this.feature[os][product.value] != undefined) {
                    this.feature[os][product.value].forEach((feature, index) => {
                        selectedFeature.push(feature);
                    });
                }
            });
        });
        let result = [];
        for (let index = 0; index < selectedFeature.length; index++) {
            let el = selectedFeature[index];
            if (result.indexOf(el) === -1) {
                result.push(el);
                this.featureList.push({ "value": el, "name": el });
            } 
        }
        if (this.step1Data != undefined) {
            this.updateMultiSelect(this.step1Data.feature, this.featureList, "featureSelection");
        } else {
            this.updateMultiSelect('', this.featureList, "featureSelection");
        }

    }

    checkIcName(formControlName) {
        var name = this.icBasicForm.controls[formControlName].value.trim();
        if (name != "" && name.length < 3) {
            this.isError = true;
            this.errorMessage = "IC name should have min 3 letters";
            this.isValidated();
        }
        else if (/^[a-zA-Z0-9- _]*$/.test(name)) {
            var firstChar = this.icBasicForm.controls[formControlName].value.charAt(0);
            if ("-,".indexOf(firstChar) != -1) {
                this.isError = true;
                this.errorMessage = "IC name should started with letters or digits or _";
            }
            else {
                let url = (<any>window).acConfig.getICDetailsAPI + this.icBasicForm.controls[formControlName].value.split(" ").join("-");
                url = encodeURI(url);
                this.apiService.getAPI(url, '').subscribe(
                    data => {
                        this.isError = false;
                        this.errorMessage = "";
                        if (data.status == 200) {
                            this.isError = true;
                            this.errorMessage = "IC name already exist.";
                        }
                        this.isValidated();
                    },
                    err => {
                        this.isError = true;
                        this.errorMessage = "Invalid IC name";
                        if (err.status == 404) {
                            this.isError = false;
                            this.errorMessage = "";
                        }
                        this.isValidated();
                    }
                    , () => { }
                );
            }
        }
        else {
            this.isError = true;
            this.errorMessage = "IC name can contain only letters, digits, _ , - and space";
            this.isValidated();
        }
    }

    public registerToSSUEApi() {
        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                this.allstepData = response.allStepsData;
                this.step1Data = JSON.parse(this.allstepData.step1);
                this.updateForm(this.step1Data);
            });
    }

    updateForm(formData) {
        this.icBasicForm.patchValue({ 'name': formData.name });
        this.icBasicForm.patchValue({ 'summary': formData.summary });
        this.icBasicForm.patchValue({ 'visibility': formData.visibility });
        this.icBasicForm.patchValue({ 'nmsArea': formData.nmsArea });
        this.updateInputArrays(formData.nmsArea, this.nmsArea, "nmsAreaSelection");
        this.updateInputArrays(formData.scope, this.scopeTypeList, "scopeSelection");
        this.updateMultiSelect(formData.osType, this.osTypeList, "osTypeSelection");
        this.updateMultiSelect(formData.productFamily, this.productFamilyList, "productFamilySelection");
        this.updateMultiSelect(formData.feature, this.featureList, "featureSelection");
        this.getProductFamilyList(formData.osType);
        this.getFeatureList(formData.productFamily);
        this.updateInputArrays(formData.architecture, this.architectureTypeList, "architectureTypeSelection");
    }

    updateInputArrays(formdata, inputArray, selection) {
        for (let input of inputArray) {
            delete input['selected'];
            if (input.value == formdata) {
                input['selected'] = true;
                this[selection] = input;
            }
        }
    }

    updateMultiSelect(formdata, inputArray, selection) {
        for (let input of inputArray) {
            delete input['selected'];
        }
        let selectedvalues = [];
        for (let value of formdata) {
            for (let input of inputArray) {
                if (input.value == value) {
                    selectedvalues.push(input);
                }
            }
        }
        this[selection] = selectedvalues;
    }

}