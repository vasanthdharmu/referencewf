import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { AceEditorComponent } from 'ng2-ace-editor';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import "brace/mode/python";

@Component({
    selector: 'ic-script',
    templateUrl: './icscript.template.html',
    styleUrls: ['./icscript.style.css'],
    encapsulation: ViewEncapsulation.None,
})

export class ICScriptComponent implements OnInit {
    public scriptResult: any;
    public deviceForm: FormGroup;
    public popupForm: FormGroup;
    public ICList: Array<any> = [
        { "commandID": "01", "commandName": "My Command 01" },
        { "commandID": "02", "commandName": "My Command 02" },
        { "commandID": "03", "commandName": "My Command 03" },
        { "commandID": "04", "commandName": "My Command 04" },
        { "commandID": "05", "commandName": "My Command 05" },
        { "commandID": "06", "commandName": "My Command 06" },
        { "commandID": "07", "commandName": "My Command 07" },
        { "commandID": "08", "commandName": "My Command 08" },
        { "commandID": "09", "commandName": "My Command 09" }];
    public PUselected: any;
    public ScriptData: any;
    public PopupScriptData: any;
    public IcData: any;
    public allstepData: any;
    public step1Data: any;
    public ste2Data: any;
    public scriptoptions: any = { highlightActiveLine: false, highlightGutterLine: false, printMargin: false, enableBasicAutocompletion: true };
    public popupeditoroptions: any = { highlightActiveLine: false, highlightGutterLine: false, printMargin: false, enableBasicAutocompletion: true };
    @Output() scriptStepData: EventEmitter<any> = new EventEmitter();

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    }

    preLoad() {

    }

    ngOnInit() {
        this.loadmodelData();
    }

    public loadmodelData() {
        this.workflowapi.registerEvent('allStepsData')
            .subscribe((response: any) => {
                this.allstepData = response.allStepsData;
                this.ste2Data = this.allstepData.step2 ? JSON.parse(this.allstepData.step2) : null;
                let stepCommandData = this.ste2Data;
                if(this.ste2Data != null){
                    let selectedCommand = [];
                    if (stepCommandData != null) {
                        stepCommandData.forEach(commandDetails => {
                            selectedCommand.push(commandDetails.command);
                        });
                    }
                    let modelurl = (<any>window).acConfig.getNetworkModelAPI;
                    this.apiService.getUrl(modelurl, '').subscribe(
                        data => {
                            let respData = data;
                            let commandList = [];
                            respData.forEach(commandDetails => {
                                let x: any;
                                for (x in commandDetails) {
                                    if (selectedCommand.indexOf(x) > -1) {
                                        commandList.push(commandDetails);
                                    }
                                }
                            });
                            this.scriptResult = commandList;
                        },
                        err => {
    
                        }
                        , () => { }
                    );
                }
                
            });
    }

    public onTextChange(evt) {
        this.validateData();
    }

    public emitStepDataOnChange(data: any) {
        this.scriptStepData.emit(data);
    }

    public validateData() {
        this.emitStepDataOnChange(btoa(this.ScriptData));
    }

    public showDialogPop(dialog) {
        dialog.width = "80%";
        dialog.height = "80%";
        dialog.showDialog();
    }

}