import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { CuiTableOptions } from 'aui/components/cui-table';
import { AceEditorComponent } from 'ng2-ace-editor';
import "brace/mode/python";

@Component({
    selector: 'edit-ic',
    templateUrl: './editic.template.html',
    styleUrls: ['./editic.style.css'],
    encapsulation: ViewEncapsulation.None
})
export class EditICComponent {

    public loaderICDetails: boolean = true;
    public deviceForm: FormGroup;
    public devices = [];
    public scriptResult: any;
    public scriptTestResult: any = "<xml></xml>";
    public selectedIC: any;

    @ViewChild('dialogTestScript') dialogTestScript;
    @ViewChild('dialogConfirmSave') dialogConfirmSave;

    public scripttext: string = "";
    public scriptoptions: any = { highlightActiveLine: false, highlightGutterLine: false, printMargin: false, enableBasicAutocompletion: true };
    public loaderSaveButton: boolean = false;

    public customCommandTableOptions: CuiTableOptions;
    public customCommands: Array<any> = [];
    public readOnly: boolean = false;
    constructor(public translate: TranslateService, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    }

    ngOnInit() {

        this.deviceForm = new FormGroup({
            'device': new FormControl(''),
            'script': new FormControl('')
        });
        this.loadICDetails();
        this.loadCustomCommandTable();

    }

    public onDeviceChange(event) {
        this.deviceForm.patchValue({ 'device': event.value });
    }

    public loadICDetails() {

        let params = new URLSearchParams(window.location.search);
        let ICName = params.get('?ICName');
        let url = (<any>window).acConfig.getICDetailsAPI + ICName;
        this.apiService.getAPI(url, '').subscribe(
            data => {

                this.loaderICDetails = false;
                if (data.status == 200) {

                    this.selectedIC = data.json();
                    this.readOnly = false;
                    if (this.selectedIC.visibility == 'public') {
                        this.readOnly = true;
                    }
                    this.logger.info("this.selectedIC", this.selectedIC);
                    this.customCommands = this.selectedIC.collectionInfo;
                    this.deviceForm.patchValue({ 'script': this.selectedIC.script });
                    this.scripttext = atob(this.selectedIC.script);

                } else {
                    this.translate.get('NOTIFICATIONFAILURE.EDITIC.ERROR',{error:data.statusText}).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "editic",
                            "title": "Edit IC",
                            "type": "Error",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:ICManager");

                }
                this.loadModel();

            },
            err => {
                this.logger.error("err", err);
                this.loaderICDetails = false;
                this.translate.get('NOTIFICATIONFAILURE.EDITIC.ERROR').subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "editic",
                        "title": "Edit IC",
                        "type": "Error",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });
                this.assessmentService.backtoSSUE("CFAssessment:ICManager");
            }
            , () => { }
        );


    }

    public loadModel() {

        let commandData = this.selectedIC.collectionInfo;
        let selectedCommand = [];
        commandData.forEach(commandDetails => {
            selectedCommand.push(commandDetails.command);
        });
        let modelurl = (<any>window).acConfig.getNetworkModelAPI;
        this.apiService.getUrl(modelurl, '').subscribe(
            data => {
                let respData = data;
                let commandList = [];
                respData.forEach(commandDetails => {
                    let x: any;
                    for (x in commandDetails) {
                        if (selectedCommand.indexOf(x) > -1) {
                            commandList.push(commandDetails);
                        }
                    }
                    this.scriptResult = commandList;
                });
            },
            err => {

            }
            , () => { }
        );

    }

    public loadCustomCommandTable() {

        this.customCommandTableOptions = new CuiTableOptions({
            "bordered": true,
            "striped": false,
            "hover": false,
            "wrapText": false,
            "padding": "regular",
            "selectable": false,
            "dynamicData": true,
            "columns": [
                {
                    "name": "Command Name",
                    "key": "command"
                },
                {
                    "name": "Command Type",
                    "key": "mode"
                },
                {
                    "name": "OS Type",
                    "key": "ostypes"
                },
                {
                    "name": "Repetition",
                    "key": "repetition"
                },
                {
                    "name": "Frequency",
                    "key": "frequency"
                }
            ]
        });

    }

    public showScriptTestResult() {

        this.scriptTestResult = "<show-status><server>10.106.211.174</server><type>CLI</type><command>show-status</command><rows><row><HostName>unity-cucm</HostName><Date>Mon Mar 6, 2017 13:26:26</Date><Locale>en_US.UTF-8</Locale><ProductVersion>10.5.1.10000-7</ProductVersion><TimeZone></TimeZone><PlatformtVersion></PlatformtVersion></row><row><MemTotal>8062644K</MemTotal><MemFree>222392K</MemFree><MemUsed>7840252K</MemUsed><MemCached>3854996K</MemCached><MemShared>0K</MemShared></row><row><Uptime> 13:26:27</Uptime><UpDays>73</UpDays><UpHours>3:58</UpHours><NumUsers>1</NumUsers><LoadAverage>1.00, 0.62, 0.31</LoadAverage><CpuIdle>87.82</CpuIdle><CpuSystem>06.09</CpuSystem><CpuUser>06.09</CpuUser><IOWait></IOWait><IRQ></IRQ></row></rows></show-status>";
        let dialog = this.dialogTestScript;
        dialog.width = "80%";
        dialog.height = "70%";
        dialog.showDialog();

    }

    public onCloseTestScriptPopup() {

    }

    public showConfirmSave() {

        let dialog = this.dialogConfirmSave;
        dialog.width = "300px";
        dialog.height = "300px";
        dialog.showDialog();

    }

    public onCloseConfirmSavePopup() {

    }

    public onCancelConfirmSave() {

        let dialog = this.dialogConfirmSave;
        dialog.cancelAction();
    }


    public saveDeviceScript() {

    }

    public onScriptChange(code) {
        //this.selectedIC.script = code;
    }

    public onCancel() {
        this.assessmentService.backtoSSUE("CFAssessment:ICManager");
    }

    public onSave() {
        this.loaderSaveButton = true;
        this.selectedIC.script = btoa(this.scripttext);
        let postData = {
            "ic": this.selectedIC
        };
        let params = new URLSearchParams(window.location.search);
        let ICName = params.get('?ICName');
        let url = (<any>window).acConfig.putICAPI + ICName;
        this.apiService.putUrl(url, JSON.stringify(postData)).subscribe(
            (result) => {

                if (result.status === 200) {

                    this.onCancelConfirmSave();
                    this.translate.get('NOTIFICATIONSUCCESS.EDITIC.EDITED',{icnames:ICName.split("-").join(" ") }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "updateic",
                            "title": "Update IC Success",
                            "type": "SUCCESS",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:ICManager");
                    this.loaderSaveButton = false;

                } else {

                    this.onCancelConfirmSave();
                    this.translate.get('NOTIFICATIONFAILURE.EDITIC.UPDATE',{icnames:ICName.split("-").join(" ") }).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "updateic",
                            "title": "Update IC Failure",
                            "type": "DANGER",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.loaderSaveButton = false;

                }

            },
            (err) => {
                this.onCancelConfirmSave();
                this.translate.get('NOTIFICATIONFAILURE.EDITIC.UPDATE',{icnames:err._body}).subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "updateic",
                        "title": "Update IC Failure",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });
                this.loaderSaveButton = false;
            });


    }

    public resetScript(){
        this.scripttext = atob(this.selectedIC.script);
    }

}