import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

import { EditICNameLinkComponent } from 'assessment/icmanager/listic/editicnamelink.component';

@Component({
  selector: 'list-ic',
  templateUrl: './listic.template.html',
  styleUrls: [ './listic.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class ListICComponent {  

  public selectedNodesLength:any;

  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public showActions: any;
  public showToolPanel: any;

	constructor(public translate: TranslateService,public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {
			
	}

  	ngOnInit(){
		
		this.gridOptions = <GridOptions>{
			context: {
                componentParent: this
            },
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no ICs</span>',
			overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'		
		}; 

		this.getICList();
	
  	}


	public onRowSelected($event) {

		let selectedNodes = this.gridOptions.api.getSelectedNodes();	
		this.selectedNodesLength = selectedNodes.length;

	}


	deleteIC(){
		
		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		let name = [];
		let status = [];
		for (let node of selectedNodes){
			name.push(node.data.name);
			status.push(node.data.visibility);
		}
		let deleteLink = '/assessment/ssue?operation=deleteic&name=' + name.join("|") + '&visibility=' + status.join("|");		
		this.router.navigateByUrl(deleteLink);

	}

	cloneIC(){
		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		let cloneLink = '/assessment/cloneic?ICName='+selectedNodes[0].data.name;
		this.router.navigateByUrl(cloneLink);
	}
	  
	getICList(){		

		let url = (<any>window).acConfig.getUserICListAPI;

		this.apiService.getAPI(url, '').subscribe(
			result => {

				if (result.status === 200) {					
					let respData = result.json();
					if(respData.length > 0){
						this.logger.info("ic list", respData);
						this.gridOptions.api.setRowData(respData);
						this.gridOptions.api.hideOverlay();
						this.gridOptions.api.sizeColumnsToFit();
					}else{
						this.gridOptions.api.setRowData([]);
						this.gridOptions.api.showNoRowsOverlay();
					}
				}else{
					this.translate.get('NOTIFICATIONFAILURE.LISTIC.LISTIC',{error:result.statusText}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "listicfailure",
							"title": "List IC Failure",
							"type": "INFO",
							"content": res
						}
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.gridOptions.api.setRowData([]);
					this.gridOptions.api.showNoRowsOverlay();
				}

			},
			err => {
				this.translate.get('NOTIFICATIONFAILURE.LISTIC.LISTIC',{error:err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "listicfailure",
						"title": "List IC Failure",
						"type": "INFO",
						"content": res
					}
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.gridOptions.api.setRowData([]);
				this.gridOptions.api.showNoRowsOverlay();
			}
			,() => {}
		);

	}  
  
  	public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectAllICs",
				width: 50,
				headerCheckboxSelection: false,
				headerCheckboxSelectionFilteredOnly: false,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},            			
			{headerName: "IC Name", field: "name",width: 150, sortingOrder: ['asc','desc'], cellRendererFramework:EditICNameLinkComponent, pinned: true,
				tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Created Date", field: "created",width: 150, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},
			{headerName: "IC Type", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "visibility", headerTooltip: "IC Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "OS Type", field: "osType",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "osType", headerTooltip: "OS Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "nmsArea", headerTooltip: "NMS Area",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Architecture Type", field: "architecture",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "architecture", headerTooltip: "Architecture Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
		  	},
			{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
		];
		return this.columnDefs;

	}

	public formatDate(params){

		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.created, 'yMMMdjms');

	}

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
		
    }	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
		this.calculateRowCount();
    }
	
}