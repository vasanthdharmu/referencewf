import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'as-pid-link',
    template: `<a (click)="onProjectSelection()">{{params.data.projectId}}</a>`
})

export class AsPidLinkComponent implements ICellRendererAngularComp  {
    public params: any;
    constructor(public router: Router) {    
    }
    agInit(params: any): void {
        this.params = params;
    }
    refresh(): boolean {
        return false;
    }
    public onProjectSelection() {
        this.params.context.componentParent.onProjectSelection(this.params.data.projectId);
    }
}