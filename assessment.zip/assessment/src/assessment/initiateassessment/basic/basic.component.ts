import { NgModule, Component, OnInit, ViewChild, Output, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';
import { AsPidLinkComponent } from 'assessment/initiateassessment/basic/aspidlink.component';

@Component({
    selector: 'basic-details',
    templateUrl: './basic.template.html',
    styleUrls: ['./basic.style.css'],
    host: { 'class': "dynamic-component" },
    entryComponents: [FusionToaster, AsPidLinkComponent]
})
export class BasicComponent {

    public assessmentBasicForm: FormGroup;
    public asPidForm: FormGroup;
    public filteredList = [];
    public selected = [];
    public asPID = [];

    @ViewChild(ToasterAnchorDirective) toasterAnchor;
    @ViewChild('toaster') toaster: ElementRef;

    public loaderLookup: boolean = false;
    public loaderASPID: boolean = false;
    public isError: boolean = false;
    public errorMessage:String="";
    public formComplete: boolean = false;
    public assessmentTypes = [];
    public loaderAssessmentType: boolean = false;

    public architectureTypeList = [];
    public architectureTypeSelection: any = {};
    public assessmentTypeSelection: any = {};
    public periodSelection: any = {};
    public timeZoneSelection: any = {};
    public startCollectionSelection: any = {};
    public loaderArchitectureType: boolean = false;

    public periodList = [
        { "value": "10", "name": "10 Min" },
        { "value": "60", "name": "1 Hr" },
        { "value": "1440", "name": "1 Day" },
        { "value": "2880", "name": "2 Days" },
        { "value": "4320", "name": "3 Days" },
        { "value": "5760", "name": "4 Days" },
        { "value": "7200", "name": "5 Days" },
        { "value": "8640", "name": "6 Days" },
        { "value": "10080", "name": "7 days" }
    ];
 
    public timeZoneList = [{ "value": "IST", "name": "IST" },
        { "value": "PST", "name": "PST" },
        { "value": "UTC", "name": "UTC" }];

    public collectionDuration = [];
    public loaderCollectionDuration: boolean;

    public startCollection = [{ "value": "Now", "name": "Now", "selected": true }, { "value": "Later", "name": "Later" }];
    public showCollectionDate: boolean = false;

    public gridOptions: GridOptions;
    public rowData: any[];
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;

    public disableProjectName: boolean = false;
    @ViewChild('dialogAsPidList') dialogAsPidList;
    constructor(public translate: TranslateService, public wizard: WorkflowManagerComponent, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

        this['asProjectID'] = [];

    }

    ngOnInit() {
        this.loadBasicForm();
        this.loadAsPidForm();
        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No active ASPIDs assigned to you.</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };
    }

    preLoad() {
        this.appService.set("editstep", 0);
        this.disableProjectName = true;
    }

    preLoadOnBack() {
        this.disableProjectName = true;
    }

    loadCollectionDurationList() {

        this.loaderCollectionDuration = true;

        let assessmentType = this.appService.get("filterContextValue").assessment_type[0];
        let platform = 'Nexus';
        this.apiService.getAPI((<any>window).acConfig.getCollectionDurationAPI + assessmentType + '/platforms/' + platform + '/', '').subscribe(
            data => {

                let respData = data.json();
                this.logger.info("collection duration", respData);
                if (respData.length == 0) {
                    let durationentry = { "value": "1", "name": "None", "selected": true };
                    this.appService.set("collectionDurationLabel", "None");
                    this.collectionDuration.push(durationentry);
                    this.assessmentBasicForm.patchValue({ 'collectionDuration': "1" });
                }
                respData.forEach(duration => {

                    let durationentry = { "value": duration.value, "name": duration.name };
                    this.collectionDuration.push(durationentry);

                });
                this.loaderCollectionDuration = false;
                this.updateButtons();

            },
            err => {
                let durationentry = { "value": "1", "name": "None", "selected": true };
                this.collectionDuration.push(durationentry);
                this.appService.set("collectionDurationLabel", "None");
                this.assessmentBasicForm.patchValue({ 'collectionDuration': "1" });
                this.loaderCollectionDuration = false;
                this.updateButtons();
                console.error(err);
            }
            , () => { }
        );

    }

    loadAssessmentTypes() {
        let toaster = this.toaster.nativeElement;
        this.loaderAssessmentType = true;
        this.apiService.getAPI((<any>window).acConfig.getAssessmentTypeListAPI, '').subscribe( 
            data => {
                let respData = data.json();
                this.logger.info("Assessment types", respData);
                respData.forEach((assessmenttype, index) => {
                    let assessmentType = { "value": assessmenttype.name, "name": assessmenttype.name };
                    this.assessmentTypes.push(assessmentType);

                });

                this.loaderAssessmentType = false;
                this.updateFormValues();
                this.updateButtons();

            },
            err => {
                //this.toasterAnchor.createToaster(FusionToaster,"error","Error","Error with loading assessment types. Please check with administrator.",toaster,"");
		this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ASSESSMENTTYPS',{error:err._body}).subscribe((res: string) => {
                let alertMetaData = {
                    "name": "loadassessmenttypes",
                    "title": "Load Assessment Types",
                    "type": "DANGER",
                    "content": res
                }
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
		});
            }
            , () => { }
        );

    }

    loadBasicForm() {
        let projectName = "";//For " + this.appService.get("filterContextValue").customer;
        let tomorrowDate = new Date(new Date().getTime() + 86400000).toISOString().slice(0, 10);
        this.assessmentBasicForm = new FormGroup({
            'projectName': new FormControl(projectName, Validators.required),
            'asProjectID': new FormControl(''),
            'nceCECID': new FormControl(this.appService.get("cecID")),
            'assessmentTypes': new FormControl('', Validators.required),
            'architectureTypes': new FormControl('', Validators.required),
            'usersAllowed': new FormControl(''),
            'description': new FormControl(''),
            'collectionDuration': new FormControl(''),
            'startCollection': new FormControl('Now', Validators.required),
            'startCollectionDate': new FormControl(tomorrowDate),
            'startCollectionTime': new FormControl('00:00'),
            'timeZone': new FormControl('')
        });
        this.loadAssessmentTypes();
        this.getArchitectureTypes();
    }

    loadAsPidForm() {
        this.asPidForm = new FormGroup({
            'asProjectID': new FormControl(this.appService.get("cecID"))
        });
    }

    updateFormValues() {

        this.selected.push(this.appService.get("cecID"));
        let formData = null;
        if (this.appService.get("assessmentId") != "" && this.appService.get("assessmentId") != null) {

            this.selected = [];

            formData = JSON.parse(this.appService.get("assessmentData")).payLoadUI[this.wizard.getStepKey()];
            if (formData != "" && formData != undefined) {
                this.disableProjectName = true;
                formData.usersAllowed.forEach(user => {
                    this.selected.push(user);
                });
                this.logger.info("formData", formData);
                let startCollectionDate = (formData.startCollectionDateandTime != "") ? formData.startCollectionDateandTime.split(" ")[0] : "";
                let startCollectionTime = (formData.startCollectionDateandTime != "") ? formData.startCollectionDateandTime.split(" ")[1] : "";
                this.assessmentBasicForm.patchValue({
                    'projectName': formData.projectName,
                    'asProjectID': formData.asProjectID,
                    'nceCECID': formData.nceCECID,
                    'assessmentTypes': formData.assessmentTypes,
                    'architectureTypes': formData.architectureType,
                    'description': formData.description,
                    'collectionDuration': formData.collectionDuration,
                    'startCollection': formData.startCollection,
                    'startCollectionDate': startCollectionDate,
                    'startCollectionTime': startCollectionTime,
                    'timeZone': formData.timeZone,
                    'usersAllowed': formData.usersAllowed
                });
                this.updateInputArrays(formData.startCollection, this.startCollection, "startCollectionSelection");
                this.updateInputArrays(formData.architectureTypes, this.architectureTypeList, "architectureTypeSelection");
                this.updateInputArrays(formData.assessmentTypes, this.assessmentTypes, "assessmentTypeSelection");
                this.updateInputArrays(formData.collectionDuration, this.periodList, "periodSelection");
                this.updateInputRadio(formData.startCollection, this.startCollection, "startCollectionSelection");
                this.updateInputArrays(formData.timeZone, this.timeZoneList, "timeZoneSelection");
                if (formData.startCollection == "Later") {
                    this.showCollectionDate = true;
                }
                this.getASPID('asProjectID', (<any>window).acConfig.getTVAAPI + '&cecId=' + formData.nceCECID, formData.asProjectID);
            }

        } else {
            this.getASPID('asProjectID', (<any>window).acConfig.getTVAAPI + '&cecId=' + this.assessmentBasicForm.controls.nceCECID.value, "");
            this.assessmentBasicForm.patchValue({ 'nceCECID': this.appService.get("cecID") });
        }

        /*
        if (this.selected.indexOf("vasa") == -1) {
            this.selected.push("vasa");
        }
        */

        if (this.wizard.getWorkflowIndex() < this.appService.get("editstep")) {
            this.wizard.next();
        }
        this.updateButtons();

    }

    updateInputArrays(formdata, inputArray, selection) {
        for (let input of inputArray) {
            delete input['selected'];
            if (input.value == formdata) {
                input['selected'] = true;
                this[selection] = input;
            }
        }
    }
    updateInputRadio(formdata, inputArray, selection) {
        for (let input of inputArray) {
            delete input['selected'];
            if (input.value == formdata) {
                input['selected'] = true;
            }
        }
    }
    onAssessmentTypeChange(selectedAssessmentType) {
        if (selectedAssessmentType != null) {
            this.assessmentBasicForm.patchValue({ 'assessmentTypes': selectedAssessmentType.value });
        } else {
            this.assessmentBasicForm.patchValue({ 'assessmentTypes': '' });
        }
        this.updateButtons();
    }

    onArchitectureTypeChange(selectedArchitectureType) {

        if (selectedArchitectureType != null) {

            this.assessmentBasicForm.patchValue({ 'architectureTypes': selectedArchitectureType.value });

            if(selectedArchitectureType.value == "Routing and Switching"){
                this.assessmentBasicForm.controls.collectionDuration.setValidators([Validators.required]);
                this.assessmentBasicForm.controls.collectionDuration.updateValueAndValidity();
            }else{
                this.assessmentBasicForm.controls.collectionDuration.clearValidators();
                this.assessmentBasicForm.controls.collectionDuration.updateValueAndValidity();
            }
            
        } else {
            this.assessmentBasicForm.patchValue({ 'architectureTypes': '' });
        }
        this.updateButtons();
    }

    onPeriodChange(selectedCollectionDuration) {        
        if (selectedCollectionDuration != null) {
            this.assessmentBasicForm.patchValue({ 'collectionDuration': selectedCollectionDuration.value });
        } else {
            this.assessmentBasicForm.patchValue({ 'collectionDuration': '' });
        }
        this.updateButtons();
    }
    onTimezoneChange(selectedTimezone) {
        if (selectedTimezone != null) {
            this.assessmentBasicForm.patchValue({ 'timeZone': selectedTimezone.value });
        } else {
            this.assessmentBasicForm.patchValue({ 'timeZone': '' });
        }
        this.updateButtons();
    }
    onStartCollectionChange(selectedCollection) {
        this.showCollectionDate = false;
        if (this.assessmentBasicForm.controls.startCollection.value == "Later") {
            this.showCollectionDate = true;
        }
        this.updateButtons();
    }

    getASPID(id, url, selectedID) {
        this.loaderASPID = true;
        this.apiService.getTVAAPI(url, '').subscribe(
            data => {

            },
            err => {
                console.error("tva:error", err);
                this[id] = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
                this.loaderASPID = false;
                /*this.gridOptions.api.setRowData([]);
                this.gridOptions.api.showNoRowsOverlay();
                let alertMetaData = {
                    "name": "getaspid",
                    "title": "Get ASPID",
                    "type": "INFO",
                    "content": "Error getting the ASPIDs. Please try again."
                }
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                */
            }
            , () => { }
        );

        (<any>window).tvaInstance.jsonpCallback = (command, data) => {
            
            this.logger.info("tva data projectSnapShot", data.projectSnapShot);
            this.asPID = [];
            let i = 0;
            let projectSnapShot = data.projectSnapShot;
            if (projectSnapShot != undefined) {

                this.gridOptions.api.setRowData(data.projectSnapShot);
                this.gridOptions.api.hideOverlay();
                this.gridOptions.api.sizeColumnsToFit();

                projectSnapShot.forEach(project => {
                    if (project.projectStatus == 'Active' && project.endCustomerName != "UNKNOWN") {
                        let selected = false;
                        if (selectedID != "" && selectedID == project.projectId) {
                            selected = true;
                        }
                        let projectentry = { "value": project.projectId, "name": project.projectName + " (" + project.projectId + ")", "selected": selected };
                        this.asPID.push(projectentry);
                        i++;
                    }
                    if (i == 0) {
                        this.asPID = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
                    }
                });

            } else {
                this.asPID = [{ "value": -1, "name": "No active ASPIDs assigned to you." }];
                this.gridOptions.api.setRowData([]);
                this.gridOptions.api.showNoRowsOverlay();
            }
            this[id] = this.asPID;
            this.logger.info("as pid list", this[id]);
            this.loaderASPID = false;
        };
    }

    public onSave() {

        if (this.isValidated()) {

            let data = this.prepareData();
            data.action = "save";
            data.status = "draft";
            this.postToWorkFlowAPI(data, true, "saveButton");

        }

    }

    public onNext() {
        let data = this.prepareData();
        data.action = "next";
        data.status = "draft";
        this.postToWorkFlowAPI(data, false, "nextButton");
    }

    postToWorkFlowAPI(data, showtoaster, action) {

        this.wizard.setLoaderEnabled(action);
        this.logger.info("Post:assessmentData", data);
        let toaster = this.toaster.nativeElement;

        this.apiService.postUrl((<any>window).acConfig.postAssessmentDataWorkflowAPI, JSON.stringify(data)).subscribe(
            (result) => {

                if (result.status === 201) {

                    let respData = result.json();
                    respData.payLoadUI = JSON.parse(this.appService.get("assessmentData")).payLoadUI;
                    this.appService.set("processID", respData.processId);
                    this.appService.set("assessmentData", JSON.stringify(respData));
                    this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));

                    if (showtoaster) {

                        let assessmentID = respData.assessmentId;
                        if (assessmentID != "") {
			  this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.SAVEINITIATE',{project:assessmentID}).subscribe((res: string) => {
                            let alertMetaData = {
                                "name": "saveassessment",
                                "title": "Save Assessment - Project Details",
                                "type": "SUCCESS",
                                "content": res
                            }
                            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
    			  });
                        } else {
			    this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.SAVEINITIATE',{project:assessmentID}).subscribe((res: string) => {
                            let alertMetaData = {
                                "name": "saveassessment",
                                "title": "Save Assessment - Project Details",
                                "type": "INFO",
                                "content": res
                            }
                            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			  });
                        }
                        //this.toasterAnchor.createToaster(FusionToaster,"success","Success","Saved successfully!",toaster,"");

                    }

                } else {

                    if (showtoaster) {
			this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.INFO',{data:result.statusText}).subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "saveassessment",
                            "title": "Save Assessment - Project Details",
                            "type": "INFO",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
                        //this.toasterAnchor.createToaster(FusionToaster,"warning","Info",result.statusText,toaster,"");
                    }

                }

                this.wizard.setLoaderDisabled(action);

            },
            (err) => {

                this.wizard.setLoaderDisabled(action);

                if (showtoaster) {
		    this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ERROR',{error:err._body}).subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "saveassessment",
                        "title": "Save Assessment - Project Details",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    //this.toasterAnchor.createToaster(FusionToaster,"error","Failure",err._body,toaster,"");
		});
                }

            });

    }

    public prepareData() {

        let data = Object.assign({}, this.assessmentBasicForm.value);
        let startCollectionDate = data.startCollectionDate;
        let startCollectionTime = data.startCollectionTime;
        let timeZone = (data.timeZone == undefined) ? "" : data.timeZone;
        /*
        if (this.selected.indexOf("vasa") == -1) {
            this.selected.push("vasa");
        }
        */
        let startCollectionDateandTime = (data.startCollection == "Later" && startCollectionDate != undefined && startCollectionDate != "") ? startCollectionDate + " " + startCollectionTime + " " + timeZone : "";
        timeZone = (data.startCollection == "Later" && startCollectionDate != undefined && startCollectionDate != "") ? timeZone : "";
        data.collectionDuration = (data.collectionDuration != null && data.collectionDuration != "") ? data.collectionDuration : "10";
        data.usersAllowed = this.selected;
        data.startCollectionDateandTime = startCollectionDateandTime;
        data.timeZone = timeZone;
        delete data.startCollectionDate;
        delete data.startCollectionTime;
        let assessmentData = JSON.parse(this.appService.get("assessmentData"));
        assessmentData.step = this.wizard.getWorkflowIndex();
        assessmentData.stepKey = this.wizard.getStepKey();
        assessmentData.payLoad = Object.assign({}, data);
        assessmentData.payLoadUI[this.wizard.getStepKey()] = data;
        this.appService.set("assessmentData", JSON.stringify(assessmentData));
        assessmentData.payLoadUI = {};
        this.logger.info("assessmentData", assessmentData);
        return assessmentData;

    }

    public isValidated() {

        if (this.assessmentBasicForm.controls.startCollection.value == "Later" && this.assessmentBasicForm.controls.startCollectionDate.value == "") {
            return false;
        }

        if (this.assessmentBasicForm.valid && this.selected.length > 0 && !this.isError) {
            return true;
        }
        return false;

    }

    public changeModel(event) {

        this.updateButtons();

    }

    updateButtons() {
        if (this.isValidated()) {
            this.wizard.setEnabled('nextButton');
            this.wizard.setEnabled('saveButton');
            this.formComplete = true; 
        } else {
            this.wizard.setDisabled('nextButton');
            this.wizard.setDisabled('saveButton');
            this.formComplete = false;
        }

    }

    filter() {


        let query = this.assessmentBasicForm.controls.usersAllowed.value;
        let options = "";
        let toaster = this.toaster.nativeElement;

        if (this.selected.indexOf(query) != -1) {
            query = "";
            this.assessmentBasicForm.patchValue({ 'usersAllowed': '' });
            //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","Same user has been added already. Please look up for different user.",toaster,"");
	    this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.ADDUSER').subscribe((res: string) => {
            let alertMetaData = {
                "name": "initiateassessment",
                "title": "User Lookup",
                "type": "INFO",
                "content": res
            }
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
	    });
        }

        if (query !== "" && query.length >= 2) {

            this.loaderLookup = true;
            this.apiService.getExternalAPI((<any>window).acConfig.getUsersAPI + '?q=' + query + '&h=1000000000', '').subscribe( //?q=manikandan&h=1000000000

                data => {

                    this.logger.info("user api", data);

                    if (data['_body'] != "") {

                        let respdata = data.json();
                        let userObj = [];
                        let users = respdata.suggest['user-suggest'];
                        users.forEach(useroption => {
                            useroption.options.forEach(user => {
                                userObj.push({ "cecID": user._source.cecid, "name": user._source.name + "(" + user._source.cecid + ")" });
                            });
                        });

                        this.logger.info("userObj", userObj);
                        this.filteredList = userObj;
                        this.loaderLookup = false;

                    } else {
                        this.loaderLookup = false;
                        //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","User suggestion API is down. Please try after some time.",toaster,"");
                        this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.USERAPI').subscribe((res: string) => {
                        let alertMetaData = {
                            "name": "initiateassessment",
                            "title": "User Lookup",
                            "type": "INFO",
                            "content": res
                        }
                        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
		    });
                    }

                },
                err => {
                    this.loaderLookup = false;
                    //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","User suggestion API is down. Please try after some time.",toaster,"");
                    this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.USERAPI').subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "initiateassessment",
                        "title": "User Lookup",
                        "type": "INFO",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.logger.info(err);
                }
                , () => { }
            );

        } else {
            this.filteredList = [];
        }

    }

    select(item, event) {

        let toaster = this.toaster.nativeElement;

        if (this.selected.indexOf(item.cecID) == -1) {
            this.selected.push(item.cecID);
        } else {
            //this.toasterAnchor.createToaster(FusionToaster,"warning","Info","Same user has been added already. Please add different user.",toaster,"");
            this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.ADDUSER').subscribe((res: string) => {
            let alertMetaData = {
                "name": "initiateassessment",
                "title": "User Lookup",
                "type": "INFO",
                "content": res
            }
            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            });
        }
        this.filteredList = [];
        this.assessmentBasicForm.patchValue({ 'usersAllowed': '' });
        this.changeModel(event);

    }

    remove(item, event) {
        this.selected.splice(this.selected.indexOf(item), 1);
        this.changeModel(event);
    }
    public fetchAsPidList() {
        let dialog = this.dialogAsPidList;
        dialog.width = "60%";
        dialog.height = "90%";
        this.loadAsPidForm();
        this.showPids('asProjectID');
        dialog.showDialog();
    }
    public createColumnDefs() {
        this.columnDefs = [
            {
                headerName: "Project Id", field: "projectId", width: 200, sortingOrder: ['asc', 'desc'], cellRendererFramework: AsPidLinkComponent, pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Project Name", field: "projectName", width: 300, sortingOrder: ['asc', 'desc'], pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Type", field: "projectType", width: 300, sortingOrder: ['asc', 'desc'], pinned: true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
        ];
        return this.columnDefs;
    }

    public calculateRowCount() {
        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }

    public onProjectSelection(id) {
        this.assessmentBasicForm.patchValue({ 'asProjectID': id });
        let dialog = this.dialogAsPidList;
        dialog.cancelAction();
    }
    public close() {
        let dialog = this.dialogAsPidList;
        dialog.cancelAction();
    }
    getArchitectureTypes() {
        this.apiService.getAPI((<any>window).acConfig.getArchitectureTypes, '').subscribe(
            data => {
                let respData = data.json();
                let architectureList = [];
                respData.forEach((architecture, index) => {
                    architectureList.push({ "value": architecture.type, "name": architecture.type });
                });
                this.architectureTypeList = architectureList;
            },
            err => {
                console.error(err);
            }
            , () => { }
        );
    }
    checkDuplicate(formControlName) {
        var name = this.assessmentBasicForm.controls[formControlName].value.trim();
        if(name!=""&&name.length<3){
            this.isError = true;
            this.errorMessage = "Project name should have min 3 letters";
        }
        else if(/^[a-zA-Z0-9- _]*$/.test(name))
        {
            var firstChar=this.assessmentBasicForm.controls[formControlName].value.charAt(0);
            if("-,".indexOf(firstChar)!=-1){
                this.isError = true;
                this.errorMessage = "Project name should start with letters or digits or _";
            }
            else{               
                let url = (<any>window).acConfig.getAssessmentListAPI + "/" + name;
                url = encodeURI(url);
                this.apiService.getAPI(url, '').subscribe(
                    data => {
                        this.isError = false;
                        this.errorMessage = "";
                        if (data.status == 200) {
                            this.isError = true;
                            this.errorMessage = "Project name already exist.";
                        }
                        this.updateButtons();
                    },
                    err => {
                        this.isError = true;
                        this.errorMessage = "Invalid project name";
                        if (err.status == 404) {
                            this.isError = false;
                            this.errorMessage = "";
                        }
                        this.updateButtons();
                        console.error(err);
                    }
                    , () => { }
                );
            }
        }
        else{
            this.isError=true;
            this.errorMessage="Project name can contain only letters, digits, _ , - and space";
        }
    }
    public showPids(formControlName) {
        this.gridOptions.api.showLoadingOverlay();
        this.getASPID('asProjectID', (<any>window).acConfig.getTVAAPI + '&cecId=' + this.asPidForm.controls[formControlName].value, "");
        this.assessmentBasicForm.patchValue({ 'nceCECID ': this.asPidForm.controls[formControlName].value });
    }
}