import { Component, ViewChild, ElementRef, ViewEncapsulation, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

@Component({
  selector: 'collector-and-devices',
  templateUrl: './collector.template.html',
  styleUrls: [ './collector.style.css' ],
  encapsulation: ViewEncapsulation.None,
  host: {'class':"dynamic-component"},
  entryComponents: [ FusionToaster ]
})
export class CollectorComponent {
	
  public assessmentCollectorForm: FormGroup;
  public collectorNames: any[];
  public selectedDevices:any;
  public selectedDevicesLength:number;
  
  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public loaderCollector:boolean;

  public testManualUpload:any;

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  @ViewChild('manualUpload') manualUpload: any;
	
  public manualUploadLabel = [{"name": "Do you want to do manual upload?", "value": 1}];
  public showManualFileUpload:boolean = false;
  public noOfCommandsExcluded:number;
  public noOfCommandsIncluded:number;

  public icList: any = [];
  public selectedOSTypes: any = [];
  constructor(public translate: TranslateService, public wizard : WorkflowManagerComponent, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
  
        //this.rowModelPaginationType = "inMemory";
		
		this.selectedDevicesLength = 0;

		// we pass an empty gridOptions in, so we can grab the api out
        this.gridOptions = <GridOptions>{			
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">Select a collector to view associated devices</span>',
			overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };  
        
  }
  
  ngOnInit(){

	this.loadCollectorForm();	
	
  }

  preLoadOnBack(){
  }

  preLoad(){
	
	this.gridOptions.api.sizeColumnsToFit();
	let formData = null;
	this.loadCatalog();
	if((this.appService.get("assessmentId") != "" && this.appService.get("assessmentId") != null) || JSON.parse(this.appService.get("assessmentData")).assessmentId != ""){
		
	  formData = JSON.parse(this.appService.get("assessmentData")).payLoadUI[this.wizard.getStepKey()];
	  this.logger.info("formData: collector", formData);

	  if(formData != "" && formData != undefined){

		if(formData.collectorID != "" && formData.collectorID != undefined){
			this.assessmentCollectorForm.patchValue({'collectorID': formData.collectorID});
			this.getDevices(this.appService.get("cpyKey"), formData.collectorID, formData.deviceIdList, this.appService.get("editstep"));
		}else{
			this.logger.info("preload:formData.collectorID", formData.collectorID);
			this.gridOptions.api.showNoRowsOverlay();
		}
		
	  }

	}else{

		this.loadCollectorList();
		this.assessmentCollectorForm.patchValue({'collectorID': ''});
		this.gridOptions.api.hideOverlay();
		this.gridOptions.api.setRowData([]);
		this.gridOptions.api.showNoRowsOverlay();

	}

	this.appService.set("editstep", 0);

  }

  loadCatalog(){

	let assessmentData = JSON.parse(this.appService.get("assessmentData"));		
	let assessmentType = assessmentData.payLoadUI.basicDetails.assessmentTypes;
	let catalogurl = (<any>window).acConfig.getCatalogDetailsAPI + assessmentType;
	this.apiService.getUrl(catalogurl, '').subscribe(
		data => {
			this.icList = Object.assign({}, data.icSubset);
		},
		err => {
			console.error(err);
			this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.COLLECTORICLOAD').subscribe((res: string) => {
			let alertMetaData = {
				"name": "loadcatalog",
				"title" : "Get catalog details",
				"type":"DANGER",
				"content": res
			}    
			this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
		}
		,() => {}
	);

  }

  loadCollectorList(){

	this.loaderCollector = true;
	this.collectorNames = [];

	let formData = null;
	let collectorID:any = "";
	if(this.appService.get("assessmentId") != "" && this.appService.get("assessmentId") != null){
		formData = JSON.parse(this.appService.get("assessmentData")).payLoadUI['collectorAndDevices'];
		if(formData != "" && formData != undefined){
			collectorID = formData.collectorID;
		}
	}

	this.apiService.getAPI((<any>window).acConfig.getCollectorAPI + this.appService.get("cpyKey"), '').subscribe(
        data => {

			if(data.status == 200){
				let respData = data.json();
				this.logger.info("collector", respData);
				respData.forEach(collector => {

					let collectorentry:any = "";

					if(collectorID != "" && collectorID == collector.applianceId){
						collectorentry = {"value": (collector.applianceId), "name": (collector.applianceId + " (" + collector.collector + ")"), "selected": true};
					}else{
						collectorentry = {"value": (collector.applianceId), "name": (collector.applianceId + " (" + collector.collector + ")")};
					}

					this.collectorNames.push(collectorentry);

				});
				this.loaderCollector = false;
			}else{
				this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.LOADCOLLECTOR').subscribe((res: string) => {
				let alertMetaData = {
					"name": "getcollector",
					"title" : "Get Collector",
					"type":"INFO",
					"content": res
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.loaderCollector = false;
				this.logger.error(data.statusText);
			}
			//this.assessmentCollectorForm.patchValue({'collectorID': this.collectorNames[1].value+'::'+this.collectorNames[1].name});
			if(collectorID == ""){
				this.gridOptions.api.showNoRowsOverlay();
			}

        },
        err => {
			this.loaderCollector = false;
			this.logger.error(err);
			this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.LOADCOLLECTOR').subscribe((res: string) => {
			let alertMetaData = {
				"name": "getcollector",
				"title" : "Get Collector",
				"type":"INFO",
				"content": res
			}    
			this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
		}
        ,() => {}
	);	
	
  }
  
  loadCollectorForm(){

	this.assessmentCollectorForm = new FormGroup({
	  'collectorID': new FormControl('', Validators.required),
	  'devices': new FormControl(''),
	  'isManualUpload': new FormControl(''),
	  'manualFileUpload': new FormControl('')
	});
	
	this.loadCollectorList();
	
  }

  public onSave(){
	
		if( this.isValidated() ){

			let data = this.prepareData();
			data.action = "save";
			data.status = "draft";
			this.postToWorkFlowAPI(data, true, "saveButton");			
	
		}
	
  }

  public showDialog( dialog ){
	dialog.width = "25%";
	dialog.showDialog();
  }

public onNext(){    
	let data = this.prepareData();
	data.action = "next";
	data.status = "draft";
	this.postToWorkFlowAPI(data, false, "nextButton");    
}

postToWorkFlowAPI(data, showtoaster, action){

	this.wizard.setLoaderEnabled(action);
	this.logger.info("Post:assessmentData", data);
	let toaster = this.toaster.nativeElement;
	this.apiService.postUrl((<any>window).acConfig.postAssessmentDataWorkflowAPI, JSON.stringify(data)).subscribe(
		(result) => {
		
		if(result.status === 201){

		let respData = result.json();
		respData.payLoadUI = JSON.parse(this.appService.get("assessmentData")).payLoadUI;
		this.appService.set("processID", respData.processId);
		this.appService.set("assessmentData",JSON.stringify(respData));
		this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));

		if(showtoaster){
			//this.toasterAnchor.createToaster(FusionToaster,"success","Success","Saved successfully!",toaster,"");
			let assessmentID = respData.assessmentId;
			if(assessmentID != ""){
				this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.SAVECOLLECTOR',{assessment:assessmentID}).subscribe((res: string) => {
				let alertMetaData = {
					"name": "saveassessment",
					"title" : "Save Assessment - Data Source",
					"type":"SUCCESS",
					"content": res
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
			}
		}
		
		}else{

		if(showtoaster){
			this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.SAVECOLLECTOR',{data:result.statusText}).subscribe((res: string) => {
			let alertMetaData = {
				"name": "saveassessment",
				"title" : "Save Assessment - Data Source",
				"type":"INFO",
				"content": res        
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
			//this.toasterAnchor.createToaster(FusionToaster,"warning","Info",result.statusText,toaster,"");
		}
		
		}

		this.wizard.setLoaderDisabled(action);			  

		},
		(err) => {

			this.wizard.setLoaderDisabled(action);				

			if(showtoaster){
			this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ERROR',{error:err._body}).subscribe((res: string) => {
				let alertMetaData = {
					"name": "saveassessment",
					"title" : "Save Assessment -Data Source",
					"type":"DANGER",
					"content": res       
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
				//this.toasterAnchor.createToaster(FusionToaster,"error","Error",err._body,toaster,"");
			}

		});
		
	}
	
	public prepareData(){
	
		let data = this.assessmentCollectorForm.value;     
		
		let selectedDevices = [];
		let selectedDeviceIds = [];
		let selectedDeviceNames = [];
		let selectedNodes = this.gridOptions.api.getSelectedNodes();		
		
		for(let i=0;i<selectedNodes.length;i++){
			 
			  let devices = {
				"deviceId": selectedNodes[i].data.deviceId,
				"deviceSysname": selectedNodes[i].data.deviceSysname,
				"ipAddress": selectedNodes[i].data.ipAddress,
				"deviceType": selectedNodes[i].data.deviceType,
				"swVersion": selectedNodes[i].data.swVersion,	
				"swType": selectedNodes[i].data.swType,							
				"productFamily": selectedNodes[i].data.productFamily
			  };
			  selectedDevices.push(devices);	
			  selectedDeviceIds.push(selectedNodes[i].data.deviceId.toString());
			  selectedDeviceNames.push(selectedNodes[i].data.deviceSysname);
		}
		data.devices = selectedDevices;
		data.deviceIdList = selectedDeviceIds;
		data.deviceNames = selectedDeviceNames;
		
		data.customCommands = JSON.parse(this.appService.get("customCommands"));
		data.excludedSNMPs = JSON.parse(this.appService.get("excludedSNMPs"));
		data.excludedCLIs = JSON.parse(this.appService.get("excludedCLIs"));
		
		let excludedICs = [];
		for(let command of data.excludedSNMPs) {
			excludedICs.push(command.icList.join(","));
		}
		for(let command of data.excludedCLIs) {
			excludedICs.push(command.icList.join(","));
		}

		let icSet = JSON.parse(this.appService.get("icSet"));
		let includedICs = icSet.filter(x => !excludedICs.includes(x));
		data.excludedICs = excludedICs;
		data.includedICs = includedICs;

		let assessmentData = JSON.parse(this.appService.get("assessmentData"));
		assessmentData.step = this.wizard.getWorkflowIndex();
		assessmentData.stepKey = this.wizard.getStepKey();
		assessmentData.payLoad = Object.assign({}, data);
		assessmentData.payLoad.collectorID = this.assessmentCollectorForm.controls.collectorID.value.split("::")[0];
		assessmentData.payLoadUI[this.wizard.getStepKey()] = data;
		this.appService.set("assessmentData",JSON.stringify(assessmentData));
		assessmentData.payLoadUI = {};
		this.logger.info("assessmentData step 2", assessmentData);
		return assessmentData;
	}

  	public isValidated(){
		
		let selectedNodes = this.gridOptions.api.getSelectedNodes();		
		if(this.assessmentCollectorForm.valid && selectedNodes.length > 0){
		  return true;
		}
		return false;
	
	}

	public onRowSelected($event) {

		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		this.selectedDevices = selectedNodes;
		this.selectedDevicesLength = selectedNodes.length;
		this.updateButtons();		

	}
	
	updateButtons(){

		if( this.isValidated() ){
			this.wizard.setEnabled('nextButton');
			this.wizard.setEnabled('saveButton');
		}else{
			this.wizard.setDisabled('nextButton');
			this.wizard.setDisabled('saveButton');
		}

	}

	onManualUploadChange(event){
		
		let target = event.target || event.srcElement || event.currentTarget;
		this.assessmentCollectorForm.patchValue({'manualFileUpload': ''});
		this.showManualFileUpload = false;
		if(target.checked){
			this.showManualFileUpload = true;
		}

	}

	onFileUploadChange(event) {
		
		let toaster = this.toaster.nativeElement;
		this.assessmentCollectorForm.patchValue({'manualFileUpload': ''});
		if(event.target.files.length > 0) {

			let file = event.target.files[0];
			let fileTypes = ["application/zip", "application/x-zip", "application/x-zip-compressed", "application/octet-stream", "application/x-compress", "application/x-compressed", "multipart/x-zip", "application/x-rar-compressed"];
			this.logger.info("upload file", file);			
			if ( fileTypes.indexOf(file.type) != -1 ) {
				this.testManualUpload = file;
			}else{
				this.manualUpload.nativeElement.value = "";
				this.testManualUpload = "";
				//this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", "You are allowed to upload only zip file.",toaster, "");
				this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.UPLOADZIP').subscribe((res: string) => {
				let alertMetaData = {
					"name": "manualupload",
					"title" : "Manual Upload",
					"type":"INFO",
					"content": res      
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				//this.logger.info("upload file empty", this.manualUpload.nativeElement.files);
			}

		}
		
	}

	uploadTestManualUpload(){

		let toaster = this.toaster.nativeElement;
		let fileTypes = ["application/zip", "application/x-zip", "application/x-zip-compressed", "application/octet-stream", "application/x-compress", "application/x-compressed", "multipart/x-zip", "application/x-rar-compressed"];
		

		if(this.assessmentCollectorForm.controls.isManualUpload.value && this.testManualUpload != ""){

		  let formData:FormData = new FormData();
		  formData.append("file", this.testManualUpload);
		  this.logger.info("formData", formData);

		  this.apiService.postFile((<any>window).acConfig.fileUploadAPI, formData).subscribe(
			(result) => {

				this.logger.info("fileupload result", result);
				if(result.status === 200){

					this.logger.info("result", (<any>result)._body);
					this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.UPLOAD',{result:(<any>result)._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "manualupload",
						"title" : "Manual Upload - Success",
						"type":"SUCCESS",
						"content": res
					}
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.assessmentCollectorForm.patchValue({'manualFileUpload': this.testManualUpload.name});

				}else{
					this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.UPLOAD').subscribe((res: string) => {
					let alertMetaData = {
						"name": "manualupload",
						"title" : "Manual Upload - Failure",
						"type":"DANGER",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.assessmentCollectorForm.patchValue({'manualFileUpload': ''});

				}
			  
			  
		  },
		  (err) => {
			  this.assessmentCollectorForm.patchValue({'manualFileUpload': ''});
			  this.logger.info("fileupload error", err);
			  //this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", "Error during file upload. Please try again.",toaster, "");
			  this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.UPLOAD').subscribe((res: string) => {
			  let alertMetaData = {
				"name": "manualupload",
				"title" : "Manual Upload - Failure",
				"type":"DANGER",
				"content": res         
			  }    
			  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
		  });
		  });

		}else{
			//this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", "Please upload only zip file.",toaster, "");
			this.translate.get('NOTIFICATIONINFO.PROJECTCREATE.UPLOADZIP').subscribe((res: string) => {
			let alertMetaData = {
				"name": "manualupload",
				"title" : "Manual Upload - Failure",
				"type":"INFO",
				"content": res
			}    
			this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			});
		}

	}


  	onCollectorChange(event){

		//this.logger.info("collector id", target.value);
		if(event.value != ""){

			this.assessmentCollectorForm.patchValue({'collectorID': event.value});
			this.getDevices(this.appService.get("cpyKey"), event.value, "", 0);

		}else{

			this.gridOptions.api.setRowData([]);
			this.gridOptions.api.showNoRowsOverlay();

		}

		this.onRowSelected(event);

	}
	  
	getDevices(cpyKey, collectorID, selectednodes, editstep){
		
		this.logger.info("getDevices:collectorID", collectorID);
		
		let assessmentData = JSON.parse(this.appService.get("assessmentData"));

		this.gridOptions.api.showLoadingOverlay();
		//http://10.126.187.14:9001/v1/assessmentui/devices/176691/collector/npm6
		//POST /v1/assessmentui/devices/{cpyKey}/collector/{collector}/assessmentType/{assessmentType}/platformType/{platformType}

		if(collectorID != undefined && collectorID != "" && cpyKey != undefined && cpyKey != ""){
			let url = (<any>window).acConfig.getDevicesAPI + cpyKey + '/collector/' + collectorID;
			this.apiService.getAPI(url, '').subscribe(
				data => {

					this.gridOptions.api.setRowData(data.json());
					this.gridOptions.api.hideOverlay();

					this.logger.info("selectednodes", selectednodes);

					this.gridOptions.api.forEachNode( (node) => {

						this.logger.info("deviceId: index", selectednodes.indexOf(node.data.deviceId.toString()));
						
						if ( selectednodes.indexOf(node.data.deviceId.toString()) != -1 ) {
						node.setSelected(true);
						}
						
					});

					if(this.wizard.getWorkflowIndex() < editstep){
						//this.wizard.next();
					}

				},
				err => {
					this.logger.error(err);
					this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.DEVICELIST').subscribe((res: string) => {
					let alertMetaData = {
						"name": "getdevices",
						"title" : "Get Devices",
						"type":"INFO",
						"content": res        
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
					this.gridOptions.api.setRowData([]);
					this.gridOptions.api.showNoRowsOverlay();
				}
				,() => {}
			);
		}

	}
  
  public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectAllDevices",
				width: 50,
				headerCheckboxSelection: true,
				headerCheckboxSelectionFilteredOnly: true,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},
			 {headerName: "Device ID", field: "deviceId", hide:true },
             {headerName: "Device Sys Name", field: "deviceSysname",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "deviceSysname", headerTooltip: "Device Sys Name",
	            icons: {
		            sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
		            sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
	        	},
	        	
           
             },
			 {headerName: "IP Address", field: "ipAddress",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "ipAddress", headerTooltip: "IP Address",
	            icons: {
		            sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
		            sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
	        	},
	        	
           
             },
			 {headerName: "Device Type", field: "deviceType",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "deviceType", headerTooltip: "Device Type",
	            icons: {
		            sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
		            sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
	        	},
             },
			 {headerName: "Device Version", field: "swVersion",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "swVersion", headerTooltip: "Device Version",
	            icons: {
		            sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
		            sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
	        	},           
			 },
			 {headerName: "OS Type", field: "swType",width: 100, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "swType", headerTooltip: "OS Type",
			 icons: {
				 sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				 sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
			 },		
			},
			{headerName: "Product Family", field: "productFamily",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "productFamily", headerTooltip: "Product Family",
			icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
			},		
			},
		];
		return this.columnDefs;

    }

    public calculateRowCount() {
        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }
	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady(event) {
        //this.logger.info('onReady');
		this.calculateRowCount();
	}

	public excludeCommandChange(value){
		this.noOfCommandsExcluded = value;
	}

	public customCommandsForCollection(value){
		this.noOfCommandsIncluded = JSON.parse(value).length;
	}
	
}