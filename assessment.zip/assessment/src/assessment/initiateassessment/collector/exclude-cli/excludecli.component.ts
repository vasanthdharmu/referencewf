import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, Input, EventEmitter, SimpleChange } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

@Component({
	selector: 'exclude-cli',
    templateUrl: './excludecli.template.html',
    styleUrls: [ './excludecli.style.css' ],
    encapsulation: ViewEncapsulation.None,
})
export class ExcludeCLIComponent {


	public gridOptions:GridOptions;
	public rowData: any[];
	public columnDefs: any[];
	public rowCount: string;
	public tableDataSource: any[];
	public rowModelPaginationType:string;

	public excludedCLIs:Array<any> = [];	

	@Output() excludeCLICommandChange: EventEmitter<any> = new EventEmitter();
	@Output() clickShowAllICs: EventEmitter<any> = new EventEmitter();

	@Input() cliCommands:any = [];

	constructor(public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
		
			  //this.rowModelPaginationType = "inMemory";
	  
			  // we pass an empty gridOptions in, so we can grab the api out
			  this.gridOptions = <GridOptions>{
				  suppressRowClickSelection: true,
				  rowSelection: 'multiple',
				  paginationPageSize: 10,
				  pagination: true,
				  enableFilter: true,
				  floatingFilter: true,
				  columnDefs: this.createColumnDefs(),			
				  overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No CLI Commands</span>',
				  overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
			  };

	}

	ngOnInit() {

		//this.loadCLICommands();		
		//this.loadCLIGrid(this.cliCommands);
		
	}

	ngOnChanges(changes: {[propKey: string]: SimpleChange}) {

		let log: string[] = [];
		for (let propName in changes) {
		  let changedProp = changes[propName];
		  if (changedProp.isFirstChange()) {
		  } else {
			let from = JSON.stringify(changedProp.previousValue);
			const commandsArray = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);				
			this.loadCLIGrid(commandsArray);
		  }
		}

	}

	public loadCLIGrid(data){

		if(data.length > 0){
			
			this.gridOptions.api.setRowData(data);
			this.gridOptions.api.sizeColumnsToFit();
			this.gridOptions.api.hideOverlay();

			let collectorAndDevices  = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'];
			let excludedCLIs = [];

			if(collectorAndDevices != "" && collectorAndDevices != undefined){
		
				excludedCLIs = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'].excludedCLIs;
		
			}

			this.gridOptions.api.forEachNode( (node) => {

				if(excludedCLIs != undefined && excludedCLIs.length != 0){

					if(!this.containsObject(node.data.command, excludedCLIs)){
						node.setSelected(true);
					}

				}else{
					node.setSelected(true);
				}
				
			});

		}else{
			this.gridOptions.api.setRowData([]);
			this.gridOptions.api.showNoRowsOverlay();
		}

	}

	public loadCLICommands(){
		
		let url = (<any>window).acConfig.getCLICommandsAPI;
		this.apiService.getUrl(url, '').subscribe(
			data => {

				this.gridOptions.api.setRowData(data);
				this.gridOptions.api.sizeColumnsToFit();
				this.gridOptions.api.hideOverlay();

				let collectorAndDevices  = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'];
				let excludedCLIs = [];

				if(collectorAndDevices != "" && collectorAndDevices != undefined){
			
				  excludedCLIs = JSON.parse(this.appService.get("assessmentData")).payLoadUI['collectorAndDevices'].excludedCLIs;
			
				}

				this.gridOptions.api.forEachNode( (node) => {

					if(excludedCLIs != undefined && excludedCLIs.length != 0){

						if(!this.containsObject(node.data.command, excludedCLIs)){
							node.setSelected(true);
						}

					}else{
						node.setSelected(true);
					}
					
				});

				this.gridOptions.api.sizeColumnsToFit();

			},
			err => {

				this.gridOptions.api.setRowData([]);
				this.gridOptions.api.showNoRowsOverlay();
				/*
				let alertMetaData = {
					"name": "manualupload",
					"title" : "Manual Upload - Failure",
					"type":"DANGER",
					"content": "Error during file upload. Please try again."         
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				*/
			}
			,() => {}
		);

	}
	
	public containsObject(command, list) {
		let i;
		for (i = 0; i < list.length; i++ )
		{
			if (list[i].command == command)
			{
				return true;
			}
		}
		return false;
	}
	

	public createColumnDefs() {
		
		  this.columnDefs = [
			  {
				  headerName: "",
				  field: "selectAllCommands",
				  width: 50,
				  headerCheckboxSelection: true,
				  headerCheckboxSelectionFilteredOnly: true,
				  checkboxSelection: true,
				  pinned: true,
				  suppressFilter: true
			  },
			  {headerName: "Commands", field: "command",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "command", headerTooltip: "Command",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }
			  },
			  {headerName: "OS Type", field: "ostypes",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "ostypes", headerTooltip: "OS Type",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }	
			  },
			  {headerName: "Repetitions / Interval", field: "frequency",width: 250, sortingOrder: ['asc','desc'], pinned: true,  cellRenderer:this.formatRepetition, headerTooltip: "Repetitions / Interval",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }
			  }
		  ];
		  return this.columnDefs;
  
	}

	formatRepetition(params){
		
		let frequency = params.data.frequency != "" ? params.data.frequency : params.data.repetition;
		return frequency;
				
	}
  
	public calculateRowCount() {
		if (this.gridOptions.api && this.rowData) {
			var model = this.gridOptions.api.getModel();
			var totalRows = this.rowData.length;
			var processedRows = model.getRowCount();
			this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
	}
	

	public onModelUpdated() {
		this.calculateRowCount();
	}

	public onReady(event) {
		//this.logger.info('onReady');
		this.calculateRowCount();
	}

	public onRowSelected($event) {
		
		this.excludedCLIs = [];
		this.gridOptions.api.forEachNode( (node) => {
			
			if(!node.isSelected() && !this.containsObject(node.data.command, this.excludedCLIs)){
				this.excludedCLIs.push(node.data);
			}else{
				
			}

		});
		this.appService.set("excludedCLIs", JSON.stringify(this.excludedCLIs));

		let length = this.excludedCLIs.length;
		this.excludeCLICommandChange.emit(length);
	}

	public checkICInCommands(ICName, ICs){	
		if(ICName != undefined && ICName != ""){
			if(this.checkICNameinICs(ICName, ICs)){
				return true;
			}
			return false;
		}
		return true;
	}

	public checkICNameinICs(ICName, ICs){
		let i;
		for (i = 0; i < ICs.length; i++ )
		{
			//if (ICs[i].Name == ICName)
			if (ICs[i].toLowerCase().indexOf(ICName.toLowerCase()) >= 0)
			{
				return true;
			}
		}
		return false;
	}

	public showICDialog(){
		this.clickShowAllICs.emit('');
	}
	
}