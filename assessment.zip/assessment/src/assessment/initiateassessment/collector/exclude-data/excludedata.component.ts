import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter, Input, SimpleChange } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod, URLSearchParams, Jsonp } from '@angular/http';
import { GridOptions } from 'ag-grid/main';
import { Observable } from 'rxjs/Observable';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

@Component({
	selector: 'exclude-data',
    templateUrl: './excludedata.template.html',
    styleUrls: [ './excludedata.style.css' ],
    encapsulation: ViewEncapsulation.None,
})
export class ExcludeDataComponent {


	public gridOptions:GridOptions;
	public rowData: any[];
	public columnDefs: any[];
	public rowCount: string;
	public tableDataSource: any[];
	public rowModelPaginationType:string;

	public gridOptionsIC:GridOptions;
	public rowDataIC: any[];
	public columnDefsIC: any[];
	public rowCountIC: string;
	public tableDataSourceIC: any[];
	public rowModelPaginationTypeIC:string;
	public isAssessmentTypeChanged:boolean=false;
	public excludedSNMPs:Array<any> = [];	

	@ViewChild('dialogICs') dialogICs;
	@Output() excludeCommandChange: EventEmitter<any> = new EventEmitter();

	public snmpCommands:any[]=  [];
	public cliCommands:any[]=  [];
	public ics:any[]=  [];

	@Input() icList:any = [];
	constructor(public translate: TranslateService,public http:Http, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
		
			  this.appService.set("icSet", JSON.stringify([]));
			  //this.rowModelPaginationType = "inMemory";
	  
			  // we pass an empty gridOptions in, so we can grab the api out
			  this.gridOptions = <GridOptions>{
				  suppressRowClickSelection: true,
				  rowSelection: 'multiple',
				  paginationPageSize: 10,
				  pagination: true,
				  enableFilter: true,
				  floatingFilter: true,
				  columnDefs: this.createColumnDefs(),			
				  overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No SNMP Commands</span>',
				  overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
			  };  

			  this.gridOptionsIC = <GridOptions>{
				suppressRowClickSelection: true,
				rowSelection: 'multiple',
				paginationPageSize: 10,
				pagination: true,
				enableFilter: true,
				floatingFilter: true,
				columnDefs: this.createColumnDefsIC(),
				overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No ICs</span>',
				overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
			}; 
			  
	}

	ngOnInit() {
		
		//this.loadICs();
		this.appendCUIComponentstoWrapper();
		
	}

	ngOnChanges(changes: {[propKey: string]: SimpleChange}) {

		let log: string[] = [];
		for (let propName in changes) {
			let changedProp = changes[propName];
			if (changedProp.isFirstChange()) {
			} else {
				let from = JSON.stringify(changedProp.previousValue);
				const icListArray = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);				
				this.loadICs(icListArray);
			}
		}
		if(changes.icList.previousValue!=null)
			this.isAssessmentTypeChanged=!(JSON.stringify(changes.icList.currentValue)==JSON.stringify(changes.icList.previousValue));

	}

	public loadICs(icList){

		let url = (<any>window).acConfig.getICListAPI;
		let body = [
				{
					"attribute":"name",
					"value": icList
				}
			];

		this.apiService.postUrl(url, body).subscribe(
			result => {

				if (result.status === 200) {
					let respData = result.json();
					this.loadICGrid(respData);
					if(this.isAssessmentTypeChanged)
						this.processICResponses(respData);
				}else{
					this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.EXCLUDEICLOAD').subscribe((res: string) => {
					let alertMetaData = {
						"name": "loadic",
						"title" : "Getting IC Details Failure",
						"type":"DANGER",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
					this.loadICGrid([]);
				}

			},
			err => {
				console.log("error loading ic", err);
				this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.EXCLUDEICLOAD').subscribe((res: string) => {			
					let alertMetaData = {
					"name": "loadic",
					"title" : "Getting IC Details Failure",
					"type":"DANGER",
					"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				});
				this.loadICGrid([]);
			}
			,() => {}
		);

	}

	public processICResponses(ICDetails){

		let icnames = [];
		this.cliCommands = [];
		this.snmpCommands = [];
		for (let ic of ICDetails) {

			icnames.push(ic.name);
			//this.logger.info("ic details", ic);	

			for (let command of ic.collectionInfo){
				switch(command.mode.toLowerCase()){
					case "snmp":
						this.addToSNMPCommand(command, ic.name);
						break;
					case "cli":
						this.addToCLICommand(command, ic.name);
						break;	
				}
			}

		}

		this.appService.set("icSet", JSON.stringify(icnames));
		this.cliCommands = Object.assign({}, this.cliCommands);
		this.loadSNMPGrid(this.snmpCommands);

	}

	public addToSNMPCommand(command, ic){
		
		if(!this.containsObject(command.command, this.snmpCommands)){
			let commandObj = command;			
			commandObj["icList"] = [ic];
			this.snmpCommands.push(commandObj);
		}else{
			this.containsObject(command.command, this.snmpCommands).icList.push(ic);
		}

	}

	public loadSNMPGrid(data){

		if(data.length > 0){

			this.gridOptions.api.setRowData(data);
			this.gridOptions.api.sizeColumnsToFit();
			this.gridOptions.api.hideOverlay();

			let collectorAndDevices  = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'];
			let excludedSNMPs = [];

			if(collectorAndDevices != "" && collectorAndDevices != undefined){
		
			  excludedSNMPs = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'].excludedSNMPs;
		
			}

			this.gridOptions.api.forEachNode( (node) => {

				if(excludedSNMPs != undefined && excludedSNMPs.length != 0){

					if(!this.containsObject(node.data.command, excludedSNMPs)){
						node.setSelected(true);
					}

				}else{
					node.setSelected(true);
				}
				
			});

		}else{
			this.gridOptions.api.setRowData([]);
			this.gridOptions.api.showNoRowsOverlay();
		}

	}

	public addToCLICommand(command, ic){

		if(!this.containsObject(command.command, this.cliCommands)){
			let commandObj = command;			
			commandObj["icList"] = [ic];
			this.cliCommands.push(commandObj);
		}else{
			this.containsObject(command.command, this.cliCommands).icList.push(ic);
		}

	}

	public appendCUIComponentstoWrapper(){
		document.body.appendChild(document.getElementById("dialogICs"));
	}
	
	public containsObject(command, list) {
		let i;
		for (i = 0; i < list.length; i++ )
		{
			if (list[i].command == command)
			{
				return list[i];
			}
		}
		return false;
	}
	

	public createColumnDefs() {
		
		  this.columnDefs = [
			  {
				  headerName: "",
				  field: "selectAllCommands",
				  width: 50,
				  headerCheckboxSelection: true,
				  headerCheckboxSelectionFilteredOnly: true,
				  checkboxSelection: true,
				  pinned: true,
				  suppressFilter: true
			  },
			  {headerName: "Commands", field: "command",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "command", headerTooltip: "Command",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }
			  },
			  {headerName: "OS Type", field: "ostypes",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "ostypes", headerTooltip: "Os Type",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }	
			  },
			  {headerName: "Repetitions / Interval", field: "frequency",width: 250, sortingOrder: ['asc','desc'], pinned: true, cellRenderer:this.formatRepetition, headerTooltip: "Repetitions / Interval",
				  icons: {
					  sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					  sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				  }
			  }
		  ];
		  return this.columnDefs;
  
	}

	formatRepetition(params){

		let frequency = params.data.frequency != "" ? params.data.frequency : params.data.repetition;
		return frequency;
		
	}
  
	public calculateRowCount() {
		if (this.gridOptions.api && this.rowData) {
			var model = this.gridOptions.api.getModel();
			var totalRows = this.rowData.length;
			var processedRows = model.getRowCount();
			this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
	}
	

	public onModelUpdated() {
		this.calculateRowCount();
	}

	public onReady(event) {
		this.calculateRowCount();
	}

	public onRowSelected($event) {
		
		this.excludedSNMPs = [];
		this.gridOptions.api.forEachNode( (node) => {
			
			if(!node.isSelected() && !this.containsObject(node.data.command, this.excludedSNMPs)){
				this.excludedSNMPs.push(node.data);
			}else{
				
			}

		});
		this.appService.set("excludedSNMPs", JSON.stringify(this.excludedSNMPs));
		
		let length = this.excludedSNMPs.length;
		this.excludeCommandChange.emit(length);
		
	}

	public excludeCLICommandChange(value){
		let totallength = this.excludedSNMPs.length + value;
		this.excludeCommandChange.emit(totallength);
	}

	public checkICInCommands(ICName, ICs){
		if(ICName != undefined && ICName != ""){
			if(this.checkICNameinICs(ICName, ICs)){
				return true;
			}
			return false;
		}
		return true;
	}

	public checkICNameinICs(ICName, ICs){
		let i;
		for (i = 0; i < ICs.length; i++ )
		{
			if (ICs[i].toLowerCase().indexOf(ICName.toLowerCase()) >= 0)
			{
				return true;
			}
		}
		return false;
	}


	public showDialog(){

		let dialog = this.dialogICs;
		dialog.width = "80%";
		dialog.height = "70%";
		dialog.showDialog();
		this.gridOptionsIC.api.sizeColumnsToFit();

	}

	public loadICGrid(data){

		if(data.length > 0){

			this.appService.set("ICList", JSON.stringify(data));
			this.gridOptionsIC.api.setRowData(data);
			this.gridOptionsIC.api.hideOverlay();
			this.gridOptionsIC.api.sizeColumnsToFit();

		}else{

			this.gridOptionsIC.api.setRowData([]);
			this.gridOptionsIC.api.showNoRowsOverlay();
			this.appService.set("ICList", JSON.stringify([]));

		}

	}
	
	public createColumnDefsIC() {

		this.columnDefsIC = [
			{
				headerName: "",
				field: "selectAllICs",
				width: 50,
				headerCheckboxSelection: true,
				headerCheckboxSelectionFilteredOnly: true,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},
			{headerName: "IC Name", field: "name", width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "name", headerTooltip: "IC Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
			},
			{headerName: "Created Date", field: "created",width: 150, pinned: true,
				tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
			},
			{headerName: "IC Type", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "visibility", headerTooltip: "IC Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "OS Type", field: "osType",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "osType", headerTooltip: "OS Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "nmsArea", headerTooltip: "NMS Area",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Architecture Type", field: "architecture",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "architecture", headerTooltip: "Architecture Type",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				}
				},
			{headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Status",
				icons: {
				sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
				sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
	  	];

		return this.columnDefsIC;
  
	}

	public calculateRowCountIC() {
		if (this.gridOptionsIC.api && this.rowDataIC) {
			var model = this.gridOptionsIC.api.getModel();
			var totalRows = this.rowDataIC.length;
			var processedRows = model.getRowCount();
			this.rowCountIC = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
	}
	

	public onModelUpdatedIC() {
		this.calculateRowCountIC();
	}

	public onReadyIC(event) {
		this.calculateRowCountIC();
	}

	public onRowSelectedIC(event) {		
		
		
	}

	public clickShowAllICs(event){
		this.showDialog();
	}

	public onCloseICPopup(){
		this.gridOptionsIC.api.setFilterModel(null);		
	}
	
}