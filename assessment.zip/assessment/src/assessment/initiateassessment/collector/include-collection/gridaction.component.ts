import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'project-link',
    template: `<div>{{params.data.name}}
        <a class="icon-edit" style="padding:0px 5px; font-size:17px"  title="Edit" (click)="clickAction(1,params.data)"></a>
        <a class="icon-trash" style="padding:0px 5px; font-size:17px" title="Delete" (click)="clickAction(2,params.data)"></a>
    </div>`
})

export class GridActionComponent implements ICellRendererAngularComp  {
    public params: any;
    constructor(public router: Router) {    
    }
    agInit(params: any): void {
        this.params = params;
    }
    refresh(): boolean {
        return false;
    }
    public clickAction(id,data) {
        if(id==1){
            this.params.context.componentParent.editCustomCommand(data);
        }
        if(id==2){
            this.params.context.componentParent.deleteCommand = data.command;
            this.params.context.componentParent.deleteconfirmation();
        }
        
    }
}