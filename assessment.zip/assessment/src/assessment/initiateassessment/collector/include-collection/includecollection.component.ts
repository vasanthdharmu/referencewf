import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter, Input, SimpleChange } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { GridOptions } from 'ag-grid/main';
import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

import { FusionAlert } from 'aui/components/notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from 'aui/components/notification-alert/alertanchor.directive';

import { CuiTableOptions } from 'aui/components/cui-table';
import { StaticPagerService } from 'aui/components/cui-services/services';
import { GridActionComponent} from './gridaction.component'

@Component({
  selector: 'include-collection',
  templateUrl: './includecollection.template.html',
  styleUrls: [ './includecollection.style.css' ],
  encapsulation: ViewEncapsulation.None,
  entryComponents: [ FusionToaster, FusionAlert, GridActionComponent ],  
  providers: [ StaticPagerService ]
})
export class IncludeCollectionComponent {
  
  public customCommands:Array<any> = [];
  public customCommandForm: FormGroup;
  public isSaveDisabled:boolean = true;
  public loaderSaveButton:boolean = false;
  public isFile:boolean = false;

  public deleteCommand:any;

  public commandTypes = [{"value": "CLI", "name": "CLI"},{"value": "SNMP", "name": "SNMP"},{"value": "HTTP", "name": "HTTP"},{"value": "FILE", "name": "FILE"}];//, {"value": "SQL", "name": "SQL"}
  public OSTypes = []; 
  public repetitions = [{"value": "Repetition", "name": "Repetition", "selected": true}, {"value": "Frequency", "name": "Interval (frequency)"}];
  public intervals = [{"value": "Minutes", "name": "Minutes"}, {"value": "First Day and Last Day", "name": "First Day and Last Day"}];
  public commands = [];
  public productType:any = [];
  public feature: any = [];
  public osListPost: any = [];
  public commandList = [];
    
  public showCustomCommandForm: boolean = true;
  public customCommandTableLoading: boolean = false;
  public validCommandName:boolean = false;
  public showCommandNameExists:boolean = false;
  public customCommandTableOptions: CuiTableOptions;
  public customCommandTableData:any;
  public tableLimit: number = 1;
  public tableOffset: number = 0;
  public totalItems: number = 0;
  public formEditMode:boolean = false;
  public gridOptions: GridOptions;
  public columnDefs: any[];
  public rowData: any[];
  public rowCount: string;
  public selectedNodesLength: any;
  public isCommandText : boolean = true;

  @ViewChild('saveBtn') saveButton;

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  @ViewChild(AlertAnchorDirective) alertAnchor;
  @ViewChild('deletefusionalert') deletefusionalert:ElementRef;

  @Output() customCommandsForCollection: EventEmitter<any> = new EventEmitter();
  @Input() selectedOSTypes:any = [];
  @Input() selectedProductFamily:any = [];
  @Input() selectedFeature:any = [];
    
  constructor(public workflowapi: workflowApi, public apiService: ApiService, public appService: AppService, public staticPagerService: StaticPagerService, public logger: LoggerService, public assessmentService: AssessmentService) {      
      this.registerToSSUEApi();
      
      this.gridOptions = <GridOptions>{
        context: {
            componentParent: this
        },
        suppressRowClickSelection: true,
        onGridReady: () => {
          this.gridOptions.api.setRowData(this.customCommands);
          this.gridOptions.api.hideOverlay();
          this.gridOptions.api.sizeColumnsToFit();
          this.calculateRowCount();
        },
        rowSelection: 'multiple',
        paginationPageSize: 10,
        pagination: true,
        enableFilter: true,
        floatingFilter: true,
        rowModelType : 'infinite',
        columnDefs: this.createColumnDefs(),
        overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no available projects</span>',
        overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
    };
  }
  
  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
      for (let propName in changes) {
          let changedProp = changes[propName];
          let to = JSON.stringify(changedProp.currentValue);
          if (changedProp.isFirstChange()) {
          } else {
              let from = JSON.stringify(changedProp.previousValue);
              if (`${propName}` == "selectedOSTypes") {
                  const selectedOSTypesArray = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);
                  let osList = [];
                  selectedOSTypesArray.forEach((osType, index) => {
                      osList.push({ "value": osType, "name": osType });
                      this.osListPost.push(osType);
                  });
                  this.OSTypes = osList;
              }
              else if(`${propName}` == "selectedProductFamily"){
                  const selectedProductFamily = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);
                  selectedProductFamily.forEach((productFamily, index) => {
                      this.productType.push(productFamily); 
                  });
              }
              else if (`${propName}` == "selectedFeature") {               
                  const selectedFeature = Object.keys(changedProp.currentValue).map(i => changedProp.currentValue[i]);
                  let commandList = [];
                  let isupdate=true;
                  // To check new enteries
                  if(this.feature.length==selectedFeature.length){
                     let diff = this.feature.filter(function(v) { 
                      return selectedFeature.indexOf(v) === -1;
                    });
                    if(diff.length==0){
                      isupdate=false;
                    }
                  }        
                  if(isupdate){
                    this.customCommands=[];
                    this.feature=[];
                    selectedFeature.forEach((feature, index) => {
                        this.feature.push(feature);
                    });
                    this.getCommand();
                    if(!this.showCustomCommandForm)
                      this.addCustomCommand();
                    
                    if (this.feature.indexOf('Legacy') === -1) {
                      this.isCommandText = false;
                    }
                    else{
                        this.isCommandText = true;
                    }
                  }
                 

              }
          }
      }
  }

  ngOnInit() {
      this.loadCustomCommandForm();
      this.loadCustomCommandTable();
      this.appendCUIComponentstoWrapper();
  }

  loadCustomCommandForm(){
    
      this.customCommandForm = new FormGroup({
        //'command': new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9-_ ]{1,}')]),
          'command': new FormControl('', Validators.required),
        'mode': new FormControl('', Validators.required),
        'ostypes': new FormControl('', Validators.required),
        'version': new FormControl('', Validators.required),
        'repetitionOrInterval': new FormControl('Repetition'),
        //'interval': new FormControl(''),
        'repetition': new FormControl(''),
        'frequency': new FormControl('')
        //'cucmDatabaseQuery': new FormControl(''),
        //'localDatabaseQuery': new FormControl('')
      });
      this.getIcMetadata();
    
  }
    
  getCommand() {
      if (this.OSTypes.length > 0) {
          let icData: any = {};
          icData['osType'] = this.osListPost;
          icData['productFamily'] = this.productType;
          icData['feature'] = this.feature;
          this.apiService.postUrl((<any>window).acConfig.postIcMetaDataCommand, JSON.stringify(icData)).subscribe(
              (data) => {
                  let respData = data.json();
                  if (data.status === 200) {
                      let commands = [];
                      respData.forEach((command, index) => {
                          commands.push({ "value": command, "name": command });
                      });
                      this.commandList = commands;
                  }
                  else {
                      let errorAlert = {
                          "name": "commandlist",
                          "title": "Command List",
                          "type": "DANGER",
                          "content": "Problem loading command list " + respData.statusText
                      }
                  }
              },
              (err) => {
                  let errinfo = err.json();
                  let errorAlert = {
                      "name": "commandlist",
                      "title": "Command List",
                      "type": "DANGER",
                      "content": "Problem loading command list " + errinfo
                  }
              });
      } 
  }

    getIcMetadata() {
    this.apiService.getAPI((<any>window).acConfig.getIcMetaData, '').subscribe(
        data => {
        
            let respData = data.json();
            let osList = [];
            respData.osType.forEach((osType, index) => {
                osList.push({ "value": osType, "name": osType });
            });
            this.OSTypes = osList;
        },
        err => {
            console.error(err);
        }
        , () => { }
    );
  }

  OnRepetitionOrIntervalChange(event){
    this.customCommandForm.patchValue({'repetition': ''});
    this.customCommandForm.patchValue({'frequency': ''});
  }
    

  public appendCUIComponentstoWrapper(){

    //document.getElementById("content-wrapper").appendChild(document.getElementById("deletefusionalert"));
    if(document.getElementById("deletefusionalert") != null){
      document.body.appendChild(document.getElementById("deletefusionalert"));
    }
    

    }

  loadCustomCommandTable(){

    this.customCommandTableOptions = new CuiTableOptions({
      "bordered": true,
      "striped": false,
      "hover": false,
      "wrapText": false,
      "padding": "regular",
      "selectable": false,
      "dynamicData": true,
      "columns": [  
        {
          "name": "Command Name",       
          "key": "command"
        },
        {
          "name": "Command Type",         
          "key": "mode"
        },
        {
          "name": "OS Type",         
          "key": "ostypes"
        },
        {
          "name": "Actions",
          "key": "command",
          "sortable": false,
          "isLink": true,
          "links": ['icon-edit', 'icon-trash']
        }
      ]
    });

    if(this.appService.get("assessmentData") != null){

      let collectorAndDevices  = JSON.parse(this.appService.get("assessmentData")).payLoad['collectorAndDevices'];
      
      if(collectorAndDevices != "" && collectorAndDevices != undefined){

        let customCommands = JSON.parse(this.appService.get("assessmentData")).payLoadUI['collectorAndDevices'].customCommands;

        if(customCommands != "" && customCommands != undefined){

          this.customCommands = customCommands;
          this.appService.set("customCommands", JSON.stringify(this.customCommands));
          this.emitCustomCommandsOnChange(JSON.stringify(this.customCommands));

          if(this.customCommands.length > 0){
            this.showCustomCommandForm = false;
          }
          
        }

      }  

    } 

  }

  addCustomCommand(){
    this.doReset();
    this.showCustomCommandForm = !this.showCustomCommandForm; 
    this.formEditMode = false;
    this.validCommandName = false;
  }

  editCustomCommand(keyValue){

    this.formEditMode = true;
    this.validCommandName = true;
    this.showCustomCommandForm = !this.showCustomCommandForm;
    this.customCommandForm.patchValue({
        'mode': keyValue.mode,
        'ostypes': keyValue.ostypes,
        'command': keyValue.command,
        'version': keyValue.version,
        'repetitionOrInterval': keyValue.repetitionOrInterval,
        //'interval': keyValue.interval,
        'repetition': keyValue.repetition,
        'frequency': keyValue.frequency,
        //'cucmDatabaseQuery': keyValue.cucmDatabaseQuery,
        //'localDatabaseQuery': keyValue.localDatabaseQuery
    });

    this.updateInputArrays(keyValue.mode, this.commandTypes);

    for(let input of this.OSTypes) {
      delete input['selected'];
    }    

    for(let OSType of keyValue.ostypes) {

      for(let input of this.OSTypes) {
        if(input.value == OSType)
        {
          input['selected'] = true;
        }
      }

    }

    this.updateInputArrays(keyValue.repetitionOrInterval, this.repetitions);
    //this.updateInputArrays(keyValue.interval, this.intervals);
    this.isValidated();

  }

  deleteconfirmation(){
    this.formEditMode = false;
    let deletefusionalert = this.deletefusionalert.nativeElement;

    let buttons =  [{
        label: "Yes",
    }, {
        label: "No"
    }];
    
    this.alertAnchor.createAlert(FusionAlert,"warning","Do you really want to delete this custom command?","",deletefusionalert, buttons);
          
  }

  onDeleteAlertButtonClick(event){
    
    let target = event.target || event.srcElement || event.currentTarget;                    
    switch(target.innerHTML){    
      case "Yes":
          this.deleteCustomCommand(this.deleteCommand);
          this.gridOptions.api.setRowData(this.customCommands);
          let alertMetaData = {
            "name": "customcollectioncommand",
            "title" : "Add Custom collection command",
            "type":"SUCCESS",
            "content": "Command has been deleted successfully!"       
          }    
          this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          
          break;            
      case "No":   
          this.deleteCommand = "";
          break;
      
    }

  }

  deleteCustomCommand(command){

    //if(this.customCommands.length  > 0){
      this.customCommands = this.customCommands.filter(function( obj ) {
        return obj.command != command;
      });
    //}

    if(this.customCommands.length == 0){
      this.showCustomCommandForm = true;
      this.doReset();
    }

    this.appService.set("customCommands", JSON.stringify(this.customCommands));
    this.emitCustomCommandsOnChange(JSON.stringify(this.customCommands));

  }

  onRowLinkClicked(event){
    
    let data = event.keyValue;
    switch(event.action){
      case "icon-edit":
        this.editCustomCommand(data);
        break;
      case "icon-trash":
        this.deleteCommand = data.command;
        this.deleteconfirmation();
        break;  
    }
   
  }  
 
  selectChange(formControlName, formControlField){
      if(formControlField.value == "FILE"){
        this.customCommandForm.patchValue({ [formControlName]: formControlField.value});
        this.isFile = true;
        let data = this.prepareData();
        let formData = Object.assign({}, data);
        let mode = JSON.parse('{"mode":"'+formData.mode+'"}');
        this.customCommands.push(mode);      
        this.appService.set("customCommands", JSON.stringify(this.customCommands));
        this.emitCustomCommandsOnChange(JSON.stringify(this.customCommands));
      }
      else{
        this.customCommandForm.patchValue({ [formControlName]: formControlField.value});
        this.isFile = false;
        this.isValidated();
      }
  }

  loadCommands(commandType, value){

    if(commandType=="SNMP"){

      this.commands = [
        {"value": "ifDescr", "name": "ifDescr"},
        {"value": "ifHCInOctets", "name": "ifHCInOctets"}
      ];

    }
    if(commandType=="CLI"){

      this.commands = [
        {"value": "show status", "name": "show status"},
        {"value": "show version", "name": "show version"},
        {"value": "show os", "name": "show os"}
      ];

    }

    if(this.formEditMode){
      this.updateInputArrays(value, this.commands);
    }

  }

  multiselectChange(formControlName, formControlField){
    let multiselected = [];
    for(let selected of formControlField) {
      multiselected.push(selected.value);
    }
    this.customCommandForm.patchValue({ [formControlName]: multiselected});
    this.isValidated();
  }

  public onSave(){
  
    if( this.isValidated() ){

      this.loaderSaveButton = true;
      let data = this.prepareData();

      console.log("save command data", data);
      
      this.deleteCustomCommand(data.command);
      let formData = Object.assign({}, data);
      this.customCommands.push(formData);      

      this.appService.set("customCommands", JSON.stringify(this.customCommands));
      this.emitCustomCommandsOnChange(JSON.stringify(this.customCommands));

      let msg = "Command has been added successfully";
      if(this.formEditMode){
        msg = "Command has been updated successfully";
      }
      let alertMetaData = {
        "name": "customcollectioncommand",
        "title" : "Add Custom collection command",
        "type":"SUCCESS",
        "content": msg    
      }    
      this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

      this.loaderSaveButton = false;
      this.showCustomCommandForm = false;
      //this.posttoAPI(data);
  
    }else{

    }
  
  }

  public doReset(){

    this.customCommandForm.reset();
    this.customCommandForm.patchValue({'mode': ''});
    this.customCommandForm.patchValue({'ostypes': ''});
    this.customCommandForm.patchValue({'repetition': ''});
    this.customCommandForm.patchValue({'frequency': ''});
    this.customCommandForm.patchValue({'command': ''});
    this.customCommandForm.patchValue({'repetitionOrInterval': 'Repetition'});
    this.updateInputArrays("", this.commandTypes);
    this.updateInputArrays("", this.OSTypes);
    this.updateInputArrays("", this.commandList);
    //this.updateInputArrays("", this.intervals);
    this.updateInputArrays("Repetition", this.repetitions);
    this.isValidated();

  }

  posttoAPI(data){
    this.loaderSaveButton = false;
  }
  

  public prepareData(){

    let data = this.customCommandForm.value;
    return data;

  }

  public isValidated(){
    if(this.customCommandForm.controls.mode.value != 'SQL'){
      if(this.customCommandForm.valid && this.validCommandName && ((this.customCommandForm.controls.repetition.value != "" && this.customCommandForm.controls.repetition.value != null) || this.customCommandForm.controls.frequency.value != "")){
        this.isSaveDisabled = false;
        return true;
      }
      this.isSaveDisabled = true;
      return false;

    } else{
      if(this.customCommandForm.controls.command.value != null && this.customCommandForm.controls.cucmDatabaseQuery.value != null && this.customCommandForm.controls.localDatabaseQuery.value != null){
        this.isSaveDisabled = false;
        return true;
      }
      this.isSaveDisabled = true;
      return false;
    }

  
  }

  public onCommandNameChange(event){

    this.validCommandName = false;
    if(!this.containsObject(this.customCommandForm.controls.command.value , this.customCommands)){
      this.validCommandName = true;
      this.showCommandNameExists = false;
    }else{
      this.showCommandNameExists = true;
    }
    this.isValidated();
  }

  public containsObject(command, list) {

        let i;
        for (i = 0; i < list.length; i++ )
        {
            if (list[i].command == command)
            {
                return list[i];
            }
        }
    return false;
    
    }

  updateInputArrays(formdata, inputArray){
    for(let input of inputArray) {
        delete input['selected'];
        if(input.value == formdata)
        {
          input['selected'] = true;
        }
    }
  }

  public emitCustomCommandsOnChange(data:any) {
    
      this.customCommandsForCollection.emit(data);
        
  }

  public registerToSSUEApi(){
        
        this.workflowapi.registerEvent('allStepsData')
        .subscribe((response: any) => {

      if(response.allStepsData.step2 != null){

        this.customCommands = JSON.parse(response.allStepsData.step2);
        this.appService.set("customCommands", JSON.stringify(this.customCommands));
        this.emitCustomCommandsOnChange(JSON.stringify(this.customCommands));
        if(this.customCommands.length > 0){
          this.showCustomCommandForm = false;
        }

      }
      
        });

  }
  
  public createColumnDefs() {
    this.columnDefs = [
        {
            headerName: "Command Name", field: "command", width: 300, sortingOrder: ['asc', 'desc'],  pinned: true,
            tooltipField: "command", headerTooltip: "Project Name",
            icons: {
                sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
            },
        },
        {
            headerName: "Command Type", field: "mode", width: 250, sortingOrder: ['asc', 'desc'], pinned: true,
            tooltipField: "mode", headerTooltip: "Command Type",
            icons: {
                sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
            },
        },
        {
          headerName: "OS Type", field: "mode", width: 250, sortingOrder: ['asc', 'desc'], pinned: true,
          tooltipField: "ostypes", headerTooltip: "OS Type", cellRenderer: function (params) {
            return params.data.ostypes.join(', '); 
          },
          icons: {
              sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
              sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
          },
      },
        {
            headerName: "Actions", field: "command", width: 300, sortingOrder: ['asc', 'desc'],  pinned: true, cellRendererFramework: GridActionComponent,
            tooltipField: "command", headerTooltip: "Actions", suppressSorting: true, suppressFilter : true
        },
    ];
    return this.columnDefs;

}
public onModelUpdated() {
  this.calculateRowCount();
}

public calculateRowCount() {
  if (this.gridOptions.api && this.rowData) {
      var model = this.gridOptions.api.getModel();
      var totalRows = this.rowData.length;
      var processedRows = model.getRowCount();
      this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
  }
}

public onRowSelected($event) {
  let selectedNodes = this.gridOptions.api.getSelectedNodes();
  this.selectedNodesLength = selectedNodes.length;
}

    
}