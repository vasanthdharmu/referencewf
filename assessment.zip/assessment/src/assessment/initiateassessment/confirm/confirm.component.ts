import { Component, ViewChild, ElementRef, Pipe, PipeTransform,ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GridOptions } from 'ag-grid/main';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

@Component({
  selector: 'confirm',
  templateUrl: './confirm.template.html',
  styleUrls: [ './confirm.style.css' ],
  host: {'class':"dynamic-component"},
  encapsulation: ViewEncapsulation.None,
  entryComponents: [ FusionToaster ]
})
export class ConfirmComponent {

  public assessmentConfirmForm: FormGroup;
  public submitted : boolean;
  public prerequistieLabel = [{"name": "Yes, I have taken care of all the above listed Network Prequisites", "value": 1}];
  public assessmentData:any;
  public selectedDevices:any;
  public selectedDevicesLength:number;
  public selectedDevicesgridOptions:GridOptions;
  public icgridOptions:GridOptions;
  public columnDefs: any[];
  public iccolumnDefs: any[];
  public searchString:String;
  public excluded_commands:any[];
  public custom_commands:any[];
  public popupdata:any;
  public searchText: any;
  public icsearchText: any;
  public periodList = [{ "value": "10080", "name": "7 days" },
  { "value": "8640", "name": "6 Days" },
  { "value": "7200", "name": "5 Days" },
  { "value": "5760", "name": "4 Days" },
  { "value": "4320", "name": "3 Days" },
  { "value": "2880", "name": "2 Days" },
  { "value": "1440", "name": "1 Day" },
  { "value": "60", "name": "1 Hr" },
  { "value": "10", "name": "10 Min" }];


  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  constructor(public translate: TranslateService, public router: Router, public wizard : WorkflowManagerComponent, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    this.submitted = false;
    this.selectedDevicesgridOptions = <GridOptions>{			
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No devices to list</span>',
			overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        }; 

    this.icgridOptions = <GridOptions>{			
      suppressRowClickSelection: true,
      rowSelection: 'multiple',
      paginationPageSize: 10,
      pagination: true,
      enableFilter: true,
      floatingFilter: true,
      columnDefs: this.createICColumnDefs(),			
      overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No IC to list</span>',
      overlayLoadingTemplate : '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        }; 

  }

  ngOnInit(){

	  this.loadConfirmForm();

  }

  preLoadOnBack(){
  }

  preLoad(){

    this.assessmentData = JSON.parse(this.appService.get("assessmentData"));
    this.logger.info("assessmentData", this.assessmentData);

    this.selectedDevices = this.assessmentData.payLoadUI.collectorAndDevices.devices;
    this.logger.info("this.selectedDevices", this.selectedDevices);
    this.selectedDevicesLength = this.selectedDevices.length;
    this.selectedDevicesgridOptions.api.setRowData(this.selectedDevices);

    let ICList = JSON.parse(this.appService.get("ICList"));
    let includedICs = this.assessmentData.payLoadUI.collectorAndDevices.includedICs;
    let includedICList = [];
    for (let IC of ICList){
      if(includedICs.indexOf(IC.name) != -1){
        includedICList.push(IC);
      }
    }
    this.icgridOptions.api.setRowData(includedICList);

    this.custom_commands = this.assessmentData.payLoadUI.collectorAndDevices.customCommands;
    this.excluded_commands = (this.assessmentData.payLoadUI.collectorAndDevices.excludedSNMPs != null && this.assessmentData.payLoadUI.collectorAndDevices.excludedSNMPs.length > 0) ? this.assessmentData.payLoadUI.collectorAndDevices.excludedSNMPs.length : [];
    for(var i in this.assessmentData.payLoadUI.collectorAndDevices.excludedCLIs) { 
      this.excluded_commands.push(this.assessmentData.payLoadUI.collectorAndDevices.excludedCLIs[i]);
    }

  }

  public showDialog( dialog ){
    dialog.width = "25%";
    dialog.showDialog();
  }

  public showDialogPop( dialog,data ){
    this.popupdata=data;
    dialog.width = "50%";
	  dialog.height = "50%";
    dialog.showDialog();
  }

  loadConfirmForm(){

    this.assessmentConfirmForm = new FormGroup({
      'acceptPrerequistie': new FormControl(''), //, Validators.required
      'searchText':new FormControl()
    });

  }

  onPrerequistieChange(event){

    let target = event.target || event.srcElement || event.currentTarget;
    if( this.isValidated() && target.checked ){
			this.wizard.setEnabled('nextButton');
			this.wizard.setEnabled('saveButton');
		}else{
			this.wizard.setDisabled('nextButton');
			this.wizard.setDisabled('saveButton');
		}

  }

  public onSave(){

     let data = this.prepareData();
     data.action = "save";
     data.status = "draft";
     data.modifiedTx = this.appService.getUnixTimeStamp();
     this.postToWorkFlowAPI(data, (<any>window).acConfig.postAssessmentDataWorkflowAPI, true, "saveButton");

  }

  public isValidated(){

    this.logger.info("this.assessmentConfirmForm.valid", this.assessmentConfirmForm.valid);
    if(this.assessmentConfirmForm.valid){
      return true;
    }
    return false;

  }

  public onSubmit(action){

    let data = this.prepareData();
    data.action = "submit";
    data.status = "active";
    data.payLoad.basicDetails.asProjectID = String(data.payLoad.basicDetails.asProjectID);
    data.processId = String(data.processId);
    data.globalFilters.cpyKey = String(data.globalFilters.cpyKey);

    /*
    let excludedCommandSet = (JSON.parse(this.appService.get("excludedSNMPs")) != null && JSON.parse(this.appService.get("excludedSNMPs")).length > 0) ? JSON.parse(this.appService.get("excludedSNMPs")) : [];    
    let excludedCLIs = (JSON.parse(this.appService.get("excludedCLIs")) != null && JSON.parse(this.appService.get("excludedCLIs")).length > 0) ? JSON.parse(this.appService.get("excludedCLIs")) : [];
    for(var i in excludedCLIs) {
      excludedCommandSet.push(excludedCLIs[i]);
    }
    data.payLoad.collectorAndDevices.excludedCommandSet = excludedCommandSet;
    */

    data.payLoad.collectorAndDevices.icSubSet = data.payLoad.collectorAndDevices.includedICs; //JSON.parse(this.appService.get("icSet"));    
    let customCommands = Object.assign({}, data.payLoad.collectorAndDevices.customCommands);
    data.payLoad.collectorAndDevices.additionalCommands = Object.keys(customCommands).map(i => customCommands[i]);

    delete data.payLoad.collectorAndDevices.customCommands;
    delete data.payLoad.collectorAndDevices.excludedSNMPs;
    delete data.payLoad.collectorAndDevices.excludedCLIs;
    delete data.payLoad.collectorAndDevices.excludedICs;
    delete data.payLoad.collectorAndDevices.includedICs;
    delete data.payLoadUI;
    delete data.payLoad.basicDetails.nceCECID;
    //delete data.payLoad.collectorAndDevices.deviceIDs;
    delete data.payLoad.collectorAndDevices.deviceNames;
    data.modifiedTx = this.appService.getUnixTimeStamp();
    this.postToWorkFlowAPI(data, (<any>window).acConfig.submitAssessmentDataWorkflowAPI, true, action);

  }

  postToWorkFlowAPI(data, url, showtoaster, action){

        let toaster = this.toaster.nativeElement;

        if( this.isValidated() ){

          this.wizard.setLoaderEnabled(action);

          this.logger.info("Post:assessmentData", data);
          this.apiService.postUrl(url, JSON.stringify(data)).subscribe(
            (result) => {
            
            if(result.status === 201 || result.status === 200){

              if(data.action == "save"){

                  let respData = result.json();
                  respData.payLoadUI = JSON.parse(this.appService.get("assessmentData")).payLoadUI;
                  this.appService.set("assessmentData",JSON.stringify(respData));
                  this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));

                  let assessmentID = respData.assessmentId;
                  if(assessmentID != ""){
                    this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.SAVE',{project: assessmentID}).subscribe((res: string) => {
                      let alertMetaData = {
                        "name": "saveproject",
                        "title" : "Save Project - Confirm",
                        "type":"SUCCESS",
                        "content": res
                      }    
                      this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                  }
                 
              }
              if(data.action == "submit"){
                
                let payLoadUI = JSON.parse(this.appService.get("assessmentData")).payLoadUI;

                if((<any>window).acConfig.isTVALogUserToolServiceEnabled){
                  
                  // TVA log Service
                  if(payLoadUI.basicDetails.asProjectID != ""){

                    //&cecId=DTAKAMIN&proxyId=&projectIdentifier=239598&toolName=SORA&toolFunction=Software%20Recommendation&serviceName=NOS
                    let tvaURL = (<any>window).acConfig.getTVALogUserToolServiceAPI 
                    + '&cecId=' + payLoadUI.basicDetails.nceCECID
                    + '&proxyId='
                    + '&projectIdentifier=' + payLoadUI.basicDetails.asProjectID
                    + '&toolName=Assessment'
                    + '&toolFunction=Nexus Health Check'
                    + '&serviceName=Data Center Optimization Service';

                    this.apiService.getTVAAPI(tvaURL, '').subscribe(
                      data => {
                        
                      },
                      err => {
                        console.error("tva:error", err)
                      } 
                      ,() => {}
                    );

                    (<any>window).tvaInstance.jsonpCallback = (command, data) => {
                      this.logger.info("tva logservice", data);
                    };

                  }
                }
                
                let projectName = payLoadUI.basicDetails.projectName != "" ? payLoadUI.basicDetails.projectName : "";
                this.translate.get('NOTIFICATIONSUCCESS.PROJECTCREATE.CREATE',{project: projectName}).subscribe((res: string) => {
                  let alertMetaData = {
                    "name": "submitproject",
                    "title" : "Create Project Success",
                    "type":"SUCCESS",
                    "content": res   
                  }    
                  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);                
                });
                this.assessmentService.backtoSSUE("CFAssessment:Projects");
                
              }

            }else{
              this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.CREATE',{error: result.statusText}).subscribe((res: string) => {
                let alertMetaData = {
                  "name": "submitproject",
                  "title" : "Create Project Failure",
                  "type":"INFO",
                  "content": res
                }    
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
              });
            }

            this.wizard.setLoaderDisabled(action);

           },
           (err) => {
               this.wizard.setLoaderDisabled(action);
               this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.CREATE',{error: err._body}).subscribe((res: string) => {
               let alertMetaData = {
                "name": "submitproject",
                "title" : "Create Project Failure",
                "type":"DANGER",
                "content": res
              }    
              this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            });
          });

        }

  }
public logSelectedTab(evt){
  // console.log(evt);
}

public createColumnDefs() {
  
  this.columnDefs = [
 {headerName: "Device ID", field: "deviceId", hide:true },
  {headerName: "Device Name", field: "deviceSysname",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField:"deviceSysname", headerTooltip:"Device Name",
    icons: {
      sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
      sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
  },},
 {headerName: "IP Address", field: "ipAddress",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField:"ipAddress", headerTooltip:"IP Address",
        icons: {
          sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
          sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
  },},
 {headerName: "Device Type", field: "deviceType",width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField:"deviceType", headerTooltip:"Device Type",
        icons: {
          sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
          sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
  },}, 
  {headerName: "Device Version", field: "swVersion",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField:"swVersion",  headerTooltip:"Device Version",
  icons: {
    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
    },},
  {headerName: "Product Family", field: "productFamily",width: 280, sortingOrder: ['asc','desc'], pinned: true, tooltipField:"productFamily", headerTooltip:"Product Family",
  icons: {
    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
    },},
  ];
  return this.columnDefs;

}


public createICColumnDefs() {	  
  this.iccolumnDefs = [
    {headerName: "IC Name", field: "name", width: 150, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "name", headerTooltip: "IC Name",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      }
    },
    {headerName: "Created Date", field: "created",width: 150, pinned: true,
      tooltipField: "created", headerTooltip: "Created Date", suppressSorting: true
    },
    {headerName: "IC Type", field: "visibility",width: 150, sortingOrder: ['asc','desc'], pinned: true,
      tooltipField: "visibility", headerTooltip: "IC Type",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      },
    },
    {headerName: "OS Type", field: "osType",width: 130, sortingOrder: ['asc','desc'], pinned: true,
      tooltipField: "osType", headerTooltip: "OS Type",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      },
    },
    {headerName: "NMS Area", field: "nmsArea",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
      tooltipField: "nmsArea", headerTooltip: "NMS Area",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      },
    },
    {headerName: "Architecture Type", field: "architecture",width: 150, sortingOrder: ['asc','desc'], pinned: true,
      tooltipField: "architecture", headerTooltip: "Architecture Type",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      },
    },
    {headerName: "IC Description", field: "summary",width: 200, sortingOrder: ['asc','desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
      icons: {
      sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
      sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      }
      },
    {headerName: "Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
      tooltipField: "status", headerTooltip: "Status",
      icons: {
        sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
        sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
      },
    }
  ];
  return this.iccolumnDefs;

}
  public onNext(){
    //this.prepareData();
  }

  public prepareData(){

    let assessmentData = JSON.parse(this.appService.get("assessmentData"));
    assessmentData.payLoad = Object.assign({}, assessmentData.payLoadUI);
    return assessmentData;

  }

  public openpopup(){

  }

  public getOptionValue(value, inputArray) {
    
    for (let input of inputArray) {
        if (input.value == value) {
            return input.name;
        }
    }
    return "";
    
  }

}


