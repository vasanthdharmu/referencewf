import { Component, ViewChild, Input, ElementRef } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';
import { BasicComponent } from './basic/basic.component';
import { CollectorComponent } from './collector/collector.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { VerifyComponent } from './verify/verify.component';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

@Component({
  styleUrls: [
    './initiateassessment.style.css'
  ],
  selector:'initiate-assessment',
  templateUrl: './initiateassessment.template.html',
  entryComponents: [ FusionToaster, BasicComponent, CollectorComponent, ConfirmComponent, ScheduleComponent, VerifyComponent ]
})
export class InitiateAssessmentComponent{

  public workflowMetaData: any;
  public assessmentId:any;
  public showloader = true;
  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  constructor(public translate: TranslateService, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
    this.assessmentId = null;
  }

  ngOnInit() {

        let params = new URLSearchParams(window.location.search);
        this.assessmentId = params.get('?assessmentId'); //127532  

        /*
        this.appService.set("assessmentId", null);*/
        this.appService.set("customCommands", JSON.stringify([]));
        this.appService.set("excludedSNMPs", JSON.stringify([]));
        this.appService.set("excludedCLIs", JSON.stringify([]));
       

        if(this.assessmentId != "" && this.assessmentId != null && this.assessmentId != undefined){
          this.appService.set("assessmentId", this.assessmentId);
        }
        let toaster = this.toaster.nativeElement;
        
        /*
        this.appService.set("editstep", 0);
        this.appService.set("processID", "");
        */
        
        let data = {
          "workFlowId": this.appService.get("workFlowId"),
          "processId": null,
          "assessmentId": this.appService.get("assessmentId"),
          "step": "0",
          "payLoad": {},
          "payLoadUI": {},
          "userDetails": {
            "cco": this.appService.get("cecID"), //"vasa"
            "clientIPAddress": ""
          },      
          "globalFilters":{
            "cpyKey" : Number(this.appService.get("filterContext").customer[0]),
            "groupId" : '123'
          },
          "createdTx": this.appService.getUnixTimeStamp(),
          "modifiedTx": this.appService.getUnixTimeStamp()
        };
        
        this.appService.set("cpyKey", Number(this.appService.get("filterContext").customer[0])); //this.appService.get("filterContext").customer[0]

        this.appService.set("assessmentData",JSON.stringify(data));

        if(this.appService.get("assessmentId") != "" && this.appService.get("assessmentId") != null){

          //?workflowId=AsWorkflowProcess&processId=7778

          this.apiService.getAPI((<any>window).acConfig.getAssessmentDataWorkflowAPI + '?workflowId=AsWorkflowProcess&assessmentId=' + this.appService.get("assessmentId") + '&userId=' + this.appService.get("cecID"), '').subscribe(
            (result) => {
            
            this.logger.info("result", result);

            if(result != null && result.status === 200){

              let respData = result.json();
              respData.payLoadUI = Object.assign({}, respData.payLoad);
              this.appService.set("assessmentData",JSON.stringify(respData));
              this.appService.set("cpyKey", respData.globalFilters.cpyKey);
              this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));
              this.showloader = false;
              this.appService.set("editstep", respData.step);              
              this.loadMetaData();
              
            }else{
              
              //this.appService.set("assessmentData",JSON.stringify(data));
              //this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", "Technical issue, please contact administrator",toaster,""); 
              this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.TECHISSUE', {message: result.statusText}).subscribe((res: string) => {
                let alertMetaData = {
                  "name": "workflowapi",
                  "title" : "Initiate Assessment - Workflow API",
                  "type":"DANGER",
                  "content": res
                }    
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
              });
              this.router.navigate(['/assessment/initiate']);
              
            }
      
          },
          (err) => {
      
              //this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", err._body, toaster,"");
              this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ERROR', {error: err._body}).subscribe((res: string) => {
                let alertMetaData = {
                  "name": "workflowapi",
                  "title" : "Initiate Assessment - Workflow API",
                  "type":"DANGER",
                  "content": res
                }    
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
              });
      
          });


        }else{
            
            this.logger.info("Post:assessmentData", data);                        

            this.apiService.postUrl((<any>window).acConfig.postAssessmentDataWorkflowAPI, JSON.stringify(data)).subscribe(
              (result) => {
              
              if(result.status === 201){

                let respData = result.json();
                respData.payLoadUI = {};
                this.appService.set("assessmentData",JSON.stringify(respData));
                this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));
                this.showloader = false;
                this.loadMetaData();                
                
              }else{
        
                data.processId = null;
                data.assessmentId = null;
                this.appService.set("assessmentData",JSON.stringify(data));
                //this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", result.statusText,toaster,""); 
                this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ERROR', {error: result.statusText}).subscribe((res: string) => {
                  let alertMetaData = {
                    "name": "workflowapi",
                    "title" : "Initiate Assessment - Workflow API",
                    "type":"DANGER",
                    "content": res
                  }    
                  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });
   
              }
        
            },
            (err) => {        

                //this.toasterAnchor.createToaster(FusionToaster, "error", "Failure", err._body, toaster,"");
                this.translate.get('NOTIFICATIONFAILURE.PROJECTCREATE.ERROR', {error: err._body}).subscribe((res: string) => {
                  let alertMetaData = {
                    "name": "workflowapi",
                    "title" : "Initiate Assessment - Workflow API",
                    "type":"DANGER",
                    "content": res
                  }    
                  this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });

            });
      }
    
  }

  loadMetaData(){
    this.apiService.getUrl((<any>window).acConfig.getWorkflowMetadataAPI,'').subscribe(
      data => {

        this.workflowMetaData = data;
        this.workflowMetaData.steps.forEach((step, index) => {
          this.workflowMetaData.steps[index].component = this.getComponent(this.workflowMetaData.steps[index].component);
        });

      },
      err => console.error(err)
      ,() => {}
    );
  }

  getComponent(componentName){

    switch(componentName){

      case 'BasicComponent':
        return BasicComponent;
      case 'CollectorComponent':
        return CollectorComponent; 
      case 'VerifyComponent':
        return VerifyComponent;    
      case 'ScheduleComponent':
        return ScheduleComponent; 
      case 'ConfirmComponent':
        return ConfirmComponent;

    }

  }

  
  
}