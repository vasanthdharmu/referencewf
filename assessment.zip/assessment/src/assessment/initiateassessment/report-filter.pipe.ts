import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'reportTableFilter'
})
export class reportTableFilter implements PipeTransform {

  transform(items: any[], filter: string, datasourcefilter: string): any {

    if (!filter && !datasourcefilter) {
        return items;
    }

    if(filter && datasourcefilter ){

        let tablefiltereditems = items.filter((item: any) => this.applyTableFilter(item, filter));
        return tablefiltereditems.filter((item: any) => this.applyDataSourceFilter(item, datasourcefilter));

    }

    if(filter){
        return items.filter((item: any) => this.applyTableFilter(item, filter));
    }

    if(datasourcefilter){
        return items.filter((item: any) => this.applyDataSourceFilter(item, datasourcefilter));
    }
   

  }

  applyTableFilter(item: any, filter: any): boolean {

    return (item.tablename.toLowerCase().substr(0,filter.length) === filter.toLowerCase()) == true;

  }

  applyDataSourceFilter(item: any, filter: any): boolean {
    
    return (item.datasource.toLowerCase().substr(0,filter.length) === filter.toLowerCase()) == true;
    
  }

}
