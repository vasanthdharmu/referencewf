import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

@Component({
  selector: 'schedule',
  templateUrl: './schedule.template.html',
  styleUrls: [ './schedule.style.css' ],
  host: {'class':"dynamic-component"},
  entryComponents: [ FusionToaster ]
})
export class ScheduleComponent {
	
  public assessmentScheduleForm: FormGroup;
  public collectionDuration = [];
  public loaderCollectionDuration:boolean;

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;
  constructor(public wizard : WorkflowManagerComponent, public apiService: ApiService, public appService: AppService, public logger: LoggerService) {	  

  }
  
  ngOnInit(){
	  
	  this.loadScheduleForm();  
	
  }

  loadCollectionDurationList(){
    
      this.loaderCollectionDuration = true;
    
      let assessmentType = this.appService.get("filterContextValue").assessment_type[0];
      let platform = this.appService.get("filterContextValue").platform[0];
      this.apiService.getAPI((<any>window).acConfig.getCollectionDurationAPI + assessmentType + '/platforms/' + platform + '/', '').subscribe(
            data => {          
          
          let respData = data.json();
          this.logger.info("collection duration", respData);
          if(respData.length == 0){
            let durationentry = {"value": "1", "name": "None", "selected": true};
            this.appService.set("collectionDurationLabel","None");
            this.collectionDuration.push(durationentry);
            this.assessmentScheduleForm.patchValue({'collectionDuration': "1"});
          }
          respData.forEach(duration => {
    
            let durationentry = {"value": duration, "name": duration};
            this.collectionDuration.push(durationentry);
    
          });
          this.loaderCollectionDuration = false;

            },
            err => {
              let durationentry = {"value": "1", "name": "None", "selected": true};
              this.collectionDuration.push(durationentry);
              this.appService.set("collectionDurationLabel","None");
              this.assessmentScheduleForm.patchValue({'collectionDuration': "1"});
              this.loaderCollectionDuration = false;
              console.error(err)
            }
            ,() => {}
      );	
      
  }

  preLoad(){

    let formData = null;
    if(this.appService.get("assessmentId") != ""){

      formData = JSON.parse(this.appService.get("assessmentData")).payLoadUI[this.wizard.getStepKey()];
      this.logger.info("formData: schedule", formData);
      
      if(formData != "" && formData != undefined){

        let storeddurationentry = {"value": formData.collectionDuration, "name": formData.collectionDuration};
        this.collectionDuration.push(storeddurationentry);
        this.assessmentScheduleForm.patchValue({'collectionDuration': formData.collectionDuration});
        this.assessmentScheduleForm.patchValue({'comments': formData.comments});	
  
      }

    }

  }
  
  loadScheduleForm(){    
	  
    this.assessmentScheduleForm = new FormGroup({
      'collectionDuration': new FormControl('', Validators.required),
      'startDate': new FormControl('Immediate', Validators.required),
      'comments': new FormControl('')
    });

    this.loadCollectionDurationList();
	
  }

    public onSave(){
    
      if( this.isValidated() ){

        let data = this.prepareData();
        data.action = "save";       
        this.postToWorkFlowAPI(data, true, "saveButton");    

      }
    
    }

    public onNext(){

      let data = this.prepareData();
      data.action = "next";
      this.postToWorkFlowAPI(data, false, "nextButton");    
      
    }

    postToWorkFlowAPI(data, showtoaster, action){
      
        this.wizard.setLoaderEnabled(action);
        this.logger.info("Post:assessmentData", data);
        let toaster = this.toaster.nativeElement;
        this.apiService.postUrl((<any>window).acConfig.postAssessmentDataWorkflowAPI, JSON.stringify(data)).subscribe(
          (result) => {
           
          if(result.status === 201){
      
          let respData = result.json();
          respData.payLoadUI = JSON.parse(this.appService.get("assessmentData")).payLoadUI;
          this.appService.set("processID", respData.processId);
          this.appService.set("assessmentData",JSON.stringify(respData));
          this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));
      
          if(showtoaster)
            this.toasterAnchor.createToaster(FusionToaster,"success","Success","Saved successfully!",toaster,"");
          
          }else{
      
          if(showtoaster)
            this.toasterAnchor.createToaster(FusionToaster,"warning","Info",result.statusText,toaster,"");
          
          }

          this.wizard.setLoaderDisabled(action);          
      
         },
         (err) => {

          this.wizard.setLoaderDisabled(action);
          
          if(showtoaster)
           this.toasterAnchor.createToaster(FusionToaster,"error","Failure",err._body,toaster,"");
      
        });
      
      }

    public prepareData(){

      let data = this.assessmentScheduleForm.value;      
      let assessmentData = JSON.parse(this.appService.get("assessmentData"));
      assessmentData.step = this.wizard.getWorkflowIndex();
      assessmentData.stepKey = this.wizard.getStepKey();
      assessmentData.payLoad = Object.assign({}, data);
      assessmentData.payLoad.collectionDuration = this.assessmentScheduleForm.controls.collectionDuration.value.split("::")[0];
      assessmentData.payLoadUI[this.wizard.getStepKey()] = data;
      this.appService.set("assessmentData",JSON.stringify(assessmentData));
      assessmentData.payLoadUI = {};
      return assessmentData;

    }
  
    public isValidated(){
      
      if(this.assessmentScheduleForm.valid){
        return true;
      }
      return false;
    
    }

    public changeModel(event){
      
      let target = event.target || event.srcElement || event.currentTarget;

      if(target.id == "collectionDuration"){
  
        this.appService.set("collectionDurationLabel", target.options[target.options.selectedIndex].innerText);
        
      }

      this.updateButtons();
      
    }

    updateButtons(){
  
      if( this.isValidated() ){
        this.wizard.setEnabled('nextButton');
        this.wizard.setEnabled('saveButton');
      }else{
        this.wizard.setDisabled('nextButton');
        this.wizard.setDisabled('saveButton');
      }
  
    }
	
}
