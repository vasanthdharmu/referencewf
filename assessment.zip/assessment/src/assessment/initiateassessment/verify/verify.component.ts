import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

@Component({
  selector: 'view-and-verify',
  templateUrl: './verify.template.html',
  styleUrls: [ './verify.style.css' ],
  host: {'class':"dynamic-component"},
  entryComponents: [ FusionToaster ]
})
export class VerifyComponent {
  
  public reportsections:any;
  public reportselected:any;
  
  public sectionfilter:string;
  public tablefilter:string;
  public datasourcefilter:string;

  reportSectionsForm: FormGroup;
  selectedReportSectionList:any;
  selectedReportTableList:any;  

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;
  
  constructor(public wizard : WorkflowManagerComponent, public apiService: ApiService, public _fb: FormBuilder, public appService: AppService, public logger: LoggerService) {
    this.reportselected = "";
  }

  ngOnInit(){
	  
	this.loadReportSections();
	
  }

  preLoad(){

  }

  loadReportSections(){

    this.reportSectionsForm = new FormGroup({
      'sectionfilter': new FormControl(''),
      'tablefilter': new FormControl(''),
      'datasourcefilter': new FormControl(''),
      'selectedReportSections': this._fb.array([]),
      'selectedReportTables': this._fb.array([])
		});

    this.apiService.getUrl('assets/api/data/report-sections.json','').subscribe(
      data => {

        this.reportsections = data.reportsection;
        this.selectedReportSectionList = data.selectedreportsections;
        this.selectedReportTableList = data.selectedreporttables;
        
        const selectedReportSectionsArray = <FormArray>this.reportSectionsForm.controls.selectedReportSections;
        selectedReportSectionsArray.controls = [];

        const selectedReportTablesArray = <FormArray>this.reportSectionsForm.controls.selectedReportTables;
        selectedReportTablesArray.controls = [];

        let reportSectionLength = this.reportsections.length;
        
        for (let i = 0; i < reportSectionLength; i++) {

          let reportSectionId = "section_"+this.reportsections[i].sectionid;

          if(this.selectedReportSectionList.indexOf(parseInt(this.reportsections[i].sectionid)) == -1){
            const control: FormControl = new FormControl(false);
            this.reportSectionsForm.addControl(reportSectionId, control);
          }else{
            const control: FormControl = new FormControl(true);
            selectedReportSectionsArray.push(new FormControl(reportSectionId));
            this.reportSectionsForm.addControl(reportSectionId, control);
          }							
          
          let reportTable = this.reportsections[i].reporttable;
          let reportTableLength = this.reportsections[i].reporttable.length;

          for (let j = 0; j < reportTableLength; j++) {

            let reportTableId = "table_"+reportTable[j].id;
            if(this.selectedReportTableList.indexOf(parseInt(reportTable[j].id)) == -1){
              const control: FormControl = new FormControl(false);
              this.reportSectionsForm.addControl(reportTableId, control);
            }else{
              const control: FormControl = new FormControl(true);
              selectedReportTablesArray.push(new FormControl(reportTableId));
              this.reportSectionsForm.addControl(reportTableId, control);
            }	

          }

        }
        

      },
      err => console.error(err)
      ,() => {}
    );

  }


  public onSave(){
    
      if( this.isValidated() ){
  
        let data = this.prepareData();
        data.action = "save";
        data.payLoad = data.payLoad.reportSections;
        this.postToWorkFlowAPI(data, true);    
    
      }
    
    
    }

    public onNext(){    
      let data = this.prepareData();
      data.action = "next";
      data.payLoad = data.payLoad.reportSections;
      this.postToWorkFlowAPI(data, false);    
    }

    postToWorkFlowAPI(data, showtoaster){
      
        this.logger.info("Post:assessmentData", data);
        let toaster = this.toaster.nativeElement;
        this.apiService.postUrl('/v1/assesmentWorkflow/assessmentData',JSON.stringify(data)).subscribe(
          (result) => {
           
          if(result.status === 200){
      
          this.appService.set("assessmentData",JSON.stringify(result.json()));
          this.logger.info("Resp:assessmentData", JSON.parse(this.appService.get("assessmentData")));
      
          if(showtoaster)
            this.toasterAnchor.createToaster(FusionToaster,"success","Success","Saved successfully!",toaster,"");
          
          }else{
      
          if(showtoaster)
            this.toasterAnchor.createToaster(FusionToaster,"success","Success",result.statusText,toaster,"");
          
          }
      
         },
         (err) => {
      
          if(showtoaster)
           this.toasterAnchor.createToaster(FusionToaster,"error","Failure",err._body,toaster,"");
      
        });
      
      }
      
    public prepareData(){

      let data = {"selectedReportSections":this.reportSectionsForm.controls.selectedReportSections.value, "selectedReportTables":this.reportSectionsForm.controls.selectedReportTables.value};      
      let assessmentData = JSON.parse(this.appService.get("assessmentData"));         
      assessmentData.payLoad.reportSections = data;
      assessmentData.step = this.wizard.getWorkflowIndex();
      assessmentData.stepKey = this.wizard.getStepKey();
      this.appService.set("assessmentData",JSON.stringify(assessmentData));      
      return assessmentData;
      
    }
  
      public isValidated(){
      
      if(this.reportSectionsForm.valid){
        return true;
      }
      return false;
    
    }

  sectionFilter(){
    this.sectionfilter = this.reportSectionsForm.controls.sectionfilter.value;
  }

  tableFilter() {		
	 this.tablefilter = this.reportSectionsForm.controls.tablefilter.value;    
  }

  dataSourceFilter(){
    this.datasourcefilter = this.reportSectionsForm.controls.datasourcefilter.value;
  }

  onReportSectionChange(event){

    let target = event.target || event.srcElement || event.currentTarget;
    const selectedReportSectionsArray = <FormArray>this.reportSectionsForm.controls.selectedReportSections;
    const selectedReportTablesArray = <FormArray>this.reportSectionsForm.controls.selectedReportTables;

    this.reportselected = "";

    
      let reportSectionLength = this.reportsections.length;

      let reportSectionSelected = selectedReportSectionsArray.value;
      let reportSectionSelectedLength = selectedReportSectionsArray.value.length;

      if(target.checked){
        this.reportselected = target.value;
        const control: FormControl = new FormControl(true);
        selectedReportSectionsArray.push(new FormControl(target.id));
        this.reportSectionsForm.addControl(target.id, control);
      }else{
        for (let s = 0; s < reportSectionSelectedLength; s++) {
                if(reportSectionSelected[s] == target.id){                
                  selectedReportSectionsArray.removeAt(s);
                }
        }
      }
      
      for (let i = 0; i < reportSectionLength; i++) {

        let reportSectionId = this.reportsections[i].sectionid;
        
        if(reportSectionId == target.value){

          let reportTable = this.reportsections[i].reporttable;
          let reportTableLength = this.reportsections[i].reporttable.length;

          for (let j = 0; j < reportTableLength; j++) {

            let reportTableId = "table_"+reportTable[j].id;

            this.reportSectionsForm.patchValue({
              [reportTableId]: target.checked
            });

            if(target.checked){
              if(selectedReportTablesArray.value.indexOf(reportTableId) == -1){
                const control: FormControl = new FormControl(true);
                selectedReportTablesArray.push(new FormControl(reportTableId));
                this.reportSectionsForm.addControl(reportTableId, control);
              }
            }else{
              let reportTableSelected = selectedReportTablesArray.value;
              let reportTableSelectedLength = selectedReportTablesArray.value.length;              
              for (let k = 0; k < reportTableSelectedLength; k++) {
                      if(reportTableSelected[k] == reportTableId){                
                          selectedReportTablesArray.removeAt(k);
                      }
              }
            }


          }

        }

      }      
    

  }

  onReportTableChange(event){

    let target = event.target || event.srcElement || event.currentTarget;
    const selectedReportTablesArray = <FormArray>this.reportSectionsForm.controls.selectedReportTables;

    let reportTable = selectedReportTablesArray.value;
    let reportTableLength = selectedReportTablesArray.value.length;

    if(target.checked){
      const control: FormControl = new FormControl(true);
      selectedReportTablesArray.push(new FormControl(target.id));
      this.reportSectionsForm.addControl(target.id, control);
    }else{
      for (let i = 0; i < reportTableLength; i++) {              
              if(reportTable[i] == target.id){                
                  selectedReportTablesArray.removeAt(i);
              }
      }
    }

  }

}
