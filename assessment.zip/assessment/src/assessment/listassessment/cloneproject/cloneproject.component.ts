import { Component, ViewChild, ElementRef, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { TranslateService } from 'ng2-translate';

@Component({
	selector: 'clone-project',
    templateUrl: './cloneproject.template.html',
    styleUrls: [ './cloneproject.style.css' ],
    encapsulation: ViewEncapsulation.None,
})

export class CloneProjectComponent {

	public projectBasicForm: FormGroup;
	public projectDuplicate: boolean = false;
	public duplicateCheck: boolean = false;
	public loaderProjectDetails: boolean = true;
	public selectedProject: any;
	public loaderSaveButton: boolean = false;
	
	@ViewChild('dialogCloneProject') dialogCloneProject;	

	constructor(public translate: TranslateService, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {
			  
	}

	ngOnInit() {

		this.projectBasicForm = new FormGroup({
            'name': new FormControl('', Validators.required)
		});
		this.loadProjectDetails();
		this.showCloneProject();

	}

	public loadProjectDetails(){

		let params = new URLSearchParams(window.location.search);
		let ProjectName = params.get('?projectname');
		let url = (<any>window).acConfig.editAssessmentAPI + ProjectName;
		this.apiService.getAPI(url, '').subscribe(
			data => {

				this.loaderProjectDetails = false;
				if(data.status == 200){
					
					this.selectedProject = data.json();
					this.projectBasicForm.patchValue({ 'name':"copy of " + this.selectedProject.name  });
					this.checkProjectName();

				}else{

					this.translate.get('NOTIFICATIONFAILURE.CLONEIC.GETICDETAILSTOCLONE', {message: data.statusText}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "cloneic",
							"title" : "Get IC to Clone",
							"type":"Error",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});								
					this.assessmentService.backtoSSUE("CFAssessment:Projects");

				}
				

			},
			err => {
				this.loaderProjectDetails = false;
				this.translate.get('NOTIFICATIONFAILURE.CLONEIC.GETICDETAILSTOCLONE', {message: err._body}).subscribe((res: string) => {
					let alertMetaData = {
						"name": "cloneic",
						"title" : "Get IC to Clone",
						"type":"Error",
						"content": res
					}    
					this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);		
				});	
				this.assessmentService.backtoSSUE("CFAssessment:Projects");				
			}
			,() => {}
		);
		

	}

	public showCloneProject(){
		
		let dialog = this.dialogCloneProject;
		dialog.width = "300px";
		dialog.height = "300px";
		dialog.showDialog();

	}

	public onCancelCloneProject(){

		let dialog = this.dialogCloneProject;
		dialog.cancelAction();
		this.assessmentService.backtoSSUE("CFAssessment:Projects");
	}
	
	public onSave(){
		this.loaderSaveButton = true;

		let params = new URLSearchParams(window.location.search);
		let ProjectName = params.get('?projectname');

		let postData = this.selectedProject; 
		postData.name = this.projectBasicForm.controls.name.value;
		postData.owner =this.appService.get("cecID");
		delete postData.createdTime;	
		delete postData.updatedTime;

		let url = (<any>window).acConfig.updateAssessmentAPI;
		this.apiService.postUrl(url, JSON.stringify(postData)).subscribe(
            (result) => {
				if (result.status === 200) {
					
					this.translate.get('NOTIFICATIONSUCCESS.CLONEPROJECT.SAVECLONEPROJECT', {fromProjectName: decodeURI(ProjectName), newProjectName: postData.name}).subscribe((res: string) => {

						let alertMetaData = {
							"name": "cloneproject",
							"title" : "Clone Project Success",
							"type":"SUCCESS",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

					});
					
					this.loaderSaveButton = false;
					this.assessmentService.backtoSSUE("CFAssessment:Projects");

				}else{

					this.translate.get('NOTIFICATIONFAILURE.CLONEPROJECT.SAVECLONEPROJECT', {ProjectName: ProjectName}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "cloneproject",
							"title" : "Clone Project Failure",
							"type":"DANGER",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});					
					this.loaderSaveButton = false;
					this.assessmentService.backtoSSUE("CFAssessment:Projects");

				}

			},
			(err) => {
				if(err.status === 400 && err.json().enlightenMessages[0].code =="DOCKET_NAME_ALREADY_EXISTS"){
					this.projectDuplicate = true;
				}
				else{
					this.translate.get('NOTIFICATIONFAILURE.CLONEPROJECT.SAVECLONEPROJECT', {ProjectName: err._body}).subscribe((res: string) => {
						let alertMetaData = {
							"name": "cloneproject",
							"title" : "Clone Project Failure",
							"type":"DANGER",
							"content": res
						}    
						this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
					});
				}
				
				this.loaderSaveButton = false;
				this.assessmentService.backtoSSUE("CFAssessment:Projects");
				
		});
		

	}

	public checkProjectName() {
		this.duplicateCheck = true;
        if (this.projectBasicForm.controls.name.value != "") {
            let url = (<any>window).acConfig.editAssessmentAPI + this.projectBasicForm.controls.name.value;
            this.apiService.getAPI(url, '').subscribe(
                data => {   
					this.duplicateCheck = false;                 
                    if (data.status == 200) {
                        this.projectDuplicate = true;
                    }else{
						this.projectDuplicate = false;
					}
                },
                err => {
					this.duplicateCheck = false;
                    this.projectDuplicate = true;
                    if (err.status == 404) {
                        this.projectDuplicate = false;
                    }
                    console.error(err);
                }
                , () => { }
            );
		}
		
    }
		
}