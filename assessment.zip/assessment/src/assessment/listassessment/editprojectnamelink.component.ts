import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'edit-assessment-user',
    template: `<a (click)="gotoLink()">{{params.data.name}}</a>`
})

export class EditProjectNameLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {    
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {		
        
        let link = '/assessment/view?assessmentId=' + this.params.data.name + '&status=' + this.params.data.status;
        this.router.navigateByUrl(link);   
        //this.params.context.componentParent.showStatusLog(this.params.data.assessmentId);
        
    }
}