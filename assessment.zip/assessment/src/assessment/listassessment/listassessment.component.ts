import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

import { EditProjectNameLinkComponent } from 'assessment/listassessment/editprojectnamelink.component';
import { EditStatusLinkComponent } from 'assessment/listassessment/editstatuslink.component';

@Component({
  selector: 'list-assessment',
  templateUrl: './listassessment.template.html',
  styleUrls: [ './listassessment.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class ListAssessmentComponent {  

  public selectedNodesLength:any;
  public selectedNode:any;

  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;

  public showActions: any;
  public showToolPanel: any;
	
  @ViewChild('showStatusHistory') showStatusHistory:ElementRef;

	constructor(public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService, public router: Router) {
			
	}

  	ngOnInit(){
		
		this.gridOptions = <GridOptions>{
			context: {
                componentParent: this
            },
			suppressRowClickSelection: true,
			rowSelection: 'multiple',
			paginationPageSize: 10,
			pagination: true,
			enableFilter: true,
			floatingFilter: true,
			columnDefs: this.createColumnDefs(),			
			overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no projects</span>',
			overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'		
		}; 

		this.getAssessments();
	
  	}  


	public onRowSelected($event) {

		let selectedNodes = this.gridOptions.api.getSelectedNodes();	
		if(selectedNodes.length > 0)
			this.selectedNode = selectedNodes[0].data;
		this.selectedNodesLength = selectedNodes.length;

	}

	public editProject(){

		let selectedNodes = this.gridOptions.api.getSelectedNodes();				
		let name = selectedNodes[0].data.name;
		let status = selectedNodes[0].data.status;
		let editLink = '/assessment/ssue?operation=editproject&assessmentId=' + name + '&status=' + status;
		this.router.navigateByUrl(editLink);

	}


	deleteProject(){
		
		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		let name = [];
		let status = [];
		for (let node of selectedNodes){
			name.push(node.data.name);
			status.push(node.data.status);
		}
		let deleteLink = '/assessment/ssue?operation=deletproject&assessmentId=' + name.join("|") + '&status=' + status.join("|");
		this.router.navigateByUrl(deleteLink);

	}

	cloneProject(){
		let selectedNodes = this.gridOptions.api.getSelectedNodes();
		let cloneLink = '/assessment/cloneproject?projectname='+selectedNodes[0].data.name;
		this.router.navigateByUrl(cloneLink);
	}
	  
	getAssessments(){

		let url = (<any>window).acConfig.getAssessmentListAPI;
		this.apiService.getUrl(url, '').subscribe(
			data => {

				if(this.gridOptions != null && this.gridOptions.api != null){
					if(data.length > 0){
						this.logger.info("assessment list", data);
						this.gridOptions.api.setRowData(data);
						this.gridOptions.api.hideOverlay();
						this.gridOptions.api.sizeColumnsToFit();
					}else{
						this.gridOptions.api.setRowData([]);
						this.gridOptions.api.showNoRowsOverlay();
					}
				}

			},
			err => {
				console.error(err);
				let alertMetaData = {
					"name": "listassessmentfailure",
					"title": "List Assessment Failure",
					"type": "INFO",
					"content": err._body
				}
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				if(this.gridOptions != null && this.gridOptions.api != null)
					this.gridOptions.api.setRowData([]);
				this.gridOptions.api.showNoRowsOverlay();
			}
			,() => {}
		);

	}

	showStatusLog(name){

		this.appService.set('selectedAssessment', name);
		let showStatusHistory = this.showStatusHistory.nativeElement;
		showStatusHistory.click();
		
	}

	showStatusAudit(dialog){
		dialog.width = "25%";
		dialog.showDialog();
	}
  
  
  	public createColumnDefs() {
	  
        this.columnDefs = [
			{
				headerName: "",
				field: "selectAllAssessments",
				width: 50,
				headerCheckboxSelection: false,
				headerCheckboxSelectionFilteredOnly: false,
				checkboxSelection: true,
				pinned: true,
				suppressFilter: true
			},            			
			{headerName: "Project Name", field: "name",width: 150, sortingOrder: ['asc','desc'], cellRendererFramework:EditProjectNameLinkComponent, pinned: true,
				tooltipField: "name", headerTooltip: "Project Name",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Created Date", field: "createdTime",width: 150, cellRenderer:this.formatDate, pinned: true,
				tooltipField: "createdTime", headerTooltip: "Created Date", suppressSorting: true, suppressFilter : true
			},
			{headerName: "Project Status", field: "status",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "status", headerTooltip: "Project Status",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
            {headerName: "Job Status", field: "jobStatus",width: 150, sortingOrder: ['asc','desc'], cellRendererFramework:EditStatusLinkComponent, pinned: true,
                tooltipField: "jobStatus", headerTooltip: "Job Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
			{headerName: "Assessment Type", field: "catalogName",width: 150, sortingOrder: ['asc','desc'], pinned: true,  
				tooltipField: "catalogName", headerTooltip: "Assessment Type",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Users Assigned", field: "members",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "members", headerTooltip: "Users Assigned",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "AS Project ID", field: "pid",width: 100, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "pid", headerTooltip: "AS Project ID",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			},
			{headerName: "Description", field: "description",width: 150, sortingOrder: ['asc','desc'], pinned: true,
				tooltipField: "description", headerTooltip: "Description",
				icons: {
					sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
					sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
				},
			}
		];
		return this.columnDefs;

	}

	public formatDate(params){

		const datepipe: DatePipe = new DatePipe('en-US');
		return datepipe.transform(params.data.createdTime, 'yMMMdjms');

	}

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
		}
		
    }
	

	public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
		this.calculateRowCount();
    }
	
}