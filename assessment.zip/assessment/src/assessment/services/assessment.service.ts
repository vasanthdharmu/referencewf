import { Injectable, Input, Output, EventEmitter } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { LoggerService } from 'app/shared/logger.service';
import { AppService } from 'app/shared/app.service';

import { SmartBridgeDelegateService } from "app/lib/partner/integration/angular/services/smartbridge-delegate";


@Injectable()
export class AssessmentService {

  constructor(public router: Router, public logger: LoggerService, public delegate: SmartBridgeDelegateService, public appService: AppService) {


    if ((<any>top).ssue && (<any>top).ssue != ""){    

    }

    if(this.delegate.clientBridge != undefined){
        this.delegate.clientBridge.registerAlertMessageService(this.registerAlertMessageServiceCallback.bind(this));
        this.delegate.clientBridge.registerFiltersChangedEvent(this.registerFiltersChangedEventCallback.bind(this));
        this.delegate.clientBridge.registerRefreshService(this.registerRefreshServiceCallback.bind(this));
    }


  }

  smartBridgeService(serviceName, metaData){

    switch(serviceName){
      case "generateAlertMessageService":
            if(this.delegate.clientBridge != undefined){
                
                let alertMetaData = {
                  "name": metaData.name,
                  "title" : metaData.title,
                  "type": metaData.type, //INFO, WARNING, SUCCESS, DANGER
                  "target":"alertmessage",
                  "content": metaData.content,
                  "dismissRule": "",
                  "config": {
                    "autoDismiss": true,
                    "autoDismissTimeInterval": 5000
                  }
                };
            
                this.delegate.clientBridge.generateAlertMessageService(alertMetaData);
            
            }
            break;
    }

  }

  registerAlertMessageServiceCallback(){
    
  }

  registerRefreshServiceCallback(){
    console.log("registerRefreshServiceCallback");
    this.onRefresh();
  }

  registerFiltersChangedEventCallback(){
    console.log("registerFiltersChangedEventCallback");
    this.onRefresh();
  }
  
  onRefresh() {
		
		this.router.routeReuseStrategy.shouldReuseRoute = function(){ return false; };		
		let currentUrl = this.router.url + '?';
    console.log("currentUrl", currentUrl);
    this.appService.updateSSUEFilter();
		this.router.navigateByUrl(currentUrl)
		.then(() => {
			this.router.navigated = false;
			this.router.navigateByUrl(currentUrl);
		});

  }
  

  //CFAssessment:Projects
  backtoSSUE(name, type = "report"){
   
    switch(type){

      case "report":
          parent.window.top.postMessage({'message':'lnpJump','data':{'lnpResourceId': 'CAEntitlement:SSUE:LNPs:'+name,
            'refresh': true
            }
          },'*');
          break;
      case "tab":
          parent.window.top.postMessage({'message':'lnpJump','data':{'lnpResourceId': 'CAEntitlement:SSUE:LNPs:'+name,
            'refresh': true
            }
          },'*');
          break;
      default:
          parent.window.top.postMessage({'message':'lnpJump','data':{'lnpResourceId': 'CAEntitlement:SSUE:LNPs:'+name,
            'refresh': true
            }
          },'*');
          break;

    }

  }

}