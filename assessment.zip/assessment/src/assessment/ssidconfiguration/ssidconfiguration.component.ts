import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

@Component({
    selector: 'ssid-configuration',
    templateUrl: './ssidconfiguration.template.html',
    styleUrls: ['./ssidconfiguration.style.css'],
    encapsulation: ViewEncapsulation.None
})

export class SsidConfigurationComponent implements OnInit {
   
    public allSSIDs = [
        {   
            listName: "Available SSID(s)", 
            items: [
                { 'name': 'CNHI-Mobile' },
                { 'name': 'CNHI-Consultant' },
                { 'name': 'CNHI-Guest' },
                { 'name': 'FG-WiFi' },
                { 'name': 'VirtualRoom' }
            ], 
            dragging: false
        },
        {   
            listName: "Corporate SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "Voice SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "Guest SSID(s)", 
            items: [], 
            dragging: false
        }
      ];
    constructor(public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    }

    ngOnInit() {

    }

    public removeItem(item: any, list: any[]): void {
        list.splice(list.indexOf(item), 1);
        console.log("this.allSSIDs", this.allSSIDs);
    }

    onMoved(list){
        
        list.items = list.items.filter(function(item) { return !item.selected; });
          
    }

    onDragstart(list, event) {
        
        list.dragging = true;
        
    }

    getSelectedItemsIncluding(list, item) {
        item.selected = true;
        return list.items.filter(function(item) { return item.selected; });
    }

    onDrop(list, items, index) {
        items.forEach((item) => { item.selected = false; });
        list.items = list.items.slice(0, index)
                    .concat(items)
                    .concat(list.items.slice(index));
        return true;
    }

}
