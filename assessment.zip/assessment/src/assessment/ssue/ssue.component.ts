import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod, URLSearchParams, Jsonp } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

import { FusionAlert } from 'aui/components/notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from 'aui/components/notification-alert/alertanchor.directive';

@Component({
  selector: 'ssue-operations',
  templateUrl: './ssue.template.html',
  styleUrls: [ './ssue.style.css' ],
  encapsulation: ViewEncapsulation.None,
  entryComponents: [ FusionToaster, FusionAlert ]
})
export class SSUEComponent {
  
  public operation:any;

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  @ViewChild(AlertAnchorDirective) alertAnchor;
  @ViewChild('deletefusionalert') deletefusionalert:ElementRef;

 
  constructor(public http:Http, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public router: Router, public assessmentService: AssessmentService) {


  }


  ngOnInit(){

    let params = new URLSearchParams(window.location.search);
    this.operation = params.get('?operation');

    switch(this.operation){
      case "deletproject":
        this.deleteconfirmation("deletproject");
        break;
      case "editproject":
        this.editproject();
        break;  
      case "editic":
        this.editic();
        break;
      case "gotonextstage":
        this.gotonextstage();
        break;
      case "deleteic":
        this.deleteconfirmation("deleteic");
        break;
      case "deleteassessmenttype":  
        this.deleteconfirmation("deleteassessmenttype");
        break;
      case "editassessmenttype":
        this.editassessmenttype();
        break;  
    }

    this.appendCUIComponentstoWrapper();

  }

  public gotonextstage(){

    let params = new URLSearchParams(window.location.search);
    let assessmentId = params.get('assessmentId');
    let status = decodeURIComponent(params.get('status')).toLowerCase();

    switch(status){
      case "collection-completed":
        let editLink = '/assessment/analysis?assessmentName=' + assessmentId + '&status=' + status;
        this.router.navigateByUrl(editLink);   
        break;
      default:
        let alertMetaData = {
          "name": "gotonextstage",
          "title": "Go to next state based on project status",
          "type": "INO",
          "content": "No action is defined for this project status"
        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        this.assessmentService.backtoSSUE("CFAssessment:Projects");
        break;
    }

  }

  public appendCUIComponentstoWrapper(){
    //document.getElementById("content-wrapper").appendChild(document.getElementById("deletefusionalert"));
    document.body.appendChild(document.getElementById("deletefusionalert"));
	}

  editproject(){

    let params = new URLSearchParams(window.location.search);
    let assessmentId = params.get('assessmentId');
    let status = decodeURIComponent(params.get('status')).toLowerCase();
    if(status == "draft"){
      let editLink = '/assessment/initiate?assessmentId=' + assessmentId;		
      this.router.navigateByUrl(editLink);
    }else{
      let editLink = '/assessment/edit?assessmentId=' + assessmentId + '&status=' + status;
      this.router.navigateByUrl(editLink);
    }

  }

  editic(){
    
    let params = new URLSearchParams(window.location.search);
    let ICName = decodeURIComponent(params.get('ICName')).toLowerCase();
    let editLink = '/assessment/editic?ICName=' + ICName;
    this.router.navigateByUrl(editLink);
 
  }

  editassessmenttype(){
    
        let params = new URLSearchParams(window.location.search);
        let assessmentTypeName = decodeURIComponent(params.get('AssessmentTypeName'));
        let editLink = '/assessment/listicofassessment?AssessmentTypeName=' + assessmentTypeName;
        this.router.navigateByUrl(editLink);
    
  }

  deleteconfirmation(purpose){      

      switch(purpose){

        case "deletproject":
          this.deleteProjectConfirmation();
          break; 
        case "deleteic":
          this.deleteICConfirmation();
          break;
        case "deleteassessmenttype":
          this.deleteAssessmentTypeConfirmation();
          break;
      }
      
  }

  deleteProjectConfirmation(){

    let deletefusionalert = this.deletefusionalert.nativeElement;  
    let buttons =  [{
        label: "Yes",
    }, {
        label: "No"
    }];
    let params = new URLSearchParams(window.location.search);
    let assessmentId = decodeURIComponent(params.get('assessmentId')).split("|").join(", ");
    this.alertAnchor.createAlert(FusionAlert,"warning","Do you really want to delete project name " + assessmentId +" ?","",deletefusionalert, buttons);

  }

  deleteICConfirmation(){
    
      let deletefusionalert = this.deletefusionalert.nativeElement;  
      let buttons =  [{
          label: "Yes",
      }, {
          label: "No"
      }];      
      let params = new URLSearchParams(window.location.search);
      let ICNames = decodeURIComponent(params.get('name')).split("|");
      let visibility = decodeURIComponent(params.get('visibility')).split("|");
      let privateICs = [];
      let publicICs = [];
      for(let i = 0; i < ICNames.length; i++){
        if(visibility[i].toLowerCase() == "private"){
          privateICs.push(ICNames[i]);
        }
        if(visibility[i].toLowerCase() == "public"){
          publicICs.push(ICNames[i]);
        }
      }
      if(privateICs.length > 0){

        let msg = privateICs.length == 1 ? "Private IC " : "Private ICs ";
        let message = "Do you really want to delete the " + msg + privateICs.join(', ') +" ?";
        if(publicICs.length > 0){
          let publicmsg = publicICs.length == 1 ? "Public IC " : "Public ICs ";
          message += " Chosen " + publicmsg + publicICs.join(', ') + " cannot be deleted.";
        }
        this.alertAnchor.createAlert(FusionAlert,"warning",message,"",deletefusionalert, buttons);

      }else{

        if(publicICs.length > 0){
          let msg = publicICs.length == 1 ? "Public IC " : "Public ICs ";
          let alertMetaData = {
            "name": "deleteic",
            "title" : "Delete PublicIC Notification",
            "type":"WARNING",
            "content": "You cannot delete the " + msg + publicICs.join(', ')
          }
          this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        }
        this.assessmentService.backtoSSUE("CFAssessment:ICManager");
      }
          
  }

  deleteAssessmentTypeConfirmation(){
    
      let deletefusionalert = this.deletefusionalert.nativeElement;  
      let buttons =  [{
          label: "Yes",
      }, {
          label: "No"
      }];      
      let params = new URLSearchParams(window.location.search);
      let AssessmentTypeNames = decodeURIComponent(params.get('name')).split("|");
      let visibility = decodeURIComponent(params.get('visibility')).split("|");
      let privateAssessmentTypes = [];
      let publicAssessmentTypes = [];
      for(let i = 0; i < AssessmentTypeNames.length; i++){
        if(visibility[i].toLowerCase() == "private"){
          privateAssessmentTypes.push(AssessmentTypeNames[i]);
        }
        if(visibility[i].toLowerCase() == "public"){
          publicAssessmentTypes.push(AssessmentTypeNames[i]);
        }
      }
      if(privateAssessmentTypes.length > 0){

        let msg = privateAssessmentTypes.length == 1 ? "Assessment Type " : "Assessment Types ";
        let message = "Do you really want to delete the " + msg + privateAssessmentTypes.join(', ') +" ?";
        if(publicAssessmentTypes.length > 0){
          let publicmsg = publicAssessmentTypes.length == 1 ? "Public Assessment Type " : "Public Assessment Types ";
          message += " Chosen " + publicmsg + publicAssessmentTypes.join(', ') + " cannot be deleted.";
        }
        this.alertAnchor.createAlert(FusionAlert,"warning",message,"",deletefusionalert, buttons);

      }else{

        if(publicAssessmentTypes.length > 0){
          let msg = publicAssessmentTypes.length == 1 ? "Public Assessment Type " : "Public Assessment Types ";
          let alertMetaData = {
            "name": "deleteassessmenttype",
            "title" : "Delete Public Assessment Type Notification",
            "type":"WARNING",
            "content": "You cannot delete the " + msg + publicAssessmentTypes.join(', ')
          }
          this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        }
        this.assessmentService.backtoSSUE("CFAssessment:ICManager");
      }
          
  }

  onDeleteAlertButtonClick(event){
    
      let target = event.target || event.srcElement || event.currentTarget;
      let params = new URLSearchParams(window.location.search);
      let purpose = params.get('?operation');    
      switch(target.innerHTML){

        case "Yes":
    
            switch(purpose){
              case "deletproject":
                this.deleteProject();
                break;                 
              case "deleteic":
                this.deleteIC();
                break;
              case "deleteassessmenttype":
                this.deleteAssessmentType();
                break;  
            }
            
            break;
        
        case "No":

            switch(purpose){
              case "deletproject":
                this.assessmentService.backtoSSUE("CFAssessment:Projects");
                break;                 
              case "deleteic":
                this.assessmentService.backtoSSUE("CFAssessment:ICManager");
                break;
              case "deleteassessmenttype":
                this.assessmentService.backtoSSUE("CFAssessment:ICManager");
                break;  
            }                
            break;
        
      }

  }

  deleteProject(){

    let params = new URLSearchParams(window.location.search);
    let assessmentId = decodeURIComponent(params.get('assessmentId')).split("|");
    let status = decodeURIComponent(params.get('status')).split("|");
    let combined: any;
    let observableBatch = [];

    for(let i = 0; i < assessmentId.length; i++){

      if(status[i].toLowerCase() == "draft"){
       
        let deleteassessmenturl = (<any>window).acConfig.deleteAssessmentAPI + assessmentId[i];
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
          headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
          headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        headers.append("Content-Type", "application/json");
        let deleteassessmentrequestOptions = new RequestOptions({
          method: RequestMethod.Delete,
          url: deleteassessmenturl,
          headers: headers,
          body: ''
        });
        
        observableBatch.push( this.http.request(new Request(deleteassessmentrequestOptions)).map((res: Response) => {  }) );

        let deleteworkflowprocessurl = (<any>window).acConfig.deleteAssessmentDataWorkflowAPI + this.appService.get("workFlowId") + '/users/' + this.appService.get("cecID") + '/assessments/' + assessmentId[i];
        let deleteworkflowprocessrequestOptions = new RequestOptions({
          method: RequestMethod.Delete,
          url: deleteworkflowprocessurl,
          headers: headers,
          body: ''
        });                    
        
        observableBatch.push( this.http.request(new Request(deleteworkflowprocessrequestOptions)).map((res: Response) => {  }) );

      }else{

        let url = (<any>window).acConfig.deleteAssessmentAPI + assessmentId[i];       
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
          headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
          headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Content-Type","application/json");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
          method: RequestMethod.Delete,
          url: url,
          headers: headers,
          body: ''
        });
      
        observableBatch.push( this.http.request(new Request(requestOptions)).map((res: Response) => {  }) );   

      }                  

    }

    combined = Observable.forkJoin(observableBatch);

    combined.subscribe(
      finalResponse => {

        let msg = decodeURIComponent(params.get('assessmentId')).split("|").length == 1 ? "Project name " : "Project names ";
        let alertMetaData = {
          "name": "deleteproject",
          "title" : "Delete Project Success",
          "type":"SUCCESS",
          "content": msg + decodeURIComponent(params.get('assessmentId')).split("|").join(", ") + " deleted successfully."       
        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        this.assessmentService.backtoSSUE("CFAssessment:Projects");

      },
    error => {
      console.log("Delete error Response", error);
      let alertMetaData = {
        "name": "deleteproject",
        "title" : "Delete Project Failure",
        "type":"DANGER",
        "content": "Error during deleting some project"     
      }    
      this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
      this.assessmentService.backtoSSUE("CFAssessment:Projects");
    });

  }  

  deleteIC(){
    
      let params = new URLSearchParams(window.location.search);
                
      let ICNames = decodeURIComponent(params.get('name')).split("|");
      let visibility = decodeURIComponent(params.get('visibility')).split("|");
      let combined: any;
      let observableBatch = [];
      let privateICs = [];
      let publicICs = [];
      for(let i = 0; i < ICNames.length; i++){

        if(visibility[i].toLowerCase() === "private"){

          privateICs.push(ICNames[i]);
          let deleteicurl = (<any>window).acConfig.deleteICAPI + ICNames[i];
          var headers = new Headers();
          if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
          }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
          }
          headers.append("loggedin", this.appService.get("cecID"));
          headers.append("CUSTOMER", this.appService.get("cpyKey"));
          headers.append("Content-Type", "application/json");
          let deleteicrequestOptions = new RequestOptions({
            method: RequestMethod.Delete,
            url: deleteicurl,
            headers: headers,
            body: ''
          });
          
          observableBatch.push( this.http.request(new Request(deleteicrequestOptions)).map((res: Response) => {  }) );

        }

      }

      combined = Observable.forkJoin(observableBatch);
      
      combined.subscribe(
        finalResponse => {

          let msg = privateICs.length == 1 ? "Private IC " : "Private ICs ";
          let alertMetaData = {
            "name": "deleteic",
            "title" : "Delete IC Success",
            "type":"SUCCESS",
            "content": msg + privateICs.join(", ") + " deleted successfully."
          }    
          this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          this.assessmentService.backtoSSUE("CFAssessment:ICManager");

        },
      error => {
        let alertMetaData = {
          "name": "deleteic",
          "title" : "Delete IC Failure",
          "type":"DANGER",
          "content": "Error during deleting some ICs"
        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        this.assessmentService.backtoSSUE("CFAssessment:ICManager");
      });

  }

  deleteAssessmentType(){
    
      let params = new URLSearchParams(window.location.search);
                
      let AssessmentTypeNames = decodeURIComponent(params.get('name')).split("|");
      let visibility = decodeURIComponent(params.get('visibility')).split("|");
      let combined: any;
      let observableBatch = [];
      let privateAssessmentTypes = [];
      for(let i = 0; i < AssessmentTypeNames.length; i++){

        if(visibility[i].toLowerCase() === "private"){

          privateAssessmentTypes.push(AssessmentTypeNames[i]);
          let deleteicurl = (<any>window).acConfig.deleteAssessmentTypeAPI + AssessmentTypeNames[i];
          var headers = new Headers();
          if((<any>top).ssue_accessToken != undefined){
            headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
          }else{
            headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
          }
          headers.append("loggedin", this.appService.get("cecID"));
          headers.append("CUSTOMER", this.appService.get("cpyKey"));
          headers.append("Content-Type", "application/json");
          let deleteicrequestOptions = new RequestOptions({
            method: RequestMethod.Delete,
            url: deleteicurl,
            headers: headers,
            body: ''
          });
          
          observableBatch.push( this.http.request(new Request(deleteicrequestOptions)).map((res: Response) => {  }) );

        }

      }

      combined = Observable.forkJoin(observableBatch);
      
      combined.subscribe(
        finalResponse => {

          let msg = privateAssessmentTypes.length == 1 ? "Assessment Type " : "Assessment Types ";
          let alertMetaData = {
            "name": "deleteassessmenttype",
            "title" : "Delete Assessment Type Success",
            "type":"SUCCESS",
            "content": msg + privateAssessmentTypes.join(", ") + " deleted successfully."
          }    
          this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          this.assessmentService.backtoSSUE("CFAssessment:ICManager");

        },
      error => {
        let alertMetaData = {
          "name": "deleteassessmenttype",
          "title" : "Delete Assessment Type Failure",
          "type":"DANGER",
          "content": "Error during deleting some AssessmentType(s)"
        }    
        this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        this.assessmentService.backtoSSUE("CFAssessment:ICManager");
      });

  }

}