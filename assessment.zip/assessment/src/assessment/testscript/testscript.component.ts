import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { AceEditorComponent } from 'ng2-ace-editor';
import "brace/mode/python";
import "brace/mode/json";

@Component({
    selector: 'test-script',
    templateUrl: './testscript.template.html',
    styleUrls: ['./testscript.style.css'],
    encapsulation: ViewEncapsulation.None
})

export class TestScriptComponent implements OnInit {
    @ViewChild('dialogSampleData') dialogSampleData;
    @Input() commandList:any = [];
    @Input() ICScript:any = "";
    public selectedCommand: any;
    public resultScriptData: any;
    public resultScriptDataLoading: boolean = false;
    public resultDataEditorOptions: any = { highlightActiveLine: false, highlightGutterLine: false, printMargin: false, enableBasicAutocompletion: true };
    public sampleDataEditoroptions: any = { highlightActiveLine: false, highlightGutterLine: false, printMargin: false, enableBasicAutocompletion: true };
    constructor(public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

    }

    ngOnInit() {
        if(this.commandList != undefined){
            this.commandList.forEach((command, index) => 
                {
                    if(index == 0)
                        this.selectedCommand = command.command;
                    command['sampleData'] = "";
                    command['file'] = "";
            });
        }
    }

    public showSampleDataPopUp() {
        let dialog = this.dialogSampleData;
        dialog.width = "80%";
        dialog.height = "750px";
        dialog.showDialog();
    }

    onFileUploadChange(event, command) {
		
		if(event.target.files.length > 0) {

			let file = event.target.files[0];
			let fileTypes = ["application/json"];
			this.logger.info("sample data file", file);			
			if ( fileTypes.indexOf(file.type) != -1 ) {
                command['file'] = file;
			}else{
                command['file'] = "";
				let alertMetaData = {
					"name": "sampledataselection",
					"title" : "Sample Data Selection",
					"type":"INFO",
					"content": "Please choose only json file."         
				}    
				this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
			}

		}else{
            command['file'] = "";
        }
		
    }
    
    uploadSampleData(command){

            let formData:FormData = new FormData();
            formData.append("file", command.file);
            this.logger.info("formData", formData);

            this.apiService.postFile((<any>window).acConfig.fileUploadAPI, formData).subscribe(
            (result) => {

                this.logger.info("sample data upload result", result);
                if(result.status === 200){

                    this.logger.info("result", (<any>result)._body);
                    let alertMetaData = {
                        "name": "sampledataupload",
                        "title" : "Sample Data Upload - Success",
                        "type":"SUCCESS",
                        "content": (<any>result)._body
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

                }else{

                    let alertMetaData = {
                        "name": "sampledataupload",
                        "title" : "Sample Data Upload - Failure",
                        "type":"DANGER",
                        "content": "Error during file upload. Please try again."
                    }    
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);

                }
                
                
            },
            (err) => {
                this.logger.info("sample data upload error", err);
                let alertMetaData = {
                "name": "sampledataupload",
                "title" : "Sample Data Upload - Failure",
                "type":"DANGER",
                "content": "Error during file upload. Please try again."         
                }    
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            });
        
    }

    runTest(){
        console.log("this.commandList", this.commandList);
        this.close();
        this.resultScriptDataLoading = true;
        this.resultScriptData = "result will be displaying here";
        this.resultScriptDataLoading = false;
    }

    public close() {
        let dialog = this.dialogSampleData;
        dialog.cancelAction();
    }

}
