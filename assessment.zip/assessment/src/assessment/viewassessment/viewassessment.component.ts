import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { URLSearchParams } from "@angular/http";
import { GridOptions } from 'ag-grid/main';
import { TranslateService } from 'ng2-translate';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { CuiTableOptions } from 'aui/components/cui-table';

@Component({
    selector: 'assessment-details',
    templateUrl: './viewassessment.template.html',
    styleUrls: ['./viewassessment.style.css'],
    encapsulation: ViewEncapsulation.None
})
export class ViewAssessmentComponent {

    public assessmentData: any = {};
    public assessmentId: any;
    public loaderAssessmentData: boolean = false;

    public gridOptionsDevices: GridOptions;
    public rowDataDevices: any[];
    public columnDefsDevices: any[];
    public rowCountDevices: string;
    public tableDataSourceDevices: any[];
    public rowModelPaginationTypeDevices: string;

    public gridOptionsIC: GridOptions;
    public rowDataIC: any[];
    public columnDefsIC: any[];
    public rowCountIC: string;
    public tableDataSourceIC: any[];
    public rowModelPaginationTypeIC: string;
    public periodList = [{ "value": "10080", "name": "7 days" },
        { "value": "8640", "name": "6 Days" },
        { "value": "7200", "name": "5 Days" },
        { "value": "5760", "name": "4 Days" },
        { "value": "4320", "name": "3 Days" },
        { "value": "2880", "name": "2 Days" },
        { "value": "1440", "name": "1 Day" },
        { "value": "60", "name": "1 Hr" },
        { "value": "10", "name": "10 Min" }];

    public customCommandTableOptions: CuiTableOptions;
    public customCommands: Array<any> = [];
    public popupdata: any;
    public snmpCommandFilter: any;
    public cliCommandFilter: any;
    public customCommandFilter: any;
    @ViewChild('dialogDevices') dialogDevices: ElementRef;

    constructor(public translate: TranslateService, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public assessmentService: AssessmentService) {

        this.gridOptionsDevices = <GridOptions>{
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefsDevices(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No devices</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };

        this.gridOptionsIC = <GridOptions>{
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefsIC(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">No ICs</span>',
            overlayLoadingTemplate: '<div class="loading-spinner flex-center"><div class="wrapper"><div class="wheel"></div></div></div>'
        };


        this.customCommandTableOptions = new CuiTableOptions({
            "bordered": true,
            "striped": false,
            "hover": false,
            "wrapText": false,
            "padding": "regular",
            "selectable": false,
            "dynamicData": true,
            "columns": [
                {
                    "name": "Command Name",
                    "key": "command"
                },
                {
                    "name": "Command Type",
                    "key": "mode"
                },
                {
                    "name": "OS Type",
                    "key": "ostypes"
                },
                {
                    "name": "Version",
                    "key": "version"
                },
                {
                    "name": "Repetition",
                    "key": "repetition"
                },
                {
                    "name": "Frequency",
                    "key": "frequency"
                }
            ]
        });

    }

    ngOnInit() {

        let params = new URLSearchParams(window.location.search);
        this.assessmentId = params.get('?assessmentId');
        let status = params.get('status');
        console.log(status.toLowerCase() == "draft");
        if (status.toLowerCase() == "draft") {
            this.loadAssessmentDataFromWF(this.assessmentId);
        } else {
            this.loadAssessmentData(this.assessmentId);
        }

        // this.loadAssessmentData(this.assessmentId);

    }

    loadAssessmentData(assessmentId) {

        this.loaderAssessmentData = true;
        this.apiService.getAPI((<any>window).acConfig.editAssessmentAPI + assessmentId, '').subscribe(

            data => {

                if (data != null && data.status === 200) {

                    let respData = data.json();
                    this.logger.info("respData", respData);
                    let deviceNames = [];
                    let IClist = [];
                    /*for (let device of respData.devices) {
                        deviceNames.push({ "deviceId": device });
                    }*/
                    // for(let ic of respData.icSubSet){
                    //   IClist.push({"ICName":ic});
                    //   console.log(IClist);
                    // }
                    this.assessmentData = respData;
                    //this.assessmentData.deviceNames = deviceNames;
                    //this.loadCollectionDurationList(this.assessmentData.assessmentType, this.assessmentData.platform, this.assessmentData.collectionDuration);
                    this.loaderAssessmentData = false;
                    // this.gridOptionsDevices.api.setRowData([]);
                    this.assessmentData.projectName = respData.name;
                    this.assessmentData.asProjectId = respData.pid;
                    this.assessmentData.assessmentTypes = respData.catalogName;
                    this.assessmentData.collectionDuration = respData.duration;
                    this.assessmentData.startCollection = (respData.schedule == "" || respData.schedule == null) ? "Now" : "Later";
                    this.assessmentData.startCollectionDateandTime = (respData.schedule == "") ? "" : respData.schedule;
                    this.assessmentData.usersAllowed = respData.members.length>0 ? respData.members.toString(): respData.owner;
                    this.assessmentData.collectorId = respData.applianceId;
                    let url = (<any>window).acConfig.getDevicesAPI + this.appService.get("cpyKey") + '/collector/' + this.assessmentData.collectorId;
                    this.apiService.getAPI(url, '').subscribe(
                        data => {
                            let respDeviceData = data.json();
                            let devices = respData.devices;
                            let deviceSelected = [];
                            for (let device of devices) {
                                deviceSelected.push(device);
                            }
                            respDeviceData.forEach(deviceDetails => {
                                if (deviceSelected.indexOf(deviceDetails.deviceId) > -1) {
                                    deviceNames.push(deviceDetails);
                                }
                            });
                            this.gridOptionsDevices.api.setRowData(deviceNames);
                            this.assessmentData.deviceNames = deviceNames;
                        },
                        err => {
                            console.error(err);
                            this.translate.get('NOTIFICATIONINFO.VIEWASSESSMENT.DEVICELIST').subscribe((res: string) => {
                            let alertMetaData = {
                                "name": "getdevices",
                                "title" : "Get Devices",
                                "type":"INFO",
                                "content": res        
                            }    
                            this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                            });
                        }
                        , () => { }
                    );
                    //this.gridOptionsDevices.api.setRowData(deviceNames);
                    // this.gridOptionsIC.api.setRowData(IClist);
                    this.loadCustomeIClist(respData.icSubSet);
                    this.customCommands = respData.commandSet != null ? JSON.parse(respData.commandSet) : [];

                }else{
                    this.translate.get('NOTIFICATIONFAILURE.VIEWASSESSMENT.LOADPROJECT',{error:data.statusText}).subscribe((res: string) => {
                    let errorAlert = {
                        "name": "projectdetailsfromdocket",
                        "title": "Load project from docket",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", errorAlert);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:Projects");

                }

            },
            err => {
                this.loaderAssessmentData = false;
                console.error(err);
                this.translate.get('NOTIFICATIONFAILURE.VIEWASSESSMENT.LOADPROJECT',{error:err._body}).subscribe((res: string) => {
                let errorAlert = {
                    "name": "projectdetailsfromdocket",
                    "title": "Load project from docket",
                    "type": "DANGER",
                    "content": res
                }
                this.assessmentService.smartBridgeService("generateAlertMessageService", errorAlert);
                });
                this.assessmentService.backtoSSUE("CFAssessment:Projects");
            }
            , () => { }
        );
    }

    loadAssessmentDataFromWF(assessmentId) {

        this.loaderAssessmentData = true;
        this.apiService.getAPI((<any>window).acConfig.getAssessmentDataWorkflowAPI + '?mode=view&workflowId=AsWorkflowProcess&assessmentId=' + assessmentId + '&userId=' + this.appService.get("cecID"), '').subscribe(
            (result) => {


                if (result != null && result.status === 200) {

                    this.loaderAssessmentData = false;
                    let respData = result.json();
                    this.logger.info("loadAssessmentDataFromWF", respData);
                    this.assessmentData = respData.payLoad.basicDetails;
                    this.assessmentData.customCommands = [];
                    this.assessmentData.excludedSNMPs = [];
                    this.assessmentData.excludedCLIs = [];
                    this.assessmentData.assessmentId = respData.assessmentId;
                    this.assessmentData.asProjectId = respData.payLoad.basicDetails.asProjectID;                    
                    this.assessmentData.status = "draft";
                    //this.assessmentData.deviceN];
        
                    if (respData.payLoad.collectorAndDevices && respData.payLoad.collectorAndDevices.devices) {

                        this.assessmentData.collectorId = respData.payLoad.collectorAndDevices.collectorID;

                        if (respData.payLoad.collectorAndDevices.devices.length > 0) {

                            this.assessmentData.devices = respData.payLoad.collectorAndDevices.devices;
                            this.gridOptionsDevices.api.setRowData(this.assessmentData.devices);
                            this.gridOptionsDevices.api.sizeColumnsToFit();
                            /*
                            for(let device of respData.payLoad.collectorAndDevices.devices) {
                              this.assessmentData.deviceNames.push(device.deviceName);                
                            }
                            */
                        } else {
                            this.gridOptionsDevices.api.setRowData([]);
                        }

                    }

                    if (respData.payLoad.collectorAndDevices && respData.payLoad.collectorAndDevices.customCommands) {
                        this.assessmentData.customCommands = respData.payLoad.collectorAndDevices.customCommands;
                    }

                    if (respData.payLoad.collectorAndDevices && respData.payLoad.collectorAndDevices.excludedSNMPs) {
                        this.assessmentData.excludedSNMPs = respData.payLoad.collectorAndDevices.excludedSNMPs;
                    }

                    if (respData.payLoad.collectorAndDevices && respData.payLoad.collectorAndDevices.excludedCLIs) {
                        this.assessmentData.excludedCLIs = respData.payLoad.collectorAndDevices.excludedCLIs;
                    }

                    if (respData.payLoad.collectorAndDevices && respData.payLoad.collectorAndDevices.excludedCLIs) {
                        this.loadCustomeIClist(respData.payLoad.collectorAndDevices.includedICs);
                    }

                } else {

                    // this.loadAssessmentData(assessmentId);
                    this.translate.get('NOTIFICATIONFAILURE.VIEWASSESSMENT.LOADPROJECT',{error:result.statusText}).subscribe((res: string) => {
                    let errorAlert = {
                        "name": "projectdetailsfromwf",
                        "title": "Load project from WF",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", errorAlert);
                    });
                    this.assessmentService.backtoSSUE("CFAssessment:Projects");

                }

            },
            (err) => {

                //this.loadAssessmentData(assessmentId);
                this.translate.get('NOTIFICATIONFAILURE.VIEWASSESSMENT.LOADPROJECT',{error:err._body}).subscribe((res: string) => {
                let errorAlert = {
                    "name": "projectdetailsfromwf",
                    "title": "Load project from WF",
                    "type": "DANGER",
                    "content": res
                }
                this.assessmentService.smartBridgeService("generateAlertMessageService", errorAlert);
                });
                this.assessmentService.backtoSSUE("CFAssessment:Projects");

            });

    }

    public showDialog(dialog) {
        dialog.width = "80%";
        dialog.height = "80%";
        dialog.showDialog();
    }

    public showDialogPop(dialog, data) {

        this.popupdata = data;
        console.log("popupdata", this.popupdata);
        dialog.width = "50%";
        dialog.height = "40%";
        dialog.showDialog();

    }

    onClosePopup(event) {
        this.assessmentService.backtoSSUE("CFAssessment:Projects");
    }

    public createColumnDefsIC() {

        this.columnDefsIC = [
            {
                headerName: "IC Name", field: "name", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "name", headerTooltip: "IC Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "IC Type", field: "visibility", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "visibility", headerTooltip: "IC Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "OS Type", field: "osType", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "osType", headerTooltip: "OS Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "NMS Area", field: "nmsArea", width: 200, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "nmsArea", headerTooltip: "NMS Area",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Architecture Type", field: "architecture", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "architecture", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "IC Description", field: "summary", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "summary", headerTooltip: "IC Description",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Status", field: "status", width: 200, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "status", headerTooltip: "Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            }
        ];

        return this.columnDefsIC;

    }

    public calculateRowCountIC() {
        if (this.gridOptionsIC.api && this.rowDataIC) {
            var model = this.gridOptionsIC.api.getModel();
            var totalRows = this.rowDataIC.length;
            var processedRows = model.getRowCount();
            this.rowCountIC = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdatedIC() {
        this.calculateRowCountIC();
    }

    public onReadyIC(event) {
        //this.logger.info('onReady');
        this.calculateRowCountIC();
    }

    public onRowSelectedIC(event) {

    }

    public createColumnDefsDevices() {

        this.columnDefsDevices = [
            {
                headerName: "Device ID", field: "deviceId", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceName", headerTooltip: "Device Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Name", field: "deviceSysname", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceSysname", headerTooltip: "Device Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "IP Address", field: "ipAddress", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "ipAddress", headerTooltip: "IP Address",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Type", field: "deviceType", width: 150, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "deviceType", headerTooltip: "Device Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Device Version", field: "swVersion", width: 200, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "swVersion", headerTooltip: "Device Version",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Product Family", field: "productFamily", width: 250, sortingOrder: ['asc', 'desc'], pinned: true, tooltipField: "productFamily", headerTooltip: "Product Family",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
        ];
        return this.columnDefsDevices;

    }

    public calculateRowCountDevices() {
        if (this.gridOptionsDevices.api && this.rowDataDevices) {
            var model = this.gridOptionsDevices.api.getModel();
            var totalRows = this.rowDataDevices.length;
            var processedRows = model.getRowCount();
            this.rowCountIC = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
    }


    public onModelUpdatedDevices() {
        this.calculateRowCountDevices();
    }

    public onReadyDevices(event) {
        //this.logger.info('onReady');
        this.calculateRowCountDevices();
    }

    public onRowSelectedDevices(event) {

    }

    public getOptionValue(value, inputArray) {

        for (let input of inputArray) {
            if (input.value == value) {
                return input.name;
            }
        }
        return "";

    }


    public loadCustomeIClist(icList) {

        let url = (<any>window).acConfig.getICListAPI;
        let body = [
            {
                "attribute": "name",
                "value": icList
            }
        ];
        this.apiService.postUrl(url, body).subscribe(
            result => {

                if (result.status === 200) {

                    let respData = result.json();

                    if (respData.length > 0) {

                        this.gridOptionsIC.api.setRowData(respData);
                        this.gridOptionsIC.api.sizeColumnsToFit();
                        this.gridOptionsIC.api.hideOverlay();

                    } else {

                        this.gridOptionsIC.api.setRowData([]);
                        this.gridOptionsIC.api.showNoRowsOverlay();

                    }

                } else {
                    this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOIC').subscribe((res: string) => {
                    let alertMetaData = {
                        "name": "loadic",
                        "title": "Getting IC Details Failure",
                        "type": "DANGER",
                        "content": res
                    }
                    this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    });
                    this.gridOptionsIC.api.setRowData([]);
                    this.gridOptionsIC.api.showNoRowsOverlay();

                }

            },
            err => {

                console.log("error loading ic", err);
                this.translate.get('NOTIFICATIONFAILURE.ANALYSIS.NOIC').subscribe((res: string) => {
                let alertMetaData = {
                    "name": "loadic",
                    "title": "Getting IC Details Failure",
                    "type": "DANGER",
                    "content": res
                }
                this.assessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                });
                this.gridOptionsIC.api.setRowData([]);
                this.gridOptionsIC.api.showNoRowsOverlay();

            }
            , () => { }
        );
    }

}