window.tvaInstance = {
    jsonpCallback: function(command, data) {
        
    }
};