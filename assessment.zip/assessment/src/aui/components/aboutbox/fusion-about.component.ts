import {Component, Input,Output,EventEmitter} from '@angular/core';
import {maxZindexFinderService} from '../common/maxZindexFinder.service'; 

@Component({
   selector: 'fusion-about',
   styleUrls:  ['./aboutbox.style.css'],
   providers:[maxZindexFinderService],
   templateUrl: './aboutbox.template.html'
})
export class FusionAboutBox {
  @Input() aboutboxDetails:any;
  @Output() checkUpdate = new EventEmitter();
  @Output() provideFeedback = new EventEmitter();
  public showModal: boolean = false;
  public maxZindex:any;
  constructor(public _maxZindex: maxZindexFinderService) {}
  ngOnInit() {
      this.maxZindex = this._maxZindex.getZindex('div');
  }
  showAboutbox(){
    this.showModal = true;
  }
  onUpdate(){
    this.checkUpdate.emit(null);
  }
  onFeedback(){
    this.provideFeedback.emit(null);
  }
  cancelAction() {
    this.showModal = false;
  }
  
}