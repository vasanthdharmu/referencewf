/**
  FUSION ACCORDIONPANE COMPONENT
**/

import {Component, Input, OnDestroy, trigger, state, style, transition, animate} from '@angular/core';

/*** Parent Component ***/
        @Component({
           selector: 'fusion-accordion',
           styleUrls:['./accordionpane.css'],
           template:`<ng-content></ng-content>` 
        })

        export class FusionAccordionPane {
            public groups = [];
  
            addGroup(group) {
              this.groups.push(group);
            }
            
            closeOthers(openGroup) {
              this.groups.forEach((group) => {
                if (group !== openGroup) {
                  group.isOpen = false;
				          group._currentState = "close";
                }
              });
            }
            
            removeGroup(group){
              const index = this.groups.indexOf(group);
              if (index !== -1) {
                this.groups.splice(index, 1);
              }
            }
          
         }

		 
		 
/*** Child Component ***/		 
@Component({
  selector: 'accordion-pane',
  styleUrls:[ './accordionpane.css' ],
  templateUrl: './accordionpane.template.html',
  
  animations: [
    trigger('popsup', [
      state('open', style({       
        transform: 'scale(1)'
      })),
      state('close',   style({        
        transform: 'scale(0.9)'
      })),
      //transition('close <=> open', animate('100ms linear'))
    ])
  ]

})
export class AccordionPane implements OnDestroy {
  public _isOpen:boolean = false;
		  _currentState = "close";
  
  @Input() heading: string;
  @Input() isExpanded: boolean = false;
  @Input() showText: boolean = false;

  set isOpen(value: boolean) {
    this._isOpen = value;
    if (value) {
      this.accordion.closeOthers(this);
    }
  }
  
  get isOpen() {
    return this._isOpen;
  }
  
  constructor(public accordion: FusionAccordionPane) {    
    this.accordion.addGroup(this);
  }

  ngOnInit(){
    this.isOpen = this.isExpanded;
    this._currentState = this.isOpen? 'open' : 'close';
  }
  
  toggleOpen(event: MouseEvent): void {
    event.preventDefault();
    this.isOpen = !this.isOpen;
	  this._currentState = this.isOpen? 'open' : 'close';
  }
  ngOnDestroy() {
    this.accordion.removeGroup(this);
  }
}


 