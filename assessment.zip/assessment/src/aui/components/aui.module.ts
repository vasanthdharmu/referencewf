import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { FusionSearch} from './searchbar/fusion-searchbar.component';
import { FillPipe } from './pagebreadcrumb/pagebreadcrumb.pipe';
import { SearchPipe } from './searchbar/searchbar.pipe';
import { Pagebreadcrumb } from './pagebreadcrumb/pagebreadcrumb.component';
import { FusionCheckBox } from './checkbox/fusion-checkbox.component';
import { FusionButton } from './button/fusion-button.component';
import { FusionTextBox } from './textbox/fusion-textbox.component';
import { FusionRadio } from './radio/fusion-radio.component';
import { FusionSwitch } from './switch/fusion-switch.component';
import { FusionPanel } from './panel/fusion-panel.component';
import { FusionPopover } from './popover/fusion-popover.component';
import { FusionTextArea } from './textarea/fusion-textarea.component';
import { FusionSelectBox } from './selectbox/fusion-selectbox.component';
import { FusionValidationBox } from './validationbox/fusion-validationbox.component';
import { FusionAboutBox } from './aboutbox/fusion-about.component';
import { FusionTab } from './tab/fusion-tab.component';
import { TabComponent } from './tab/tab';

import { FusionMiniTab } from './mini-tab/fusion-mini-tab.component';
import { MiniTabComponent } from './mini-tab/mini-tab';

import { FusionToaster } from './notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from './notification-toaster/toasteranchor.directive';
import { FusionAlert } from './notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from './notification-alert/alertanchor.directive';

import { FusionDialog } from './dialog/fusion-dialog.component';
import { FusionTooltip } from './tooltip/fusion-tooltip.component';
import { FusionTitlePane } from './titlepane/titlepane.component';
import { AccordionPane } from './accordion/fusion-accordion.component';
import { FusionAccordionPane } from './accordion/fusion-accordion.component';
import { FusionProgressBar } from './progressbar/fusion-progressbar.component';

//import { AngularDualListBoxModule } from './drag-drop-listbox/index';

import { DualListComponent } from './drag-drop-listbox/dual-list.component';

import { CuiTableComponent } from './cui-table/cui-table.component';
import { CuiSpinnerComponent } from './cui-spinner/cui-spinner.component';
import { CuiPagerComponent } from './cui-pager/cui-pager.component';
import { CuiSelectComponent } from './cui-select/cui-select.component';
import { CuiAlertComponent } from './cui-alert/cui-alert.component';
import { CuiInputComponent } from './cui-input/cui-input.component';
import { CuiProgressbarComponent } from './cui-progressbar/cui-progressbar.component';
import { CuiToastComponent } from './cui-toast/cui-toast.component';

import { NgxJsonViewerComponent } from './ngx-json-viewer/ngx-json-viewer.component';

@NgModule({
  imports:      [ 
					CommonModule,
					FormsModule, 
					ReactiveFormsModule
					//AngularDualListBoxModule					
					//AgGridModule.withComponents()
				],  
  declarations: [ 
					FusionSearch,
					FillPipe,
					SearchPipe,
					Pagebreadcrumb,
					FusionCheckBox,
					FusionButton,
					FusionTextBox,
					FusionRadio,
					FusionSwitch,
					FusionPanel,
					FusionPopover,
					FusionTextArea,
					FusionSelectBox,
					FusionValidationBox,
					FusionAboutBox,
					FusionTab,
					TabComponent,
					FusionToaster,
					ToasterAnchorDirective,
					FusionAlert,
					AlertAnchorDirective,
					FusionDialog,
					FusionTooltip,
					FusionTitlePane,
					AccordionPane,
					FusionAccordionPane,
					FusionProgressBar,
					DualListComponent,
					CuiTableComponent,
					CuiSpinnerComponent,
					CuiPagerComponent,
					CuiSelectComponent,
					CuiAlertComponent,
					CuiInputComponent,
					CuiProgressbarComponent,
					CuiToastComponent,
					NgxJsonViewerComponent,
					FusionMiniTab,
					MiniTabComponent
				],
  exports:      [   
					FusionSearch,
					FillPipe,
					SearchPipe,
					Pagebreadcrumb,
					FusionCheckBox,
					FusionButton,
					FusionTextBox,
					FusionRadio,
					FusionSwitch,
					FusionPanel,
					FusionPopover,
					FusionTextArea,
					FusionSelectBox,
					FusionValidationBox,
					FusionAboutBox,
					FusionTab,
					TabComponent,
					FusionToaster,
					ToasterAnchorDirective,
					FusionAlert,
					AlertAnchorDirective,
					FusionDialog,
					FusionTooltip,
					FusionTitlePane,
					AccordionPane,
					FusionAccordionPane,
					FusionProgressBar,
					DualListComponent,
					CuiTableComponent,
					CuiSpinnerComponent,
					CuiPagerComponent,
					CuiSelectComponent,
					CuiAlertComponent,
					CuiInputComponent,
					CuiProgressbarComponent,
					CuiToastComponent,
					NgxJsonViewerComponent,
					FusionMiniTab,
					MiniTabComponent
				]
})
export class AuiModule { }