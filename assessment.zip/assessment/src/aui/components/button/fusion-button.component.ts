import {Component,Input,Attribute} from '@angular/core';
@Component({
   selector: 'fusion-button',
   template: `<button [ngClass]="['btn',btnType,btnSize]" [attr.disabled]="isDisabled ? true : null"
				 [id]="btnId" [type]="btnAction"><ng-content></ng-content></button>` 
				 //[disabled]="disabled ? true : null" [disabled]="!parentGroup.valid"
})
export class FusionButton {
	@Input() parentGroup:any = "";
	@Input() btnSize:string = "";
	@Input() btnType:string;
	@Input() btnAction:string;
	@Input() btnId:string;
	@Input() isDisabled:boolean;
    public disabled:boolean;
	ngOnInit() {
		this.btnType = this.btnType.toLowerCase();
	}
	setDisabled(){
		this.disabled =true;
		this.isDisabled =true;
  	}
  	setEnabled(){
		this.disabled =false;
		this.isDisabled =false;
  	}
	constructor(@Attribute("disable") disable:string) {
		
      if(!(disable === null)){
        this.disabled =true;
		this.isDisabled =true;
      }
      else{
        this.disabled = false;
		this.isDisabled =false;
      }
	  
    }
}