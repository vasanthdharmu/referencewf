import {Component, Input, Output, Attribute, EventEmitter} from '@angular/core';
@Component({
   selector: 'fusion-checkbox',
   template: `<div [formGroup]="parentGroup"><label class="checkbox" [attr.disabled]="isDisabled ? true : null">
   <input type="checkbox" [formControl]="options" [name]="inputId" [id]="inputId" [value]="checkBoxValue" (change)="change($event)" />
   <span class="checkbox__input"></span><span class="checkbox__label">{{checkBoxLabel}}</span></label></div>`
})
export class FusionCheckBox {
  @Input() options;
  @Input() parentGroup;
  
  @Input() inputId:string;
  @Input() checkBoxLabel:string;
  @Input() checkBoxValue:string;
  @Input() isDisabled:boolean;
  @Output() checkboxModelChange = new EventEmitter();
  public disabled:boolean;
  public value:string="";
  ngOnInit(){
    this.value = this.checkBoxValue;
  }
  setDisabled(){
      this.disabled =true;
  }
  setEnabled(){
      this.disabled =false;
  }
  change(newValue:any) {
      this.checkboxModelChange.emit(newValue);
  }
  constructor(@Attribute("disable") disable:string) {
      if(!(disable === null)){
        this.disabled =true;
		this.isDisabled =true;
      }
      else{
        this.disabled = false;
		this.isDisabled =false;
      }
    }
}