import {Injectable} from '@angular/core';

@Injectable()
export class maxZindexFinderService {
  getZindex(elem:string){
    var elems = document.getElementsByTagName(elem);
  	var highest:number = 0;
  	for (var i = 0; i < elems.length; i++)
  	{
	    var zindex:any =document.defaultView.getComputedStyle(elems[i],null).getPropertyValue("z-index");
	    if ((zindex > highest) && (zindex != 'auto'))
	    {
	      highest = zindex;
	    }
  	}
  	return highest;
  };
}