import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement }              from '@angular/core';
import { By }                        from '@angular/platform-browser';

import { CuiAlertComponent } from './cui-alert.component';

describe('CuiAlertComponent', () => {
  let component: CuiAlertComponent;
  let fixture: ComponentFixture<CuiAlertComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ CuiAlertComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CuiAlertComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display an icon', () => {
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.icon-info-circle'));
    expect(de).toBeTruthy();
  });

  it('should display a message', () => {
    component.message = 'test';
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.alert__message'));
    el = de.nativeElement;
    expect(el.textContent).toContain('test');
  });

  it('should have a close button', () => {
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.alert__close.icon-close'));
    expect(de).toBeTruthy();

    el = de.nativeElement;
    el.click();

    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.alert'));
    expect(de).toBeNull();
  });

  it('should expose getColorClass function', () => {
    expect(component.getColorClass()).toBeDefined();
  });


  describe('getColorClass test', () => {
    const altOptions = [null, 1, 2];
    const input = ['success', 'warning', 'danger', ''];
    const output = ['alert--success', 'alert--warning', 'alert--danger', 'alert--info'];

    function testGetColorClass(flag, type, altFlag) {
      it('should expose getColorClass function and should return ' + type, () => {
        component.alt = altFlag;
        component.severity = flag;
        let suffix = '';

        switch (altFlag) {
          case null:
            suffix = '';
            break;
          case 1:
            suffix = '-alt';
            break;
          case 2:
            suffix = '-alt2';
            break;
          default:
            suffix = '';
        }
        expect(component.getColorClass()).toEqual(type + suffix);
      });
    };

    for (let i = 0; i < altOptions.length; i++) {
      for (let x = 0; x < input.length; x++) {
        testGetColorClass(input[x], output[x], altOptions[i]);
      }
    }
  });

  it('should expose getColorClass function', () => {
    expect(component.getIconClass()).toBeDefined();
  });
  describe('getIconClass test', () => {
    const input = ['success', 'warning', 'danger', ''];
    const output = ['icon-check', 'icon-exclamation-triangle', 'icon-error', 'icon-info-circle'];

    function testGetIconClass(flag, type) {
      it('should expose getIconClass function and should return ' + type, () => {
        component.severity = flag;
        expect(component.getIconClass()).toEqual(type);
      });
    };

    for (let x = 0; x < input.length; x++) {
      testGetIconClass(input[x], output[x]);
    }
  });


  it('should style alerts', () => {
    component.severity = 'warning';
    component.alt = 1;
    fixture.detectChanges();

    de = fixture.debugElement.query(By.css('.icon-exclamation-triangle'));
    expect(de).toBeTruthy();

    de = fixture.debugElement.query(By.css('.alert--warning-alt'));
    expect(de).toBeTruthy();
  });

  it('should render default values in showAlert function', () => {
    component.severity = 'default severity';
    component.message = 'default msg';
    component.closeButton = false;
    expect(component.showAlert).toBeDefined();

    component.showAlert(undefined, undefined, undefined);
    expect(component.severity).toEqual('default severity');
    expect(component.message).toEqual('default msg');
    expect(component.closeButton).toEqual(false);
  });

  it('should render values passed to showAlert function', () => {
    component.severity = 'default severity';
    component.message = 'default msg';
    component.closeButton = false;
    expect(component.showAlert).toBeDefined();

    component.showAlert('info', 'info msg', true);
    expect(component.severity).toEqual('info');
    expect(component.message).toEqual('info msg');
    expect(component.closeButton).toEqual(true);

  });

});
