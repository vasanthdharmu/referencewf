import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'cui-alert',
  templateUrl: './cui-alert.component.html'
})
/**
 * Component for an alert box
 */
export class CuiAlertComponent {
  /**
   * The severity of the alert (info [default], success, warning, danger)
   */
  @Input() severity: string;
  /**
   * The message to display in the alert
   */
  @Input() message: string;
  /**
   * Whether to display a close button
   */
  @Input() closeButton: boolean = true;
  /**
   * Optional alternate background (1, 2)
   */
  @Input() alt: number = 0;
  /**
   * Whether to show the alert
   */
  @Input() show: boolean = true;

  /**
   * Returns the color class string for the alert
   * @returns The color class string
   */
  public getColorClass() {
    const altClass = this.alt ? this.alt === 1 ? '-alt' : '-alt2' : '';
    switch (this.severity) {
      case 'success':
        return 'alert--success' + altClass;
      case 'warning':
        return 'alert--warning' + altClass;
      case 'danger':
        return 'alert--danger' + altClass;
      default:
        return 'alert--info' + altClass;
    }
  }

  /**
   * Returns the class string for the alert's icon
   * @returns The icon string
   */
  public getIconClass() {
    switch (this.severity) {
      case 'success':
        return 'icon-check';
      case 'warning':
        return 'icon-exclamation-triangle';
      case 'danger':
        return 'icon-error';
      default:
        return 'icon-info-circle';
    }
  }

  /**
   * Hides the alert when the close button is clicked
   */
  public hideAlert() {
    this.show = false;
  }

  /**
   * Shows and optionally modifies the alert
   * @param  severity    A new severity for the alert
   * @param  message     A new message for the alert
   * @param  closeButton Whether to show the close button
   */
  public showAlert(severity: string, message: string, closeButton: boolean) {
    this.severity = severity || this.severity;
    this.message = message || this.message;
    this.closeButton = closeButton || this.closeButton;
    this.show = true;
  }
}
