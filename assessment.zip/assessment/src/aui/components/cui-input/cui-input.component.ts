import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Guid } from '../cui-utilities/utilities';

/**
 * Component for a form input using CiscoUI
 */
@Component({
  selector: 'cui-input',
  templateUrl: './cui-input.component.html'
})
export class CuiInputComponent {
  /**
   * The value recorded in the input
   */
  @Input() model: any;
  /**
   * The type of input (text, textarea, number, switch, email, password, tel, date, month, week, time)
   */
  @Input() type: string = 'text';
  /**
   * The label to display next to the input
   */
  @Input() label: string;
  /**
   * Whether the input is required (not available for switches)
   */
  @Input() required: boolean;
  /**
   * Optional helper text to display below the input (not available for switches)
   */
  @Input() helperText: string;
  /**
   * Level of the helper text (info, success, warning, danger)
   */
  @Input() helperLevel: string = 'info';

  /**
   * Minimum amount for a number input
   */
  @Input() min: number = 0;
  /**
   * Maximum amount for a number input
   */
  @Input() max: number = 999999;
  /**
   * Step amount for a number input
   */
  @Input() step: number = 1;

  /**
   * Number of rows to display for a textarea
   */
  @Input() rows: number = 1;

  /**
   * Optional left icon class for a switch
   */
  @Input() leftIcon: string;

  /**
   * Optional right icon class for a switch
   */
  @Input() rightIcon: string;

  /**
   * Available choices for a radio input or checkboxes (name, value)
   */
  //@Input() items: Array<Object> = [];
  @Input() items: Array<any>;

  /**
   * Event emitted when the input's value is changed
   */
  @Output() modelChange: EventEmitter<any> = new EventEmitter();

  /**
   * GUID for the input's id attribute
   */
  guid: string = Guid.generate();

  @Input() options;
  @Input() parentGroup;

  @Input() disabled: boolean = false;
  @Input() inputId;

  @Input() tabIndexValue: number = -1;

  /**
   * Internal onChange function for the input
   */
  onChange() {

    if(this.type === 'checkbox' || this.type === 'radio') {

      this.model = this.items.filter(item => {
        return item['selected'];
      }).map(item => {
        return item ['value'];
      });
    }

    this.modelChange.emit(this.model);
  }

  public selectItem(item: any) {

    for(let i of this.items) {
      delete i.selected;
    }

    if(item.selected) {
      delete item.selected;
    }
    else {
      item.selected = true;
    }

  }

}
