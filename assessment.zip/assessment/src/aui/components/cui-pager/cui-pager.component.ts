import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cui-pager',
  templateUrl: './cui-pager.component.html'
})
export class CuiPagerComponent {
  /**
   * The current page index.
   */
  @Input() page: number = 0;
  /**
   * The number of items displayed per page.
   */
  @Input() limit: number;
  /**
   * The total number of items in the collection.
   */
  @Input() totalItems: number;

  /**
   * Event emitted when the page is changed.
   */
  @Output() onPageChanged: EventEmitter<Number> = new EventEmitter();

  gotoPage(page) {
    this.page = page;
    this.onPageChanged.emit(this.page);
  }

  getPageCount(): number {
    return Math.ceil(this.totalItems / this.limit);
  }

  getPageDetails(): string {
    return `${this.page * this.limit + 1}-${Math.min(this.page * this.limit + this.limit, this.totalItems)} of ${this.totalItems}`;
  }
}
