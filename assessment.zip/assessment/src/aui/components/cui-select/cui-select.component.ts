import { Component, Renderer2, Input, Output, EventEmitter, SimpleChanges, OnInit, OnDestroy, OnChanges } from '@angular/core';

import { Guid, Mobile } from '../cui-utilities/utilities';
import * as _ from 'lodash';

@Component({
  selector: 'cui-select',
  templateUrl: './cui-select.component.html'
})
/**
 * Component for combo box selection.
 */
export class CuiSelectComponent implements OnInit, OnDestroy, OnChanges {
  /**
   * The items available for selection.
   */
  @Input() items: Array<any>;
  /**
   * The currently selected item(s).
   */
  @Input() selection: any;

  @Input() selectedvalue: any;

  /**
   * The display name key for Object items.
   */
  @Input() optionsKey: string = 'name';
  /**
   * Optional value key for Object items.
   */
  @Input() optionsValue: string;
  /**
   * Whether the component is disabled.
   */
  @Input() disabled: boolean = false;
  /**
   * Whether the input is required.
   */
  @Input() required: boolean = false;
  /**
   * Optional helper text to display below the input (not available for switches)
   */
  @Input() helperText: string;
  /**
   * Level of the helper text (info, success, warning, danger)
   */
  @Input() helperLevel: string = 'info';
  /**
   * Whether the items are grouped by category.
   */
  @Input() grouped: boolean = false;
  /**
   * Whether multi-item select is available.
   */
  @Input() multiSelect: boolean = false;
  /**
   * Whether a select all checkbox is available.
   */
  @Input() selectAllEnabled: boolean = false;
  /**
   * Optional title text for the component.
   */
  @Input() title: string;
  /**
   * Optional label for the input.
   */
  @Input() label: string;
  /**
   * Tab index of the input.
   */
  @Input() tabIndexValue: number = -1;
  /**
   * Whether an empty selection button is available.
   */
  @Input() empty: boolean = false;
  /**
   * Whether to display the native mobile select element.
   */
  @Input() mobile: boolean = Mobile.isMobile();

  @Input() emitSelection = false;
  /**
   * Event emitted when an item is selected.
   */
  @Output() selectChange: EventEmitter<any> = new EventEmitter();

  @Input() options;
  @Input() parentGroup;

  /**
   * Whether the dropdown element is visible.
   */
  public dropdownVisible: boolean = false;
  /**
   * Available items in the dropdown, set by the search input.
   */
  public filteredItems: Array<Object> = [];

  public guid: string = Guid.generate();
  public mouseInInput: boolean = false;
  public mouseInDropdown: boolean = false;
  public searchText: string = '';
  public globalClick;

  constructor(public renderer: Renderer2) { }

  ngOnInit() {
    if(!this.items) {
      return;
    }

    if(typeof this.items[0] === 'string') {
      let resolvedItems = [];
      for(let item of this.items) {
        resolvedItems.push({
          name: item,
          value: item
        })
      }

      this.items = resolvedItems;
      this.optionsValue = 'value';
    }
    else {
      let multiSelection = [];
      if(this.grouped) {
        for(let group of this.items) {
          for(let item of group.items) {
            if(item.selected) {
              if(this.multiSelect) {
                multiSelection.push(item);
                continue;
              }
              this.selection = item;
              break;
            }
          }
          if(this.selection) {
            break;
          }
        }
      }
      else {
        for(let item of this.items) {
          if(item.selected) {
            if(this.multiSelect) {
              multiSelection.push(item);
              continue;
            }
            this.selection = item;
            break;
          }
        }
      }

      if(this.multiSelect && multiSelection.length) {
        this.selection = multiSelection;
      }
      if(this.selection) {
        this.searchText = this.multiSelect ? this.getMultiSelectDisplayString() : this.selection[this.optionsKey];
      }
    }

    this.filterItems();

    this.globalClick = this.renderer.listen('document', 'click', (event: MouseEvent) => {
      this.toggleDropdown();
    });
  }

  ngOnDestroy() {
    this.globalClick();
  }

  /*
  ngOnChanges(changes: SimpleChanges) {
    if(changes.items) {
      this.filterItems();
    }
    if(changes.multiSelect) {
      this.selection = null;
    }
  }
  */

  ngOnChanges (changes: SimpleChanges) {
    
		if (changes.selectedvalue && changes.selectedvalue.currentValue) {
      if (this.multiSelect){
        this.selection = [];
        for (const item of changes.selectedvalue.currentValue) {
          this.selectItem(item);
        }
        this.searchText = this.getMultiSelectDisplayString();
      }else{
        this.selectItem(changes.selectedvalue.currentValue);
      }
		}
		if (changes.items) {
			this.filterItems();
		}
		if (changes.multiSelect) {
			this.selection = null;
    }
    
	}

  public toggleDropdown() {
    if(!this.dropdownVisible) {
      if(this.mouseInInput) {
        this.dropdownVisible = true;
        if(this.selection) {
          this.searchText = '';
          this.filterItems();
        }
      }
    }
    else if(this.mouseInInput || !this.mouseInDropdown) {
      this.dropdownVisible = false;
      if(!this.dropdownVisible && this.selection) {
        this.searchText = this.multiSelect ? this.getMultiSelectDisplayString() : this.selection[this.optionsKey];
      }
    }
  }

  public getItemDisplayName(item: Object) {
    return item[this.optionsKey];
  }

  public enterDropdown() {
    this.mouseInDropdown = true;
  }

  public leaveDropdown() {
    this.mouseInDropdown = false;
  }

  public enterInput() {
    this.mouseInInput = true;
  }

  public leaveInput() {
    this.mouseInInput = false;
  }

  public getMultiSelectDisplayString() {
    let displayString = '';
    for(let i of this.selection) {
      if(displayString.length) {
        displayString += ', ';
      }
      displayString += i[this.optionsKey];
    }

    return displayString;
  }

  public onKeydown(event: KeyboardEvent) {
    if(event.key === 'Enter' && this.filteredItems.length) {
      this.selectItem(this.filteredItems[0]);
    }
  }

  public onSearchChange(event: Event) {
    this.filterItems();
    this.dropdownVisible = true;
  }

  public clearSearchText(event: Event) {
    event.stopPropagation();
    this.searchText = '';
    this.filterItems();
    this.dropdownVisible = false;
    if(!this.multiSelect) {
      if(this.grouped) {
        for(let g of this.items) {
          for(let i of g.items) {
            delete i.selected;
          }
        }
      }
      else {
        for(let i of this.items) {
          delete i.selected;
        }
      }
      this.selection = null;
      this.selectChange.emit(this.selection);
    }
  }

  public filterItems() {
    this.filteredItems = [];
    this.searchText = _.defaultTo(this.searchText, '');
    
    if(this.grouped) {
      for(let group of this.items) {
        if(!this.searchText.length || (!this.multiSelect && this.selection && this.searchText === this.selection[this.optionsKey])) {
          this.filteredItems.push(group);
          continue;
        }

        for(let item of group.items) {
          if(item[this.optionsKey].toLowerCase().indexOf(this.searchText.toLocaleLowerCase()) > -1) {
            let foundGroup: any = this.filteredItems.find((filteredGroup: any) => {
              return group.name === filteredGroup.name;
            });

            if(foundGroup) {
              foundGroup.items.push(item);
            }
            else {
              this.filteredItems.push({
                name: group.name,
                items: [item]
              });
            }
          }
        }
      }
    }
    else {
      for(let item of this.items) {
        if(!this.searchText.length || (!this.multiSelect && this.selection && this.searchText === this.selection[this.optionsKey])) {
          this.filteredItems.push(item);
          continue;
        }

        if(item[this.optionsKey].toLowerCase().indexOf(this.searchText.toLocaleLowerCase()) > -1) {
          this.filteredItems.push(item);
        }
      }
    }
  }

  /*public selectItem(item: any) {
    if(!this.multiSelect) {
      if(this.grouped) {
        for(let g of this.items) {
          for(let i of g.items) {
            delete i.selected;
          }
        }
      }
      else {
        for(let i of this.items) {
          delete i.selected;
        }
      }
      this.selection = item;
      this.selection.selected = true;
      this.searchText = this.selection[this.optionsKey];
      this.selectChange.emit(this.optionsValue ? this.selection[this.optionsValue] : this.selection);
      this.dropdownVisible = false;
    }
    else {
      if(item.selected) {
        this.selection = this.selection.filter(i => {
          return i !== item;
        });
        delete item.selected;
      }
      else {
        if(!this.selection) {
          this.selection = [];
        }
        this.selection.push(item);
        item.selected = true;
      }
      this.selectChange.emit(this.selection);
    }

    this.filterItems();
  }*/
  private selectItem (item: any) {

		if (!this.multiSelect) {
			if (this.grouped) {
				for (const g of this.items) {
					for (const i of g.items) {
						delete i.selected;
					}
				}
			} else {
				for (const i of this.items) {
					delete i.selected;
				}
      }
      item.selected = true;
			this.selection = item;
			this.selection.selected = true;
			this.searchText = this.selection[this.optionsKey];
      //this.selectChange.emit((this.optionsValue && !this.emitSelection) ?	this.selection[this.optionsValue] : this.selection);
      this.selectChange.emit(this.optionsValue ? this.selection[this.optionsValue] : this.selection);
			this.dropdownVisible = false;
		} else {
			if (item.selected) {
				this.selection = this.selection.filter((i: any) => i !== item);
				delete item.selected;
			} else {
				if (!this.selection) {
					this.selection = [];
        }
        item.selected = true;
				this.selection.push(item);
				item.selected = true;
      }      
			this.selectChange.emit(this.selection);
		}

		this.filterItems();
	}

  public onMobileSelectionChanged() {
    if(!this.multiSelect && this.optionsValue) {
      this.selectChange.emit(this.selection[this.optionsValue]);
    }
    this.selectChange.emit(this.multiSelect ? this.selection : this.selection[0]);
  }

  public allSelected(): boolean {
    if(!this.selection || !Array.isArray(this.selection)) {
      return false;
    }

    if(this.grouped) {
      let totalItems: number = 0;
      for(let group of this.items) {
        totalItems += group.items.length;
      }
      return this.selection.length === totalItems;
    }
    else {
      return this.selection.length === this.items.length;
    }
  }

  public toggleSelectAll() {
    if(!this.allSelected()) {
      this.selection = [];
      if(this.grouped) {
        for(let g of this.items) {
          for(let i of g.items) {
            this.selection.push(i);
            i.selected = true;
          }
        }
      }
      else {
        for(let i of this.items) {
          this.selection.push(i);
          i.selected = true;
        }
      }
    }
    else {
      this.selection = [];
      if(this.grouped) {
        for(let g of this.items) {
          for(let i of g.items) {
            delete i.selected;
          }
        }
      }
      else {
        for(let i of this.items) {
          delete i.selected;
        }
      }
    }
    this.selectChange.emit(this.selection);
  }
}