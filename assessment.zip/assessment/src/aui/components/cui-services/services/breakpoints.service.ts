/**
 * Service for alerting when the bootstrap breakpoint changes
 */
import { Injectable, NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/distinctUntilChanged';


export interface WindowSize {
    width: number;
    height: number;
}

export interface Breakpoint {
    min?: number;
    max?: number;
}

export interface BreakpointEvent {
    name: string;
    breakpoint: Breakpoint;
    size: WindowSize;
}

export interface BreakpointConfig {
    [name: string]: Breakpoint;
}

// Breakpoints come from Bootstrap Grid definitions
// https://v4-alpha.getbootstrap.com/layout/overview/
const defaultBreakpoints: BreakpointConfig = {
    xs: { max: 576 },
    sm: { min: 576, max: 992 },
    md: { min: 768, max: 992 },
    lg: { min: 992, max: 1200 },
    xl: { min: 1200 }
};

const FALLBACK_BREAKPOINT = {
    min: 0, max: Number.MAX_SAFE_INTEGER
};

@Injectable()
/**
 * Monitors the window size and emits the new value when it changes
 */
export class BreakpointsService  {

    public lastBreakpoint: string = null;
    public breakpoints: BreakpointConfig = defaultBreakpoints;
    public changesSubject: BehaviorSubject<BreakpointEvent>;
    public subscription: Subscription;

    changes: Observable<BreakpointEvent>;
    resize: Observable<WindowSize>;

    constructor (public ngZone: NgZone) {

        this.setBreakpoints(this.breakpoints);

        this.resize = Observable.fromEvent(window, 'resize').map(this.getWindowSize).distinctUntilChanged();

        const initialBreakpoint = this.getBreakpoint(window.innerWidth);
        this.changesSubject = new BehaviorSubject<BreakpointEvent>(this.getBreakpointEvent(initialBreakpoint));
        this.changes = this.changesSubject.distinctUntilChanged((x, y) => x.name === y.name);
        this.subscribe();
    }

    // Unsubscribe to the resize event
    public unsubscribe () {

        if (this.subscription) {
            this.subscription.unsubscribe();
            this.subscription = null;
        }
    }

    // Subscribe to the resize event
    public subscribe () {

        if (this.subscription) {
            return;
        }

        // Make sure resize event doesn't trigger change detection by running outside of angular zone
        this.ngZone.runOutsideAngular(() => {

            this.subscription = this.resize.subscribe((size: WindowSize) => {

                const breakpoint: string = this.getBreakpoint(size.width);

                if (breakpoint === this.lastBreakpoint) {
                    return;
                }

                this.lastBreakpoint = breakpoint;

                // Emitting back in angular zone
                this.ngZone.run(() => {
                    this.changesSubject.next(this.getBreakpointEvent(breakpoint));
                });
            });
        });

    }

    // Sets the customized breakpoints
    public setBreakpoints (breakpoints?: BreakpointConfig) {

        if (breakpoints) {
            this.breakpoints = breakpoints;
        }
    }


    // Returns a breakpoint event, with the fallback breakpoint if none were found
    public getBreakpointEvent (name: string): BreakpointEvent {

        if (!name) {
            return { name: 'default', breakpoint: FALLBACK_BREAKPOINT, size: this.getWindowSize() };
        } else {
            return { name: name, breakpoint: this.breakpoints[name], size: this.getWindowSize() };
        }
    }

    // Returns the current window size
    public getWindowSize (): WindowSize {

        return { width: window.innerWidth, height: window.innerHeight };
    }


    // Returns the first breakpoint that match the current size
    public getBreakpoint (currentSize: number): string {

        const keys = Object.keys(this.breakpoints);
        for (const key of keys) {
            const value = this.breakpoints[key];
            const min = value.min || 0;
            const max = value.max || Number.MAX_SAFE_INTEGER;

            if (currentSize >= min && currentSize < max) {
                return key;
            }
        }

        return null;
    }
}
