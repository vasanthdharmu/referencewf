import { Injectable, ReflectiveInjector } from '@angular/core';
import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, RequestOptions } from '@angular/http';
import { HttpModule, Response, ResponseOptions } from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';

import { DynamicPagerService } from './dynamic-pager.service';

let params: Object = {
  platform: 'rdjq4vwe',
  max: 10,
  offset: 0
};
let gameId;

describe('DynamicPagerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [DynamicPagerService]
    });

    this.injector = ReflectiveInjector.resolveAndCreate([
      {provide: ConnectionBackend, useClass: MockBackend},
      {provide: RequestOptions, useClass: BaseRequestOptions},
      Http,
      DynamicPagerService,
    ]);
    this.service = this.injector.get(DynamicPagerService);
    this.backend = this.injector.get(ConnectionBackend) as MockBackend;
    this.backend.connections.subscribe((connection: any) => this.lastConnection = connection);
  });

  it('should ...', () => {
    expect(this.service).toBeTruthy();
  });

  it('should retrieve list data', fakeAsync(() => {
    let items = [];
    this.service.setServiceUrl('/items');
    this.service.getMultiple(params).then(result => {
      items = result;
    });
    this.lastConnection.mockRespond(new Response(new ResponseOptions({
      body: JSON.stringify([{id: '12345'}]),
    })));
    tick();
    expect(items[0].id).toEqual('12345');
  }));

  it('should retrieve single object data', fakeAsync(() => {
    let item;
    this.service.setServiceUrl('/items');
    this.service.get('12345').then(result => {
      item = result;
    });
    this.lastConnection.mockRespond(new Response(new ResponseOptions({
      body: JSON.stringify({id: '12345'}),
    })));
    tick();
    expect(item.id).toEqual('12345');
  }));

  it('should create objects', fakeAsync(() => {
    let response;
    this.service.setServiceUrl('/items');
    this.service.create({id: '12345'}).then(result => {
      response = result;
    });
    this.lastConnection.mockRespond(new Response(new ResponseOptions({
      body: JSON.stringify({success: true}),
    })));
    tick();
    expect(response.success).toEqual(true);
  }));

  it('should update objects', fakeAsync(() => {
    let response;
    this.service.setServiceUrl('/items');
    this.service.update('12345', {id: '12345'}).then(result => {
      response = result;
    });
    this.lastConnection.mockRespond(new Response(new ResponseOptions({
      body: JSON.stringify({success: true}),
    })));
    tick();
    expect(response.success).toEqual(true);
  }));

  it('should create objects', fakeAsync(() => {
    let response;
    this.service.setServiceUrl('/items');
    this.service.delete('12345').then(result => {
      response = result;
    });
    this.lastConnection.mockRespond(new Response(new ResponseOptions({
      body: JSON.stringify({success: true}),
    })));
    tick();
    expect(response.success).toEqual(true);
  }));
});
