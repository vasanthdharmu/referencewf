import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class DynamicPagerService {
  constructor(public http: Http) { }

  public serviceUrl: string = '';

  /**
   * Sets the base url of the service to call
   */
  public setServiceUrl(url: string) {
    this.serviceUrl = url;
  };

  /**
   * Retrieves a single object from the service
   * @param  {string}          [id]     The UID of the element to retrieve
   * @param  {Object}          [params] Parameters to add to the URL
   * @return {Promise<Object>}          The object retrieved from the service
   */
  public get(id: string = '', params: Object = {}): Promise<Object> {
    let url = `${this.serviceUrl}/${id}${this.buildParamsString(params)}`;
    return this.http.get(url)
               .toPromise()
               .then(response => response.json() as Object)
               .catch(Promise.reject);
  }

  /**
   * Retrieves an array of objects from the service
   * @param  {Object}          [params] Parameters to add to the URL
   * @return {Promise<Object>}          The objects retrieved from the service
   */
  public getMultiple(params: Object = {}): Promise<Object[]> {
    let url = `${this.serviceUrl}${this.buildParamsString(params)}`;
    return this.http.get(url)
               .toPromise()
               .then(response => response.json() as Object[])
               .catch(Promise.reject);
  }

  /**
   * Creates an object through the service
   * @param  {Object}          data The data of the object
   * @return {Promise<Object>}      The response returned from the service
   */
  public create(data: Object = {}): Promise<Object> {
    let url = `${this.serviceUrl}`;
    return this.http.post(url, data)
               .toPromise()
               .then(response => response.json() as Object)
               .catch(Promise.reject);
  }

  /**
   * Updates an object through the service
   * @param  {string}          [id]   The UID of the element to update
   * @param  {Object}          [data] The data of the object
   * @return {Promise<Object>}        The response returned from the service
   */
  public update(id: string = '', data: Object = {}): Promise<Object> {
    let url = `${this.serviceUrl}/${id}`;
    return this.http.put(url, data)
               .toPromise()
               .then(response => response.json() as Object)
               .catch(Promise.reject);
  }

  /**
   * Deletes a single object from the service
   * @param  {string}          [id]     The UID of the element to delete
   * @param  {Object}          [params] Parameters to add to the URL
   * @return {Promise<Object>}          The object retrieved from the service
   */
  public delete(id: string = '', params: Object = {}): Promise<Object> {
    let url = `${this.serviceUrl}/${id}${this.buildParamsString(params)}`;
    return this.http.delete(url)
               .toPromise()
               .then(response => response.json() as Object)
               .catch(Promise.reject);
  }

  public buildParamsString(params: Object): string {
    let paramsString = ``;
    for(let key in params) {
      paramsString += `${(paramsString.length ? '&' : '?')}${key}=${params[key]}`;
    }

    return paramsString;
  }
}
