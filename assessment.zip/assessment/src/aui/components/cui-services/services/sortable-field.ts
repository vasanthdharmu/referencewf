export interface SortableField {
    sortable: boolean;
    sorting: boolean;
    sortKey: string;
    sortDirection: string;
    render: Function;
}