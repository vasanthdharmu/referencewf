import { Injectable } from '@angular/core';
import { SortableField } from './sortable-field';

@Injectable()
/**
 * Service for the sorting and paging of a static data set
 */
export class StaticPagerService {
  /**
   * Returns a single page's objects
   * @param  {Array<Object>} data   The data to page
   * @param  {number}        offset The page index
   * @param  {number}        limit  The number of items per page
   * @return {Array<Object>}        The paged data
   */
  public getPagedData(data: Array<Object>, offset: number, limit: number): Array<Object> {
    if(!limit) {
      return data;
    }

    let displayedData = [...data];
    return displayedData.splice(offset * limit, limit);
  }

  /**
   * Sorts a data set by a field
   * @param  {SortableField}        sortField    The field to sort by
   * @param  {Array<SortableField>} allFields    All sortable fields
   * @param  {Array<Object>}        data         The data to sort
   * @return {Array<Object>}                     The sorted data
   */
  public sort(sortField: SortableField, allFields: Array<SortableField>, data: Array<Object>) {
    if(!sortField.sortable) {
      return;
    }

    let sortDirection = sortField.sortDirection === 'asc' ? 'desc' : 'asc';
    for(let column of allFields) {
      column.sorting = false;
      column.sortDirection = 'desc';
    }
    sortField.sorting = true;
    sortField.sortDirection = sortDirection;

    let sortedData = [...data];
    return this.sortDataByField(sortField, sortedData);
  }

  public sortDataByField(sortField: SortableField, data: Array<Object>) {
    return data.sort((a, b) => {
      if(sortField.sortDirection === 'asc') {
        if(sortField.sortKey) {
          let valA = typeof a[sortField.sortKey] !== 'boolean' ? a[sortField.sortKey] : a[sortField.sortKey] ? 0 : 1;
          let valB = typeof b[sortField.sortKey] !== 'boolean' ? b[sortField.sortKey] : b[sortField.sortKey] ? 0 : 1;

          return valA > valB ? 1 : valA < valB ? -1 : 0;
        }

        return sortField.render(a) > sortField.render(b) ? 1 : sortField.render(a) < sortField.render(b) ? -1 : 0;
      }

      if(sortField.sortKey) {
        let valA = typeof a[sortField.sortKey] !== 'boolean' ? a[sortField.sortKey] : a[sortField.sortKey] ? 0 : 1;
        let valB = typeof b[sortField.sortKey] !== 'boolean' ? b[sortField.sortKey] : b[sortField.sortKey] ? 0 : 1;

        return valA < valB ? 1 : valA > valB ? -1 : 0;
      }

      return sortField.render(a) < sortField.render(b) ? 1 : sortField.render(a) > sortField.render(b) ? -1 : 0;
    });
  }
}
