import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

import { CuiSpinnerComponent } from './cui-spinner.component';

describe('CuiSpinnerComponent', () => {
  let component: CuiSpinnerComponent;
  let fixture: ComponentFixture<CuiSpinnerComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ CuiSpinnerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CuiSpinnerComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render text in a h4 tag', () => {
    component.label = 'Loading';
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('h4'));
    el = de.nativeElement;
    expect(el.textContent).toContain('Loading');
  });

  it('should have loading dots', () => {
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.loading-dots'));
    el = de.nativeElement;
    expect(el.textContent).toBeTruthy();
  });

  it('should color loading dots', () => {
    component.color = 'info';
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.loading-dots--info'));
    el = de.nativeElement;
    expect(el.textContent).toBeTruthy();
  });

  it('should return "" if color is white', () => {
    component.color = 'white';
    fixture.detectChanges();
    expect(component.getColorClass()).toBe('');
  });
});
