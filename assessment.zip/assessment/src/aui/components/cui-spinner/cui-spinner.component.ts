import { Component, Input } from '@angular/core';

@Component({
  selector: 'cui-spinner',
  templateUrl: './cui-spinner.component.html'
})
/**
 * Component for a loader element
 */
export class CuiSpinnerComponent {
  /**
   * Optional text to display with the loader
   */
  @Input() label: string;
  /**
   * Optional loading dots color (muted [default], white, info, primary, warning)
   */
  @Input() color: string = 'muted';

  /**
   * Returns the loading dots color class string
   * @returns The color class string
   */
  public getColorClass() {
    if(this.color == 'white') {
      return '';
    }

    return `loading-dots--${this.color}`;
  }
}
