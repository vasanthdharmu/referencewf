import { CuiTableColumnOption } from './cui-table-column-option';

/**
 * Options object for the CuiTableComponent
 */
export class CuiTableOptions {
  /**
   * Array of individual column option objects
   */
  public columns: Array<CuiTableColumnOption>;
  /**
   * Whether the table is bordered
   */
  public bordered: boolean = false;
  /**
   * Whether the table has a striped background
   */
  public striped: boolean = true;
  /**
   * Whether the table highlights on hover
   */
  public hover: boolean = false;
  /**
   * Whether the table cells wrap text
   */
  public wrapText: boolean = false;
  /**
   * Table padding/size (compressed, regular, loose)
   */
  public padding: string = 'regular';
  /**
   * Whether items in the table are selectable by a checkbox
   */
  public selectable: boolean = false;
  /**
   * Whether items in the table loaded from a service
   */
  public dynamicData: boolean = true;

  constructor(options) {
    for(let key in options) {
      if(key === 'columns') {
        this.createColumns(options.columns || []);
        continue;
      }

      this[key] = options[key];
    }
  }

  public createColumns(columns: Array<Object>) {
    let columnOptions: Array<CuiTableColumnOption> = [];
    for(let column of columns) {
      columnOptions.push(new CuiTableColumnOption(column));
    }

    this.columns = columnOptions;
  }
}
