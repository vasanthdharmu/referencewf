import { Component, Input } from '@angular/core';

import { CuiToastOptions } from './cui-toast-options';

@Component({
  selector: 'cui-toast',
  templateUrl: './cui-toast.component.html',
  styleUrls: ['./cui-toast.component.css']
})
/**
 * Component for toast popups
 */
export class CuiToastComponent {
  toasts: Array<CuiToastOptions> = [];

  /**
   * Adds a toast to the screen
   * @param severity The severity of the toast
   * @param title    The title to display
   * @param message  The message to display
   * @param padding  The padding of the toast
   */
  public addToast(severity: string, title: string, message: string, padding: string = 'regular'): CuiToastOptions {
    let toast: CuiToastOptions = new CuiToastOptions(severity, title, message, padding);
    this.toasts.push(toast);

    return toast;
  }

  /**
   * Removes a toast from the screen
   * @param toastToRemove The toast to remove
   */
  public removeToast(toastToRemove: CuiToastOptions) {
    let toast = this.toasts.find((toastOptions) => {
      return toastOptions.guid === toastToRemove.guid;
    });

    if(toast) {
      toast.hide();
      setTimeout(() => {
        this.toasts.splice(this.toasts.indexOf(toast), 1);
      }, 500);
    }
  }
}
