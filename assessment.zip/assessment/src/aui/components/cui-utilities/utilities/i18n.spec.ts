import { TestBed, inject } from '@angular/core/testing';

import { i18n } from './i18n';

describe('i18n Utility', () => {
    let dictionary = [
        { key: '_TESTBasic_', value: 'Basic' },
        { key: '_TESTReplaceSingle_', value: 'Replace single {0}' },
        { key: '_TESTReplaceMultiple_', value: 'Replace multiple {0} - {1}' }
    ];

    it('should return empty strings for nonexistent keys', () => {
        i18n.injectDictionary(dictionary);
        expect(i18n.get('_YabbaDabbaDoo_')).toEqual('');
    });

    it('should inject new dictionary items', () => {
        i18n.injectDictionary(dictionary);
        expect(i18n.get('_TESTBasic_')).toEqual('Basic');
        expect(i18n.get('_TESTReplaceSingle_', 'test')).toEqual('Replace single test');
        expect(i18n.get('_TESTReplaceSingle_', 0)).toEqual('Replace single 0');
        expect(i18n.get('_TESTReplaceSingle_', {name: 'test'})).toEqual('Replace single {"name":"test"}');
        expect(i18n.get('_TESTReplaceMultiple_', [3, 5])).toEqual('Replace multiple 3 - 5');
    });

    it('should rebuild the dictionary', () => {
        i18n.buildDictionary('es-ES', dictionary);
        i18n.injectDictionary(dictionary);
        expect(i18n.get('_TESTBasic_')).toEqual('Basic');
        expect(i18n.get('_TESTReplaceSingle_', 'test')).toEqual('Replace single test');
        expect(i18n.get('_TESTReplaceSingle_', 0)).toEqual('Replace single 0');
        expect(i18n.get('_TESTReplaceSingle_', {name: 'test'})).toEqual('Replace single {"name":"test"}');
        expect(i18n.get('_TESTReplaceMultiple_', [3, 5])).toEqual('Replace multiple 3 - 5');
    });
});
