import {Component, Input,Output,EventEmitter} from '@angular/core';
import {FusionButton} from '../button/fusion-button.component';
import {maxZindexFinderService} from '../common/maxZindexFinder.service'; 

@Component({
   selector: 'fusion-dialog',
   styleUrls:  ['./dialog.style.css'],  
   providers:[maxZindexFinderService],
   templateUrl: './dialog.template.html'
})
export class FusionDialog {
  @Input() title: string;
  @Input() showModal: boolean = false;
  @Input() btnlabel: string;
  @Input() button:boolean;
  @Input() resize:boolean;
  @Input() width: string;
  @Input() height: string;
  public startX:number;
  public startY:number;
  public startWidth:number;
  public startHeight:number;
  public dialogBox:any;

  constructor(public _maxZindex: maxZindexFinderService) {}

  //public showModal: boolean = false;
  maxZindex:any
  @Output() onSuccess = new EventEmitter();
  @Output() onClose = new EventEmitter();

  ngOnInit() {
      this.maxZindex = this._maxZindex.getZindex('div');
      //this.width  = this.width+"px";
      //this.height = this.height+"px";
  }
  positiveAction() {
    this.onSuccess.emit(null);
    this.showModal = false;
  }
  cancelAction() {
    this.onClose.emit(null);
    this.showModal = false;
  }
  showDialog(){
    this.showModal = true;
  }
  
  initDrag(event){
    this.dialogBox = document.querySelector('.dialogbox');
    this.startX = event.clientX;
    this.startY = event.clientY;
    this.startWidth = parseInt(document.defaultView.getComputedStyle(this.dialogBox).width, 10);
    this.startHeight = parseInt(document.defaultView.getComputedStyle(this.dialogBox).height, 10);
    document.documentElement.addEventListener('mousemove', clicked, false);
    var that = this;
    
    document.documentElement.addEventListener('mouseup', function(event){
      document.documentElement.removeEventListener('mousemove', clicked, false);
    });

    function clicked(event){
       that.dialogBox.style.width = (that.startWidth + event.clientX - that.startX) + 'px';
       that.dialogBox.style.height = (that.startHeight + event.clientY - that.startY) + 'px';
     }
  }
}