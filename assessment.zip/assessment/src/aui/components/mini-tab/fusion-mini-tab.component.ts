import {Component, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';

@Component({
   selector: 'fusion-mini-tab',
   styleUrls:  [ './mini-tab.style.css' ],
   templateUrl: './mini-tab.template.html',
   encapsulation: ViewEncapsulation.None
})
export class FusionMiniTab {
  @Input() orientation:string;
  public tabs = [];
  public verticalTab:boolean = false;
  @Output() selected = new EventEmitter();

  ngOnInit(){
    if(this.orientation){
        this.verticalTab = true;
    }
    else{
        this.verticalTab = false;
    }
  }
  
  addTab(tab) {
    if (!this.tabs.length) {
      tab.selected = true;
    }
    this.tabs.push(tab);
  }
  
  selectTab(tab) {
    this.tabs.map((tab) => {
      tab.selected = false;
    })
    tab.selected = true;
    this.selected.emit({selectedTab: tab});    
  }
}
