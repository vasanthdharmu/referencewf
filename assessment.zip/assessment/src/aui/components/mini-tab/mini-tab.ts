import { Component, Input} from '@angular/core';
import { FusionMiniTab } from './fusion-mini-tab.component';

@Component({
  selector: 'mini-tabs',
  template: `<div [hidden]="!selected" class="mini-tabs-content">
                 <ng-content></ng-content>
            </div>`
})
export class MiniTabComponent {  
  @Input() tabTitle;
  @Input() tabIcon = "";
  public selected: any;
  constructor(public fusionMiniTab: FusionMiniTab) {}
  
  ngOnInit() {
    this.fusionMiniTab.addTab(this);
  }
}