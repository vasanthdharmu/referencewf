import {Directive, ComponentFactoryResolver, ComponentFactory, ComponentRef, ViewContainerRef, Output, EventEmitter} from '@angular/core';

@Directive({ 
  selector: '[alertAnchor]'
})
export class AlertAnchorDirective {
  public alertQueue = [];
  @Output() onButtonClick = new EventEmitter();
   constructor(
        public viewContainer: ViewContainerRef,
        public componentFactoryResolver: ComponentFactoryResolver
    ) {}

    createAlert(alertComponent, alertType,alertTitle,alertMessage,container, buttons) {
        if(container.childNodes.length === 1){
          let toasterComponentFactory = 
            this.componentFactoryResolver.resolveComponentFactory(alertComponent);  
          let toasterComponentRef = this.viewContainer.createComponent(toasterComponentFactory);
          container.appendChild(this.viewContainer.element.nativeElement);        
          toasterComponentRef.instance['onOpen'](alertType,alertTitle,alertMessage, buttons);
          toasterComponentRef.instance['close'].subscribe((event) => {
              this.onButtonClick.emit(event);
              toasterComponentRef.destroy();
              this.destroyAlert();
           });
          return toasterComponentRef;
        }
        else {
          var alertObjects = {};
          alertObjects['alertComponent'] = alertComponent;
          alertObjects['alertType'] = alertType;
          alertObjects['alertTitle'] = alertTitle;
          alertObjects['alertMessage'] = alertMessage;
          alertObjects['container'] = container;
          alertObjects['buttons'] = buttons;
          this.alertQueue.push(alertObjects);
        }
    }
    destroyAlert(){
        this.viewContainer.clear();
        var currentAlertParam = this.alertQueue[0];
        if(currentAlertParam){
          this.createAlert(currentAlertParam.alertComponent, currentAlertParam.alertType, currentAlertParam.alertTitle, currentAlertParam.alertMessage, currentAlertParam.container, currentAlertParam.buttons);
          this.alertQueue.shift();
        }
    }

}