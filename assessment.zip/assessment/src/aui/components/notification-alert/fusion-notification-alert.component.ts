import {Component,Input,trigger,state,style,transition,animate,EventEmitter,ViewContainerRef} from '@angular/core';
import {maxZindexFinderService} from '../common/maxZindexFinder.service'; 

@Component({
   selector: 'fusion-alert',
   styleUrls:  ['./alert.style.css'],
   providers:[maxZindexFinderService],
   templateUrl: './alert.template.html',
    //add animations
    animations: [
        trigger('shrinkOut', [
          state('in', style({height: '*'})),
          transition('* => void', [
            style({height: '*'}),
            animate(250, style({height: 0}))
          ])
        ])
      ]
})
export class FusionAlert {
    @Input() alertType:string;
    @Input() alertTitle:string;
    @Input() alertMessage:string;
    public alertIcon:string;
    public alertView:string; 
    public maxZindex:number;
    public showModal: boolean = false;
    public buttons =  [];

    close = new EventEmitter();

    clear(event) {
        this.showModal = false;
        this.close.emit(event);
    }  

    constructor(public _maxZindex: maxZindexFinderService) {}  

    onOpen(alertType,alertTitle,alertMessage, buttons){
        this.alertType = alertType;
        this.alertTitle = alertTitle;
        this.alertMessage = alertMessage;
        this.showModal = true;
        this.buttons = buttons;
    }

    ngOnInit() {
      this.maxZindex = this._maxZindex.getZindex('div');
      switch(this.alertType){
        case "info":
              this.alertIcon = "icon-info-circle";
              this.alertView = "alert--info-alt";
              break;
        case "error":
              this.alertIcon = "icon-error";
              this.alertView = "alert--danger-alt";
              break;
        case "warning":
              this.alertIcon = "icon-exclamation-triangle";
              this.alertView = "alert--warning-alt";
              break;
        case "success":
              this.alertIcon = "icon-check";
              this.alertView = "alert--success-alt";
              break;
        default:
              this.alertIcon = "icon-info-circle";
              this.alertView="alert--info-alt";
              break;
      }
  }
}