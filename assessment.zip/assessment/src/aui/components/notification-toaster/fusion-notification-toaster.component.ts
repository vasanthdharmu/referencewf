import {Component,Input,trigger,state,style,transition,animate,EventEmitter} from '@angular/core';

@Component({
   selector: 'fusion-toaster',
   styleUrls:  [ './toaster.style.css' ],
   template: `<div [@flyInOut]="showToaster" *ngIf="showToaster" class="toast-top-right">
			        <div class="toast">
			            <div class="toast__icon" [ngClass]="[toasterIcon]"></div>
			            <div class="toast__body">
			                <div class="toast__title">{{toasterTitle}}</div>
			                <div class = "toast__message" [innerHTML]="toasterMessage"></div>
			                <div class="toaster-close alert__close icon-close" (click)="clear()"></div>
			            </div>
			        </div>
			      </div>`,
      //add animations
      animations: [
          trigger('flyInOut', [
            state('in', style({height: '*'})),
            transition('* => void', [
              style({height: '*'}),
              animate(100, style({height: 0}))
            ])
          ])
        ]
})
export class FusionToaster {
    public toasterType:string;
    public toasterTitle:string;
    public toasterMessage:string;
    public toasterIcon:string;
    public showToaster:boolean;

    close = new EventEmitter();

    clear() {
        this.showToaster = false;
        setTimeout(()=>{this.close.emit('event')},500);
    }  
    onOpen(toasterType,toasterTitle,toasterMessage,toasterTimedelay){
        this.toasterType = toasterType;
        this.toasterTitle = toasterTitle;
        this.toasterMessage = toasterMessage;
        this.showToaster = true;
        if(toasterTimedelay == ""){
          toasterTimedelay = 4000;
        }
       setTimeout(()=>{this.clear()},toasterTimedelay)
    }

    constructor() {}  
    ngOnInit() {
      switch(this.toasterType){
        case "info":
              this.toasterIcon = "text-info icon-info-circle";
              break;
        case "error":
              this.toasterIcon = "text-danger icon-error";
              break;
        case "warning":
              this.toasterIcon = "text-warning icon-warning";
              break;
        case "success":
              this.toasterIcon = "text-success icon-check";
              break;
        default:
              this.toasterIcon = "text-info icon-info-circle";
              break;
      }
  }
}