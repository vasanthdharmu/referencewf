import {Directive, ComponentFactoryResolver, ComponentFactory, ComponentRef,ViewContainerRef} from '@angular/core';

@Directive({ 
  selector: '[toasterAnchor]'
})
export class ToasterAnchorDirective {
    constructor(
        public viewContainer: ViewContainerRef,
        public componentFactoryResolver: ComponentFactoryResolver
    ) {}

    createToaster(toasterComponent,toasterType,toasterTitle,toasterMessage,container,toasterdelay) {
        let toasterComponentFactory = this.componentFactoryResolver.resolveComponentFactory(toasterComponent);        
        let toasterComponentRef = this.viewContainer.createComponent(toasterComponentFactory); 
        container.style.position="absolute";
        container.style.bottom="5px";
        container.style.right="0px";
        container.appendChild(this.viewContainer.element.nativeElement);
        toasterComponentRef.instance['onOpen'](toasterType,toasterTitle,toasterMessage,toasterdelay);
        toasterComponentRef.instance['close'].subscribe(() => {
            toasterComponentRef.destroy();
         });
        return toasterComponentRef;
    }
    destroyToaster(){
        this.viewContainer.clear();
    }

}