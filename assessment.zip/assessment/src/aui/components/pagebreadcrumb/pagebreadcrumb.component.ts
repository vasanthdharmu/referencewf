import { Component,Input,Pipe,PipeTransform } from '@angular/core';

@Component({
  selector: 'pagebreadcrumb',
  styleUrls: [ './pagebreadcrumb.style.css' ],
  templateUrl: './pagebreadcrumb.template.html'
  
})
export class Pagebreadcrumb {
  @Input() breadcurmbItem;
  @Input() ellipseCount:number=3;
  @Input() isEllipse:boolean=false;
  
  constructor() {
       if(!this.breadcurmbItem){
              this.breadcurmbItem = [
                        {"label":"Page1","href":""},
                        {"label":"Page2","href":""},
                        {"label":"Page3"}
              ];
        }
  }
  addItem(item:any){
        this.breadcurmbItem.push(item);
  }
  removeLastItem(){
        this.breadcurmbItem.pop();
  }

  ngOnInit() {
    // this.title.getData().subscribe(data => this.data = data);
  }
}
