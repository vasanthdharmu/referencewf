import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'fill'})

export class FillPipe implements PipeTransform {
  transform(value,v2):any {
    if(Array.isArray(value)){
        return value.filter(function(a,b,c){
                                return b<v2;
                                }).map(function (val){
                                        return val.label;
                                          }).join('/');
    }
    return (new Array(value)).fill(value);
  }
}