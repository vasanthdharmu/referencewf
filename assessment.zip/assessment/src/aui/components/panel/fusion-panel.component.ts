import {Component,Input,Attribute,ViewEncapsulation} from '@angular/core';

@Component({
   selector: 'fusion-panel',
   templateUrl: './fusion-panel.template.html',   
   styleUrls: [ './fusion-panel.style.css' ],
   encapsulation: ViewEncapsulation.None,
})
export class FusionPanel {
	@Input() bootStrapClass:string
	@Input() panelType:string=""
	@Input() panelAlign:string=""
  @Input() ellipseCount:number=3
  @Input() isEllipse:boolean=true
  @Input() isPageBreadCrumbRequired:boolean=false
  @Input() breadcurmbItem :any=[{"label":"Page1"},
  {"label":"Page2"},
  {"label":"Page3"}]
  constructor() {

  }
	setClasses(){
		let classes=[

			this.panelType
		]
		if(this.panelAlign){
			classes.push(this.panelAlign);
		}
		return classes
	}
}
