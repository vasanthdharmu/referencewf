/**
    POPOVER COMPONENT 
**/
import {Component, ElementRef , Renderer, Input, OnInit } from '@angular/core';

@Component({
   selector: 'fusion-popover',
   templateUrl: './popover.template.html',
   styleUrls: [ './popover.style.css' ]
})

export class FusionPopover{
	showTail = true;
	showPopover = false;
	pinned = false;
	@Input() props;
	title : string;
	id : string;
	leftHook : string;
	topHook : string;
	anchorNodes : string;
	cursorMove = "default";

	constructor(public elementRef: ElementRef, public renderer: Renderer) {
    }

    ngOnInit() {
    	this.title = this.props.title;
    	this.id = this.props.id;
    }

    closePopover() {
    	this.showPopover = false;
    	this.pinned = false;
    	this.showTail = true;
		this.cursorMove = "default";
    }

    pinPopover() {
    	this.pinned = true;
    	this.showTail = false;
    	this.cursorMove = "move";
    }

    addHook(ele) {
    	if((this.showPopover) && (this.anchorNodes == ele.currentTarget)) {
    		this.showPopover = false;
    		return;
    	}
	    this.anchorNodes = ele.currentTarget;	
	    this.leftHook = ele.x - ele.offsetX + (ele.currentTarget.clientWidth | ele.target.clientWidth)  + 20 + "px";
	    this.topHook = ele.y - ele.offsetY + (ele.currentTarget.clientHeight/2 | ele.target.clientHeight/2) - 32 + "px"; 
	    this.pinned = false;
	    this.showTail = true;
	    this.showPopover = true;
    }
	
	dragStart(evt) {
        let _self = this;
        let selected = this.elementRef.nativeElement.querySelector(".popover-container"); 
        let x_pos = evt.pageX; 
        let y_pos = evt.pageY;
        let x_elem = x_pos - selected.offsetLeft;
        let y_elem = y_pos - selected.offsetTop;

        document.addEventListener('mousemove', _movePopover, true);
        document.addEventListener('mouseup', _destroyEvent, false);

        function _movePopover(e) {
            x_pos = e.pageX;
            y_pos = e.pageY;
            if (selected !== null) {
                _self.leftHook = (x_pos - x_elem) + 'px';
                _self.topHook = (y_pos - y_elem) + 'px';
            }
        }
        function _destroyEvent() {
            selected = null;
        }
    }
}

