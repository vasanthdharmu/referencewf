import {Component, Input} from '@angular/core';

@Component({
    selector: 'fusion-progressbar, [fusion-progressbar]',
    styleUrls:  [ './progressbar.style.css' ],
    template: `<div class="progressbar" [ngClass]="{'progressbar--thin':thin}">
                    <div class="progressbar__bar">
                        <div *ngIf="!thin" class="progressbar__header-msg text-color">
                                <b>{{percent + '%'}}</b>
                        </div>
                        <div [ngClass]="type && 'progressbar--'+type">
                            <div class="progressbar__bar-solid" [ngClass]="{'transition':true,'progressbar__bar-stripped':stripped,'active':animate}"
                              [ngStyle]="{width: percent + '%'}">
                            </div>
                        </div>
                    </div>
                 </div>`
})
export class FusionProgressBar {
    @Input() public animate:boolean;
    @Input() public stripped:boolean;
    @Input() public thin:boolean;
    @Input() public max:number;
    @Input() public type:string;
    @Input() progress:boolean;
    public percent:number = 0;
    public progressCounter:number = 0;
    public progressInterval:any;
    public _value:number;

    @Input() public get value():number {
        return this._value;
    }
    
    public set value(v:number) {
        if (!v && v !== 0) {
            return;
        }
        this._value = v;
        this.recalculatePercentage();
    }

    public recalculatePercentage() {
        this.percent = this.value;
        this.startProgress()
    }
    public startProgress(){
        if(this.progress){
            this.progressInterval = setInterval(() => {this.myTimer()}, 200);
        }
    }
     public myTimer() {
      this.progressCounter++;
      if(this.percent>=99){
        this.progressCounter = 0;
      }
      this.percent = Number(this.value)+Number(this.progressCounter);
    }
    public stopProgress() {
        clearTimeout(this.progressInterval);
    }
}
