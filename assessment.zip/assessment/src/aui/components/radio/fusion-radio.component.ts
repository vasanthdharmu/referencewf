import {Component,Input,Attribute} from '@angular/core';
@Component({
   selector: 'fusion-radio',
   template: `<div [formGroup]="parentGroup" [class]="bootStrapClass" style="float:left"><label class="radio" [attr.disabled]="disabled ? true : null"><input type="radio" [formControl]="options" [name]="radioBtnName" [value]="radioBtnValue"><span class="radio__input"></span><span class="radio__label">{{radioBtnLabel}}</span></label></div>`
})
export class FusionRadio {
  
  @Input() bootStrapClass:string;
  @Input() options;
  @Input() parentGroup;
  
  @Input() radioBtnLabel:string
  @Input() radioBtnName:string
  @Input() radioBtnValue:string
  
  public disabled:boolean
  public value:string=""
  ngOnInit(){
    this.value = this.radioBtnLabel
  }
  setDisabled(){
      this.disabled =true;
  }
  setEnabled(){
      this.disabled =false;
  }
  getSelected(){
      return this.value;
  }
	constructor(@Attribute("disable") disable:string) {
      if(!(disable === null)){
        this.disabled =true
      }
      else{
        this.disabled = false
      }
    }
}