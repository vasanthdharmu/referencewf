import {Component,Input,Attribute,Output, EventEmitter} from '@angular/core';
@Component({
   selector: 'fusion-searchbar',
   template: `<div class="row">
   				<div [class]="bootStrapClass">
   					<form>
   						<div class="form-group">
   							<div class="form-group__text">
   								<input [id]="searchBarId" type="search" [ngModel]="model" (ngModelChange)="change($event)" name="search"/>
   								<label [attr.for]="searchBarId">{{searchBarLabel}}</label>
   								<button type="button" class="link"><span class="icon-search"></span></button>
   							</div>
   						</div>
   					</form>
   				</div>
   			</div>`
})
export class FusionSearch {
    @Input() bootStrapClass:string
    @Input() searchBarId:string
    @Input() searchBarLabel:string
    @Input() model:any;
  	@Output() modelChange = new EventEmitter();
  	
  	change(newValue:string) {
      this.model = newValue;
      this.modelChange.emit(newValue);
    }
}