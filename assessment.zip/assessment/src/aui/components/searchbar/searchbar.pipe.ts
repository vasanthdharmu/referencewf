import { Component,Pipe,PipeTransform} from '@angular/core';

@Pipe({name:'search'})

export class SearchPipe implements PipeTransform{
  transform(value,term){  
	  	if(term){
		    return value.filter((item)=>{
		    					if(Array.isArray(item)){
		    						return item.filter((subItem)=>{
					    								return subItem.toString().includes(term)
		    											});
		    					}
		    					if(item !== null && typeof item === 'object'){		    			
		    						if (item.label.toString().includes(term)) {
  										return true;
  									}
		    					  	if (item.hasChildren) {
    									let filterItems = (item.items.filter((subItem)=>{
    										return subItem.label.includes(term);
    									})).length;
    									return filterItems;
  									}					
		    					}
		    					return item.toString().includes(term);
		    			});
	  	}
	  	else{
	  		return value;
	  	}
  	}
}