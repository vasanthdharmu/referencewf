import {Component,Input} from '@angular/core';
@Component({
   selector: 'fusion-selectbox',
   template: `<div [formGroup]="parentGroup" [class]="bootStrapClass">
   						<div class="form-group">
   						<div class="form-group__text select">
   							<select [name]="inputId" [id]="inputId" [formControl]="options" [attr.disabled]="isDisabled ? true : null">
								<option value="" selected>{{selectBoxOptions[0].name}}</option>
								<ng-container *ngFor="let selectBoxOption of selectBoxOptions | slice:1">
								   <option [value]="selectBoxOption.value">{{selectBoxOption.name}}</option>
								</ng-container>
   							</select>
							<label [attr.for]="inputId">{{selectBoxLabel}}</label>
   						</div>
   						</div>
   			</div>`
})
export class FusionSelectBox {
	
	@Input() options;
    @Input() parentGroup;
	
	@Input() inputId:string;
	@Input() bootStrapClass:string
	@Input() selectBoxOptions:any;
	@Input() selectBoxLabel:string;
	@Input() isDisabled:boolean = false;

  	public selectedItem:string
	
  	ngOnInit(){
		if( (Array.isArray(this.selectBoxOptions) && (!this.selectBoxOptions.length)) || (this.selectBoxOptions == undefined) ){
			this.selectBoxOptions = [{"value": "", "name": "No options available"}];
		}
  	}
	
	onChange(value:string) {
     this.selectedItem = value;
	}
}