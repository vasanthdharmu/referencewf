import {Component,Input,Attribute} from '@angular/core';
@Component({
   selector: 'fusion-switch',
   template: ' <label [class]="switchType" [attr.disabled]="disabled ? true : null"><input type="checkbox" [checked]="on" (change)="on=!(on)" [name]="switchName"><span class="switch__label" *ngIf="labelLeft">{{switchLabelLeft}}</span><span class="switch__input"><span *ngIf="iconEnable" [class]="switchOffIcon"></span><span [class]="switchOnIcon" *ngIf="iconEnable"></span></span><span class="switch__label" *ngIf="labelRight">{{switchLabelRight}}</span></label>'
})
export class FusionSwitch {
    @Input() switchType:string
    @Input() switchName:string
    @Input() switchLabelLeft:string
    @Input() switchLabelRight:string
    @Input() labelRight:string
    @Input() labelLeft:string
    @Input() iconEnable:string
    @Input() switchOffIcon:string
    @Input() switchOnIcon:string
    public on:boolean
    public disabled:boolean
    constructor(@Attribute("on") on:string,@Attribute("disable") disable:string) {
      this.on = !(on === null);
      if(!(disable === null)){
        this.disabled =true
      }
      else{
        this.disabled = false
      }
    }
}