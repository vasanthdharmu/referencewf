import {Component, EventEmitter, Output,Input } from '@angular/core';

@Component({
   selector: 'fusion-tab',
   styleUrls:  [ './tab.style.css' ],
   templateUrl: './tab.template.html'
})
export class FusionTab {
  @Input() orientation:string;
  public tabs = [];
  public verticalTab:boolean = false;
  @Output() selected = new EventEmitter();

  ngOnInit(){
    if(this.orientation){
        this.verticalTab = true;
    }
    else{
        this.verticalTab = false;
    }
  }
  
  addTab(tab) {
    if (!this.tabs.length) {
      tab.selected = true;
    }
    this.tabs.push(tab);
    if(tab.selected){
      this.selectTab(tab);
    }
  }
  
  selectTab(tab) {
    this.tabs.map((tab) => {
      tab.selected = false;
    })
    tab.selected = true;
    this.selected.emit({selectedTab: tab});    
  }
}
