import { Component, Input} from '@angular/core';
import { FusionTab } from './fusion-tab.component';

@Component({
  selector: 'tabs',
  template: `<div [hidden]="!selected">
                 <ng-content></ng-content>
            </div>`
})
export class TabComponent {  
  @Input() tabTitle;
  @Input() tabSelected;
  public selected: any;
  constructor(public fusionTab: FusionTab) {}
  
  ngOnInit() {
    this.selected = this.tabSelected;
    this.fusionTab.addTab(this);
  }
}