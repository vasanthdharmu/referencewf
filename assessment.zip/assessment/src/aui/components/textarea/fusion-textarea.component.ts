import {Component,Input,Attribute} from '@angular/core';

@Component({
   selector: 'fusion-textarea',
   template: `<div [formGroup]="parentGroup" [class]="bootStrapClass">
				<div class="form-group">
					<div class="form-group__text">
						<textarea [id]="textAreaId" [maxlength]="maxLength != '' ? maxLength : ''" [rows]="rowsCount" [attr.disabled]="disabled ? true : null" [formControl]="options" [attr.autofocus]="autofocus ? true : null"></textarea>
						<label [attr.for]="textAreaId">{{textAreaLabel}}</label>
					</div>
				</div>
			</div>`
})
export class FusionTextArea {
  
  @Input() options;
  @Input() parentGroup;
	
  @Input() bootStrapClass:string;
  @Input() textAreaId:string;
  @Input() textAreaLabel:string;
  @Input() rowsCount:string;
  @Input() maxLength:string;

  public disableExpression:string;
  public disabled:boolean;
  public autofocus:boolean;
  constructor(@Attribute("disable") disable:string, @Attribute("autofocus") autofocus:string) {
      if(!(disable === null)){
        this.disabled =true
      }
      else{
        this.disabled = false
      }
     
      if(!(autofocus === null)){
        this.autofocus =true
      }
      else{
        this.autofocus = false
      }
    }
}