import {Component, Input, Attribute} from "@angular/core";

@Component({
  selector: 'fusion-textbox',
  templateUrl: './textBoxes.template.html',
})
export class FusionTextBox {
  @Input() options;
  @Input() parentGroup;
  
  @Input() bootStrapClass:string;
  @Input() inputLabel:string;
  @Input() inputId:string;
  @Input() inputType:string;
  @Input() isDisabled:boolean;
  @Input() maxLength:string;
  
  public disabled:boolean;
  public required:boolean;
  public autofocus:boolean;
  public autocomplete:boolean;
  constructor(@Attribute("require") require:string,@Attribute("disable") disable:string,@Attribute("autofocus") autofocus:string,@Attribute("autocomplete") autocomplete:string) {
      if(!(disable === null)){
        this.disabled =true;
	    	this.isDisabled =true;
      }
      else{
        this.disabled = false;
		    this.isDisabled =false;
      }
      if(!(require === null)){
        this.required =true
      }
      else{
        this.required = false
      }
      if(!(autofocus === null)){
        this.autofocus =true
      }
      else{
        this.autofocus = false
      }
	  if(!(autocomplete === null)){
        this.autocomplete =true
      }
      else{
        this.autocomplete = false
      }
  }
  
}