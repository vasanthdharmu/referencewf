/**
  FUSION TITLEPANE COMPONENT
**/

import {Component, Input, ElementRef, QueryList, AfterContentInit, AfterContentChecked, ContentChildren, AfterViewInit} from '@angular/core';

        @Component({
           selector: 'fusion-titlepane',
           styleUrls:[ './titlepane.css' ],
           templateUrl: './titlepane.template.html'   
        })

        export class FusionTitlePane implements AfterContentInit{
            @Input() title = "";
            @Input() open = "false";

            arrPos = "&#9658";
            isOpen = false;
            titles = [];
            content = [];

            constructor(public el:ElementRef){
             //debugger;
            }          

            ngAfterContentInit() {
              if(this.open ==="true"){
                this.isOpen = true;
                this.arrPos = "&#9660";
              }else{
                this.isOpen = false;
                this.arrPos = "&#9658";
              }
                 
            }
                        
            showHideContent(){
                if(!this.isOpen){
                this.isOpen = true;
                this.arrPos = "&#9660";
              }else{
                this.isOpen = false;
                this.arrPos = "&#9658";
              }
            }
          
         } 


 