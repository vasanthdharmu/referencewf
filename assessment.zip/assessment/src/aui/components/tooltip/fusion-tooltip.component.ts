/**
    FUSION TOOLTIP COMPONENT 

**/
import {Component,Input,Attribute,Output, EventEmitter, HostListener} from '@angular/core';

@Component({
   selector: 'fusion-tooltip',
   templateUrl: './tooltip.template.html',
   styles: [`
        ._box{
            position: absolute;
            background: #2A2A2A;
            opacity: 0.9;
            padding: 1rem;
            font-size: 12px;
            line-height: 16px;
            color: #fff;
            font-family: 'Arial';
            display: inline-block;
            font-style: normal;
            border-radius:3px;
          }
        ._arrow{
            max-width:400px;
            max-height:300px;                
            margin: 3px;
            overflow:auto;
        }
        ._arrowRight{
            border-top: 40px solid transparent;
            border-bottom: 40px solid transparent;  
            border-left: 40px solid #2A2A2A;
        }
        ._arrowLeft{
            border-top: 40px solid transparent;
            border-bottom: 40px solid transparent;  
            border-right: 40px solid #2A2A2A;
        }
        ._arrowTop{
            border-left: 40px solid transparent;
            border-right: 40px solid transparent;  
            border-bottom: 40px solid #2A2A2A;
        }
        ._arrowBottom{
            border-left: 20px solid transparent;
            border-right: 20px solid transparent;  
            border-top: 20px solid #2A2A2A;

        }
        ._hover{
            cursor: pointer;
            font-style: oblique;
        }
        ._hide{
            display: none;
        }
  `]
})

export class FusionTooltip{
	@Input() arrDirection:string
	@Input() content:string
	@Input() position:string
  	
    isShowing: boolean;

        @HostListener('mouseenter') onMouseEnter(){
            this.showTip();
        }
        @HostListener('mouseleave') onMouseLeave(){
            this.hideTip();    
        }

	constructor(){    
      this.isShowing = false;      
    }

    showTip(){
        this.isShowing = true;
    }

    hideTip(){
        this.isShowing = false;
    }

    /* Programmatic Creation */ 
    startup(ele,properties){
       // this.content = properties.text; 
    }
}
