/**
    FUSION VALIDATION BOX COMPONENT 
**/
import {Component,Input,Attribute,Output, EventEmitter, HostListener} from '@angular/core';

@Component({
   selector: 'fusion-vbox',
   templateUrl: './validationbox.template.html',
   styles: [`._err{
		border:2px solid red;
   } `]
   
})

export class FusionValidationBox{
	@Input() type:string;
	@Input() minimum:number = -1;
	@Input() maximum:number = -1;
	@Input() mincount:number =0;
	@Input() maxcount:number = 0;
	@Input() count="[]";
	@Input() label = "";
	@Input() inputId;
	@Input() bootStrapClass;
	@Input() value:any
	
	errorMessage:string = "Error";
	isError:boolean = false;
	isShiftKey: boolean = false;
	
	@HostListener('keypress', ['$event']) onKeyup(eve){
		if(this.type == "number"){			
			if (eve.which != 8 && eve.which != 0 && (eve.which < 48 || eve.which > 57)) {
		        return false;
    		}
			this.numCountvalidator(eve);
		}
	}
	
	ngOnInit(){
		(this.type=="number") && this.setMinMaxCount();
	}

	setMinMaxCount(){
		this.count = JSON.parse(this.count);
		if( (this.count.length>1) && (this.count[0]<this.count[1]) ){
			this.mincount = +this.count[0];
			this.maxcount = +this.count[1];
		}else if(this.count.length === 1){
			this.mincount = this.maxcount = +this.count[0];
		}
	}
	
	onInputBlur(eve){
		if(this.type == "number"){
			var _val = eve.target.value || 0;	
			
			if(this.minimum !==-1 && this.maximum !==-1){ 
				this.isError = ( (_val >= +this.minimum) && (+_val <= +this.maximum) )? false : (this.errorMessage="Not valid. Entered value is out of range", true);
			}else if(this.minimum ===-1 && this.maximum ===-1){
				this.isError = false;
			}else if(this.minimum ==-1 && _val>this.maximum){
				this.isError = true;
				this.errorMessage = "Not valid. Entered value is greater than maximum number.";
			}else if(this.maximum ==-1 && _val<this.minimum){
				this.isError = true;
				this.errorMessage = "Not valid. Entered value is less than minimum number.";
			}
			
			if(this.count.length){
				if( _val.length < this.mincount){
					this.isError = true;
					this.errorMessage = "Not valid. Entered value is less than minimum number.";
				}
			}
		}else if(this.type == "ipv4"){
			this.ipValidator(eve);			
		}
	}
	
	numCountvalidator(eve){
		var _len = eve.target.value.length,
			_kcode = eve.keyCode,
			allowedKeys = ([46,8,9,37,39].indexOf(_kcode) !== -1)? true : false;
			
			if(allowedKeys){
			
			}else if(this.count.length){
				if( !allowedKeys && _len >= this.maxcount){				
					eve.preventDefault();
				}
			}
	}

	ipValidator(eve){
		var isValidIP = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(eve.target.value);

		if( isValidIP ){  
		    this.isError = false;
		}else{
		  	this.isError = true;
			this.errorMessage = "Not a valid IP address.";
		}
	}
    
}

