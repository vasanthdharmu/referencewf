export const environment = {
  production: true,
  isDebugMode: false
};