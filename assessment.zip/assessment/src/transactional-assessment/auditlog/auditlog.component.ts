import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';

import { AuditNameLinkComponent } from './auditnamelink.component';
import { ProjectStatusComponent } from './projectstatus.component';
import { PlatformComponent } from './platform.component';
import { DateFormatAuditComponent } from './dateFormatAudit.component';

@Component({
  selector: 'audit-log',
  templateUrl: './auditlog.template.html',
  styleUrls: [ './auditlog.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class AuditLogComponent {  

  public gridOptions:GridOptions;
  public rowData: any[];
  public columnDefs: any[];
  public rowCount: string;
  public tableDataSource: any[];
  public rowModelPaginationType:string;
  public showToolPanel: any;
    
    constructor(public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService, public router: Router) {
            
    }

    ngOnInit(){
        
        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefs(),            
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no projects</span>',
            overlayLoadingTemplate : '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>',   
        }; 

        this.getAssessments();
    
      }  
      
    getAssessments(){
        let architecture = "Data Center";
        if(this.appService.get("filterContextValue").architecture_type != undefined){
            architecture = this.appService.get("filterContextValue").architecture_type[0];
        }
        let url = (<any>window).acConfig.getTransactionalAssessmentListAPI + "&architecture=" + architecture;
        this.apiService.getUrl(url, '').subscribe(
            data => {
                if(this.gridOptions != null && this.gridOptions.api != null){
                    if(data.length > 0){
                        this.logger.info("audit list", data);
                        this.gridOptions.api.setRowData(data);
                        this.gridOptions.api.hideOverlay();
                        this.gridOptions.api.sizeColumnsToFit();
                    }else{
                        this.gridOptions.api.setRowData([]);
                        this.gridOptions.api.showNoRowsOverlay();
                    }
                }

            },
            err => {
                console.error(err);
                let alertMetaData = {
                    "name": "listauditfailure",
                    "title": "List Audit Failure",
                    "type": "INFO",
                    "content": "Problem loading the audit" + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                if(this.gridOptions != null && this.gridOptions.api != null)
                    this.gridOptions.api.setRowData([]);
                this.gridOptions.api.showNoRowsOverlay();
            }
            ,() => {}
        );

    }
  
  
    public createColumnDefs() {
      
        this.columnDefs = [                     
            {headerName: "Project Name", field: "name",width: 150, sortingOrder: ['asc','desc'], cellRendererFramework:AuditNameLinkComponent, pinned: true,
                tooltipField: "name", headerTooltip: "Project Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            /*{headerName: "Created Date", field: "createdTime",width: 150, cellRenderer:this.formatDate, pinned: true,
                tooltipField: "createdTime", headerTooltip: "Created Date", suppressSorting: true, suppressFilter : true
            },*/
            {headerName: "Job Id", field: "collectionJobId",width: 200, sortingOrder: ['asc','desc'], pinned: true,
                tooltipField: "collectionJobId", headerTooltip: "Job Id"
            },
            {headerName: "Status", field: "jobStatus",width: 70, sortingOrder: ['asc','desc'], pinned: true, cellRendererFramework: ProjectStatusComponent,
                tooltipField: "jobStatus", headerTooltip: "Status", suppressFilter : true,
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "Created Date", field: "createdTime", width: 120, sortingOrder: ['asc', 'desc'], sort: "desc", pinned: true, cellRendererFramework: DateFormatAuditComponent,
                headerTooltip: "Created Date", suppressFilter: true, //, suppressSorting: true, suppressFilter: true
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {headerName: "Assessment Type", field: "catalogName",width: 120, sortingOrder: ['asc','desc'], pinned: true,  
                tooltipField: "catalogName", headerTooltip: "Assessment Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {headerName: "Architecture Type", field: "catalogName",width: 120, sortingOrder: ['asc','desc'], pinned: true, cellRendererFramework: PlatformComponent,
                tooltipField: "catalogName", headerTooltip: "Architecture Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            }
        ];
        return this.columnDefs;

    }

    public formatDate(params){

        const datepipe: DatePipe = new DatePipe('en-US');
        return datepipe.transform(params.data.createdTime, 'yMMMdjms');

    }

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }
        
    }
    

    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }
    

}