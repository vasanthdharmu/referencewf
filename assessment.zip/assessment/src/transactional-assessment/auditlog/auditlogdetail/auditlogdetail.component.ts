import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';

@Component({
  selector: 'audit-log-detail',
  templateUrl: './auditlogdetail.template.html',
  styleUrls: [ './auditlogdetail.style.css' ],
  encapsulation: ViewEncapsulation.None,
  providers: [ DatePipe ]
})
export class AuditLogDetailComponent {  

 
	public auditName: string = "";
	public auditLogDetails: any = [];
	datepipe: DatePipe = new DatePipe('en-US');
	public loading = false;
	constructor(public datePipe: DatePipe, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService, public router: Router) {
			
	}

  	ngOnInit(){
		
		let params = new URLSearchParams(window.location.search);
        this.auditName = decodeURIComponent(params.get('auditName'));
		this.getAuditLogDetail(this.auditName);
	
  	}  

	  
	  getAuditLogDetail(auditName){

		if(auditName != ""){

			this.loading = true;
			let url = (<any>window).acConfig.getTransactionslAuditLogDetailAPI + auditName;
			this.apiService.getUrl(url, '').subscribe(
				data => {
			
					this.auditLogDetails = data;
					this.loading = false;
				},
				err => {
					this.loading = false;
					let alertMetaData = {
						"name": "auditlogdetailsfailure",
						"title": "Audit Log Details Failure",
						"type": "INFO",
						"content": "Problem loading the audit log " + err._body
					}
					this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
				}
				,() => {}
			);
		}

	}
	

}