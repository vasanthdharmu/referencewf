import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'audit-name',
    template: `<a (click)="gotoLink()">{{ params.data.name }}</a>`
})

export class AuditNameLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {
         
        let viewLink = '/transactional-assessment/auditlogdetail?auditName=' + this.params.data.name;
        this.router.navigateByUrl(viewLink);
        
    }
}