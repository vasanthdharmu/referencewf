import { Component } from "@angular/core";
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'listaudit-date',
    template: `<span title="{{ date }}">{{ date }}</span>`
})

export class DateFormatAuditComponent {
    public params: any;
    public date;

    agInit(params: any): void {
        this.params = params;
        console.log("date format", this.params.value);
        const datepipe: DatePipe = new DatePipe('en-US');
        this.date =  datepipe.transform(this.params.value, 'yMMMdjms');
    }
    refresh(): boolean {
        return false;
    }
}