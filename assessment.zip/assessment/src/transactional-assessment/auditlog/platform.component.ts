import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'audit-name',
    template: `{{ this.platform }}`
})

export class PlatformComponent implements ICellRendererAngularComp  {
    public params: any;
    public platform: any;
    constructor(public router: Router) {
    }
    
    agInit(params: any): void {
        this.params = params;
        this.showPlatform(this.params.data.catalogName);
    }

    refresh(): boolean {
        return false;
    }

    public showPlatform(catalogName) {
        if(catalogName.includes('Wireless') || catalogName.includes('wireless')){
            this.platform = "Wireless";
        }
        else {
            this.platform = "Data Center";
        }
    }
}