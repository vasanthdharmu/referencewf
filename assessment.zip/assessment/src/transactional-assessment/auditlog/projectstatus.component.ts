import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'audit-name',
    template: `<span class='label label--{{ this.class }} label--raised'><span>{{ this.status }}</span></span>`
})

export class ProjectStatusComponent implements ICellRendererAngularComp  {
    public params: any;
    public status: any;
    public class: any;
    constructor(public router: Router) {
    }
    
    agInit(params: any): void {
        this.params = params;
        this.showStatus(this.params.data.jobStatus);
    }

    refresh(): boolean {
        return false;
    }

    public showStatus(jobStatus) {
        if(jobStatus == "Report-Requested"){
            this.status = "Completed";
            this.class = "success";
        }
        else if(jobStatus.includes('Failed')){
            this.status = "Failed";
            this.class = "danger";
        }
        else {
            this.status = "In Progress";
            this.class = "info";    
        }
    }
}