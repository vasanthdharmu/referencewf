import { NgModule, Component, OnInit, Input, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";
import { GridOptions } from 'ag-grid/main';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';
import { DeleteCustomerLinkComponent } from 'transactional-assessment/customermanager/deletecustomerlink.component';

@Component({
    styleUrls: ['./customer.style.css'],
    selector: 'customer',
    templateUrl: './customer.template.html',
    encapsulation: ViewEncapsulation.None
})
export class CustomerComponent {

    public tabName = 'Customer Details';
    public customerList: any = [];
    public customerDetails: any = {};
    public selectedNodesLength: any;
    public selectedNode: any;

    public gridOptions: GridOptions;
    public rowData: any[];
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;
    public originalName: string;
    public showActions: any;
    public showToolPanel: any;
    public loaderCustomerData: boolean = true;
    public loaderCustomerList: boolean = true;
    public customerBasicForm: FormGroup;
    public customerData: any = {};
    public addButton: boolean;
    public isError: boolean = false;
    public isDuplicate: boolean = false;
    public errorMessage: String = "";
    public errorDuplicateMessage: String = "";
    public formComplete: boolean = false;
    public engTypeList: any = [
        { "value": "As NCE", "name": "NCE" },
        { "value": "Internal Testing", "name": "Internal Testing" }
    ];
    public lobList: any = [
        { "value": "Enterprise", "name": "Enterprise" },
        { "value": "Service Provider", "name": "Service Provider" }, 
        { "value": "Commercial", "name": "Commercial" },
        { "value": "Other", "name": "Other" }
    ];

    public marketSgmtList: any = [
        { "value": "Education", "name": "Education" },
        { "value": "Financial", "name": "Financial" },
        { "value": "Healthcare", "name": "Healthcare" },
        { "value": "Manufacturing", "name": "Manufacturing" },
        { "value": "Retail", "name": "Retail" },
        { "value": "Other", "name": "Other" }
    ];

    public customerTheatreList: any = [
        { "value": "USA / Canada", "name": "USA / Canada" },
        { "value": "Japan", "name": "Japan" },
        { "value": "Asia Pacific", "name": "Asia Pacific" },
        { "value": "Emerging Markets", "name": "Emerging Markets" },
        { "value": "European Markets", "name": "European Markets" }
    ];

    public engTypeSelection: any = {};
    public lobSelection: any = {};
    public marketSgmtSelection: any = {};
    public customerTheatreSelection: any = {};

    public popUpLabel = '';
    @ViewChild('dialogCustDetails') dialogCustDetails;

    @ViewChild('dialogDelete') dialogDelete;
    public deleteHeader: string = "Delete Customer";
    public deleteContent: string = "Are you sure you want to delete the selected customer?";
    public deleteButtonLabel: string = "Delete Customer";
    public selectedCustomerForDelete: any;

    constructor(public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService) {

        let params = new URLSearchParams(window.location.search);
        if (params.get('?tabName') != undefined && params.get('?tabName') != null) {
            this.tabName = decodeURIComponent(params.get('?tabName'));
        }

    }

    ngOnInit() {

        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">A customer has not been added to this account.</span>',
            overlayLoadingTemplate: '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'
        };

        this.getCustomers();
        console.log("cpyKey", this.appService.get("cpyKey"));
        if (this.appService.get("cpyKey") != "" && this.appService.get("cpyKey") != null && typeof(this.appService.get("cpyKey"))=="string") {
            this.getCustomerDetails(this.appService.get("cpyKey"));
        } else {
            this.loaderCustomerData = false;
        }

        this.loadBasicForm();

    }

    public onRowSelected($event) {

        let selectedNodes = this.gridOptions.api.getSelectedNodes();
        if (selectedNodes.length > 0)
            this.selectedNode = selectedNodes[0].data;
        this.selectedNodesLength = selectedNodes.length;

    }

    getCustomers() {

        this.loaderCustomerList = true;
        let url = (<any>window).acConfig.getCustomer;
        this.apiService.getUrl(url, '').subscribe(
            data => {

                this.loaderCustomerList = false;
                this.customerList = data;
                if (this.gridOptions != null && this.gridOptions.api != null) {
                    if (data.length > 0) {
                        this.logger.info("customer list", data);
                        this.gridOptions.api.setRowData(data);
                        this.gridOptions.api.hideOverlay();
                    } else {
                        this.gridOptions.api.setRowData([]);
                        this.gridOptions.api.showNoRowsOverlay();
                    }
                    this.gridOptions.api.sizeColumnsToFit();
                }

            },
            err => {
                this.loaderCustomerList = false;
                console.error(err);
                let alertMetaData = {
                    "name": "listcustomerfailure",
                    "title": "List Customer Failure",
                    "type": "INFO",
                    "content": err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                if (this.gridOptions != null && this.gridOptions.api != null) {
                    this.gridOptions.api.setRowData([]);
                }
                this.gridOptions.api.showNoRowsOverlay();
                this.gridOptions.api.sizeColumnsToFit();
            }
            , () => { }
        );

    }

    logSelectedTab(tab) {
        if (tab.tabTitle == "My Customer") {
            this.gridOptions.api.sizeColumnsToFit();
        }
    }

    getCustomerDetails(customerID) {
        this.loaderCustomerData = true;
        if (JSON.stringify(customerID) != "{}") {
            let url = (<any>window).acConfig.getCustomer + customerID;
            this.apiService.getAPI(url, '').subscribe(
                data => {

                    this.loaderCustomerData = false;
                    if (data != null && data.status === 200) {
                        let respData = data.json();
                        this.logger.info("respData", respData);
                        this.customerDetails = respData;
                    } else {

                        let errorAlert = {
                            "name": "customerdetails",
                            "title": "Customer Details",
                            "type": "DANGER",
                            "content": "Problem loading customer details" + data.statusText
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", errorAlert);

                    }

                },
                err => {
                    this.loaderCustomerData = false;
                    this.logger.error(err);
                    let alertMetaData = {
                        "name": "customerdetailfailure",
                        "title": "Customer Detail Fetch Failure",
                        "type": "INFO",
                        "content": err._body
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                }
                , () => { }
            );
        }
    }

    public createColumnDefs() {

        this.columnDefs = [
            {
                headerName: "",
                field: "selectAllCustomers",
                width: 50,
                headerCheckboxSelection: false,
                headerCheckboxSelectionFilteredOnly: false,
                checkboxSelection: true,
                pinned: true,
                suppressFilter: true
            },
            {
                headerName: "Name", field: "name", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "name", headerTooltip: "Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Project ID", field: "pid", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "pid", headerTooltip: "Project ID",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Customer LOB ", field: "lineOfBusiness", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "lineOfBusiness", headerTooltip: "Customer LOB ",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Market Segment", field: "marketSegment", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "marketSegment", headerTooltip: "Market Segment",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Customer Theatre", field: "customerTheatre", width: 150, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "customerTheatre", headerTooltip: "Customer Theatre",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                },
            },
            {
                headerName: "", width: 50, cellRendererFramework: DeleteCustomerLinkComponent, pinned: true,
                tooltipField: "Delete", headerTooltip: "Delete", suppressFilter: true
            }
        ];
        return this.columnDefs;

    }

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }

    }

    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }

    public loadBasicForm() {
        this.customerBasicForm = new FormGroup({
            'customerName': new FormControl('', Validators.required),
            'pid': new FormControl('', Validators.required),
            'engType': new FormControl(''),
            'lob': new FormControl(''),
            'marketSgmt': new FormControl(''),
            'customerTheatre': new FormControl('')
        });
    }

    public selectChange(formControlName, formControlField) {
        this.customerBasicForm.patchValue({ [formControlName]: formControlField.value });
        this.isValidated();
    }

    public addCustomer() {
        this.showActions = !this.showActions;
        this.updateFormValues();
        this.popUpLabel = "Add Customer";
        let dialog = this.dialogCustDetails;
        dialog.width = "40%";
        dialog.height = "82%";
        dialog.showDialog();
        this.addButton = true;
    }

    public editCustomer() {
        this.showActions = !this.showActions;
        this.popUpLabel = "Edit Customer";
        let dialog = this.dialogCustDetails;
        dialog.width = "40%";
        dialog.height = "82%";
        dialog.showDialog();
        this.addButton = false;
        this.updateFormValuesEdit();
    }

    public updateFormValuesEdit() {
        this.customerBasicForm.patchValue({
            'customerName': this.selectedNode.name,
            'pid': this.selectedNode.pid,
            'engType': this.selectedNode.engineerType,
            'lob': this.selectedNode.lineOfBusiness,
            'marketSgmt': this.selectedNode.marketSegment,
            'customerTheatre': this.selectedNode.customerTheatre
        });
        this.originalName = this.selectedNode.name;
        this.updateInputArrays(this.selectedNode.engineerType, this.engTypeList, "engTypeSelection");
        this.updateInputArrays(this.selectedNode.lineOfBusiness, this.lobList, "lobSelection");
        this.updateInputArrays(this.selectedNode.marketSegment, this.marketSgmtList, "marketSgmtSelection");
        this.updateInputArrays(this.selectedNode.customerTheatre, this.customerTheatreList, "customerTheatreSelection");
    }
    public updateFormValues() {
        this.customerBasicForm.patchValue({
            'customerName': "",
            'pid': "",
            'engType': "",
            'lob': "",
            'marketSgmt': "",
            'customerTheatre': ""
        });
        this.engTypeSelection = new String("");
        this.lobSelection = new String("");
        this.marketSgmtSelection = new String("");
        this.customerTheatreSelection = new String("");
    }

    updateInputArrays(formdata, inputArray, selection) {
        for (let input of inputArray) {
            delete input['selected'];
            if (input.value == formdata) {
                input['selected'] = true;
                this[selection] = input;
            }
        }
    }

    public close() {
        let dialog = this.dialogCustDetails;
        dialog.cancelAction();
        this.isError = false;
        this.isDuplicate = false;
        this.errorMessage = "";
        this.errorDuplicateMessage = "";
        this.formComplete = true;
    }

    public add() {
        this.customerData['name'] = this.customerBasicForm.controls["customerName"].value;
        this.customerData['pid'] = this.customerBasicForm.controls["pid"].value;
        this.customerData['engineerType'] = this.customerBasicForm.controls["engType"].value;
        this.customerData['lineOfBusiness'] = this.customerBasicForm.controls["lob"].value;
        this.customerData['marketSegment'] = this.customerBasicForm.controls["marketSgmt"].value;
        this.customerData['customerTheatre'] = this.customerBasicForm.controls["customerTheatre"].value;
        this.customerData['user'] = this.appService.get("cecID");
        this.customerData['status'] = 'active';
        this.saveCustomer(this.customerData);
    }

    public saveCustomer(customerData) {

        this.close();
        if (this.addButton) {
            this.apiService.postUrl((<any>window).acConfig.postCustomer, JSON.stringify(customerData)).subscribe(
                (result) => {
                    let resultInfo = result.json();
                    if (result.status === 201 || result.status === 200) {
                        this.appService.set("customerData", JSON.stringify(result.json()));
                        this.logger.info("Resp:customerData", JSON.parse(this.appService.get("customerData")));
                        let customeName = resultInfo.name;
                        let alertMetaData = {
                            "name": "createCustomer",
                            "title": "Customer created",
                            "type": "SUCCESS",
                            "content": "Customer '" + resultInfo.name + "' added successfully."
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                        //this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");
                        (<any>window).localStorage.clear();
                        (<any>window).sessionStorage.clear();
                        (<any>window).top.location.reload();
                    }
                    else {
                        let alertMetaData = {
                            "name": "errorcreatecustomer",
                            "title": "Error on customer creation",
                            "type": "DANGER",
                            "content": "Problem creating a customer " + result.statusText
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                },
                (err) => {
                    let errinfo = err.json();
                    if (err.status === 400) {
                        let alertMetaData = {
                            "name": "errorcreatecustomer",
                            "title": errinfo.message,
                            "type": "DANGER",
                            "content": errinfo.recommended
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                    else {
                        let alertMetaData = {
                            "name": "errorcreatecustomer",
                            "title": "Error on customer creation",
                            "type": "DANGER",
                            "content": "Problem creating a customer " + err._body
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                });
        }
        else {
            let url = (<any>window).acConfig.putCustomer + this.selectedNode.id;
            this.apiService.putUrl(url, JSON.stringify(customerData)).subscribe(
                (result) => {
                    let resultInfo = result.json();
                    if (result.status === 201 || result.status === 200) {
                        this.appService.set("customerData", JSON.stringify(result.json()));
                        this.logger.info("Resp:customerData", JSON.parse(this.appService.get("customerData")));
                        let customeName = resultInfo.name;
                        let alertMetaData = {
                            "name": "updateCustomer",
                            "title": "Customer updated",
                            "type": "SUCCESS",
                            "content": "Customer '" + resultInfo.name + "' updated successfully."
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                        //this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");
                        (<any>window).localStorage.clear();
                        (<any>window).sessionStorage.clear();
                        (<any>window).top.location.reload();
                    }
                    else {
                        let alertMetaData = {
                            "name": "errorupdatecustomer",
                            "title": "Error on customer updation",
                            "type": "DANGER",
                            "content": "Problem updating customer details" + result.statusText
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                },
                (err) => {
                    let errinfo = err.json();
                    if (err.status === 400) {
                        let alertMetaData = {
                            "name": "errorupdatecustomer",
                            "title": errinfo.message,
                            "type": "DANGER",
                            "content": "Problem updating customer " + errinfo.recommended
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                    else {
                        let alertMetaData = {
                            "name": "errorupdatecustomer",
                            "title": "Error on customer updation",
                            "type": "DANGER",
                            "content": "Problem updating customer" + err._body
                        }
                        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    }
                });

        }
        //let listLink = '/transactional-assessment/customermanager?tabName=My Customer';
        //this.router.navigateByUrl(listLink);
    }

    checkNameValid(formControlName){
        if (this.addButton) {
            this.checkCustomerName(formControlName);
        }
    }
    
    checkCustomerName(formControlName) {
        this.isDuplicate = false;
        var name = this.customerBasicForm.controls[formControlName].value.trim();
        if(name.length == 0){
            this.isDuplicate = true;
            this.errorDuplicateMessage = "Customer name cannot be empty";
            this.isValidated();
        }
        else if (name != "" && name.length < 3) {
            this.isDuplicate = true;
            this.errorDuplicateMessage = "Customer should have min 3 letters";
            this.isValidated();
        }
        else if (/^[a-zA-Z0-9- _]*$/.test(name)) {
            var firstChar = this.customerBasicForm.controls[formControlName].value.charAt(0);
            if ("-,".indexOf(firstChar) != -1) {
                this.isDuplicate = true;
                this.errorDuplicateMessage = "Customer should started with letters or digits or _";
            }
            else {
                let url = (<any>window).acConfig.getCustomerDetails + this.customerBasicForm.controls[formControlName].value;
                url = encodeURI(url);
                this.apiService.getAPI(url, '').subscribe(
                    data => {
                        this.isDuplicate = false;
                        this.errorDuplicateMessage = "";
                        if (data.status == 200) {
                            this.isDuplicate = true;
                            this.errorDuplicateMessage = "Customer already exist.";
                        }
                        this.isValidated();
                    },
                    err => {
                        this.isDuplicate = true;
                        this.errorDuplicateMessage = "Invalid Customer";
                        if (err.status == 404) {
                            this.isDuplicate = false;
                            this.errorDuplicateMessage = "";
                        }
                        this.isValidated();
                    }
                    , () => { }
                );
            }
        }
        else {
            this.isDuplicate = true;
            this.errorDuplicateMessage = "Customer can contain only letters, digits, _ , - and space";
            this.isValidated();
        }
    }

    checkPid(formControlName) {
        this.isError = false;
        var name = this.customerBasicForm.controls[formControlName].value.trim();
        if(name.length == 0){
            this.isError = true;
            this.errorDuplicateMessage = "Project ID cannot be empty";
            this.isValidated();
        }
        else if (name != "" && name.length < 3) {
            this.isError = true;
            this.errorMessage = "Project ID should have minimum 3 letters";
            this.isValidated();
        }
        else if (/^[a-zA-Z0-9- _]*$/.test(name)) {
            var firstChar = this.customerBasicForm.controls[formControlName].value.charAt(0);
            if ("-,".indexOf(firstChar) != -1) {
                this.isError = true;
                this.errorMessage = "Project ID must begin with letters or digits or _";
            }
            else {
                this.isValidated();
            }
        }
        else {
            this.isError = true;
            this.errorMessage = "Project ID can contain only letters, digits, _ , - and space";
            this.isValidated();
        }
    }

    isValidated() {
        if (this.customerBasicForm.valid && !this.isError && !this.isDuplicate) {
            this.formComplete = true;
        }
        else {
            this.formComplete = false;
        }
    }

    public closeAction() {
        setTimeout(() => this.showActions = false, 250);
    }

    public showDeleteDialog(data) {

        this.selectedCustomerForDelete = data;
        let dialog = this.dialogDelete;
        dialog.width = "500px";
        dialog.height = "255px";
        dialog.showDialog();

    }

    public cancelDelete() {
        let dialog = this.dialogDelete;
        dialog.cancelAction();
    }

    deleteCustomer() {

        let customerId = this.selectedCustomerForDelete.id;
        let customerName = this.selectedCustomerForDelete.name;
        let url = (<any>window).acConfig.deleteCustomer + "/" + customerId;
        this.apiService.deleteUrl(url, '').subscribe(
            data => {

                if (data != null && data.status === 200) {
                    let alertMetaData = {
                        "name": "deletecustomer",
                        "title": "Delete Customer Success",
                        "type": "SUCCESS",
                        "content": "Customer '" + customerName + "' has been deleted successfully."
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    (<any>window).top.location.reload();
                } else {
                    let alertMetaData = {
                        "name": "deletecustomer",
                        "title": "Delete customer Failure",
                        "type": "INFO",
                        "content": "Error deleting customer '" + customerName + "'. " + data.statusText
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                }

            },
            err => {
                console.error(err);
                let alertMetaData = {
                    "name": "deletecustomer",
                    "title": "Delete customer Failure",
                    "type": "INFO",
                    "content": "Error deleting customer '" + customerName + "'. " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            }
            , () => { }
        );

        this.cancelDelete();

    }

    setNameCheck(formControlName) {
        let name = this.customerBasicForm.controls[formControlName].value.trim();
        if ((!this.addButton) && (this.originalName != name)) {
            this.checkCustomerName(formControlName);
        }
    }

}