import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'edit-assessment-status',
    template: `<a (click)="gotoLink()">Delete</a>`
})

export class DeleteCustomerLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	
	constructor(public router: Router) {    
	}
	
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {		
    
        this.params.context.componentParent.showDeleteDialog(this.params.data);
        //let link = '/transactional-assessment/ssue?operation=deletecustomer&id=' + this.params.data.id + '&name=' + this.params.data.name;
        //this.router.navigateByUrl(link);
        
    }
}