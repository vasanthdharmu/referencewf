import { Component, Output, ViewChild, EventEmitter, ElementRef, Input } from '@angular/core';
import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { workflowApi } from '@ssue-ui/cisco-workflow';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';
import { HttpEventType, HttpEvent, HttpResponse } from '@angular/common/http';

@Component({
    selector: 'datasource',
    templateUrl: './datasource.template.html',
    styleUrls: ['./datasource.style.css']
})
export class DataSourceComponent {
    @Output() private confirmStepData: EventEmitter<File[]> = new EventEmitter();

    public isUploaded: boolean = false;
    public onDrag: boolean = false;
    public uploadfileList: FileList;
    public uploading: boolean = false;
    public uploadFailed: boolean = false;
    public projectBasicForm: FormGroup;
    public enableUpload: boolean = false;
    public isChangeUpload: boolean = false;
    public architectureType: String = "";
    public projectUploadData: any = {};
    public dataSourceData = {
        "uploadType": "",
        "uploadedFile": ""
    };
    public selectedDS: any;
    public datasourceList: any;
    public datasourceListDC: any = [
        { "value": "vsem", "name": "Upload VSEM" },
        { "value": "showTech", "name": "Upload Show Tech" },
        { "value": "archive", "name": "Upload Archive" }
    ];
    public datasourceListWlna: any = [
        { "value": "archive", "name": "Upload Archive" }  
    ];
    @ViewChild('uploadinput') uploadinput: ElementRef;
    fileUploadPercentDone = 0;
    fileUploadProgressText: string = "Uploading to server...";
    fileUploadProgressSize: string = "";
    public interval: any;
    constructor(public apiService: ApiService, public workflowapi: workflowApi, public appService: AppService,public transactionalAssessmentService: TransactionalAssessmentService) {
    }

    ngOnInit() {
        this.architectureType = "Data Center";
        
        if (this.appService.get("filterContextValue").architecture_type != undefined) {
            this.architectureType = this.appService.get("filterContextValue").architecture_type[0];
        }
        if (this.architectureType == 'Wireless') {
            this.datasourceList = this.datasourceListWlna;
        }
        else if (this.architectureType == 'Data Center') {
            this.datasourceList = this.datasourceListDC;
        }
        
        this.loadBasicForm();
    }

    preLoadOnBack() {

    }

    preLoad() {

    }

    selectDS(DS, evnt) {
        this.projectBasicForm.patchValue({ [DS]: evnt.value });
        this.enableUpload = this.projectBasicForm.controls['datasource'].valid;
        this.dataSourceData.uploadType = evnt.value;
        this.projectUploadData['upload'] = this.dataSourceData.uploadType;
    }
    drop(evnt) {
        evnt.preventDefault();
        evnt.stopPropagation();
        this.uploadfileList = evnt.dataTransfer.files;
        this.uploadFile();
        this.onDrag = false;
    }

    onDragOver(evnt) {
        this.onDrag = false;
    }

    onFilesChange(fileList: FileList) {

    }


    remove() {
        if (!this.uploading) {
            this.uploadfileList = null;
            this.isUploaded = false;
            this.onDrag = false;
            this.emitStepDataOnChange(null);
        }
    }

    changeUploadedFile() {
        if (!this.uploading) {
            this.isChangeUpload = true;
            setTimeout(() => {
                let el: HTMLElement = this.uploadinput.nativeElement as HTMLElement;
                el.click();
            }, 100);
        }
    }

    afterUploadclick(event) {
        this.isChangeUpload = false;
    }

    public loadBasicForm() {
        this.projectBasicForm = new FormGroup({
            'datasource': new FormControl('', Validators.required)
        });
    }

    fileChange(event) {
        this.uploadfileList = event.target.files;
        this.uploadFile();
        this.isChangeUpload = false;
    }

    uploadFile() {
        if (this.uploadfileList.length > 0) {
            this.emitStepDataOnChange(null);
            let file: File = this.uploadfileList[0];
            let formData: FormData = new FormData();
            formData.append('file', file);
            this.isUploaded = false;
            this.uploading = true;
            this.fileUploadPercentDone = 0;
            this.fileUploadProgressText = "Uploading to server...";
            let url = (<any>window).acConfig.TransactionalfileuploadAPI;
            this.apiService.postFileProgress(url, formData).subscribe(event => {
                if (event.type === HttpEventType.UploadProgress) {
                    const percentDone = Math.round(100 * event.loaded / event.total);
                    console.log("progress", event.loaded + "---" + event.total);
                    this.fileUploadProgressSize = event.loaded + " bytes of " + event.total + " bytes";
                    if(percentDone == 100){
                        this.fileUploadProgressSize = event.loaded + " bytes are uploaded.";  
                    }
                    this.fileUploadPercentDone = percentDone;
                }
                else if (event instanceof HttpResponse) {
                    const apiResponse = event.body;
                    this.fileUploadProgressText = "Getting upload status...";
                    this.fileUploadPercentDone = 0;
                    this.interval = setInterval(() => {
                        this.checkFileUploadStatus(apiResponse['filePath']);
                    }, 1000 * 4);
                }
            }, error => {

                if (this.interval) {
                    clearInterval(this.interval);
                }
                this.uploading = false;
                this.isUploaded = false;
                this.uploadFailed = true;
                this.isChangeUpload = false;
                let alertMetaData = {
                    "name": "transactionalfileuploadfailure",
                    "title": "Transactional File Upload Failure",
                    "type": "INFO",
                    "content": "Problem uploading the file "+ error._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
    
            });

        }
    }

    checkFileUploadStatus(fileName){
        let url = (<any>window).acConfig.getFileUploadStatus + fileName + "/";
        url = encodeURI(url);
        this.apiService.getPlainUrl(url, '').subscribe(
            data => {
                if(data != "COMPLETED_UPLOAD"){
                    this.fileUploadPercentDone += 10;
               }
                else{
                    this.fileUploadPercentDone = 100;
                    this.uploading = false;
                    this.isUploaded = true;
                    this.uploadFailed = false;
                    this.isChangeUpload = false;
                    this.dataSourceData.uploadedFile = fileName;
                    this.projectUploadData['upload'] = this.dataSourceData.uploadType;
                    this.projectUploadData['filePath'] = fileName;
                    this.emitStepDataOnChange(this.projectUploadData);    
                    clearInterval(this.interval);               
                }
            }, error => {

                if (this.interval) {
                    clearInterval(this.interval);
                }
                this.uploading = false;
                this.isUploaded = false;
                this.uploadFailed = true;
                this.isChangeUpload = false;
                let alertMetaData = {
                    "name": "transactionalfileuploadfailure",
                    "title": "Transactional File Upload Failure",
                    "type": "INFO",
                    "content": "Problem getting the upload status of the file "+ error._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
    
            }
        );

    }

    ngOnDestroy() {
        if (this.interval) {
          clearInterval(this.interval);
        }
    }

    public emitStepDataOnChange(data: any) {
        this.confirmStepData.emit(data);
    }

}


