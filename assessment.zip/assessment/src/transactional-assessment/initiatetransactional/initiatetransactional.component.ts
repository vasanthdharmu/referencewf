import { Component, ViewChild, Input, ElementRef, ViewEncapsulation } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';
import { DataSourceComponent } from './datasource/datasource.component';


@Component({
    selector: 'initiate-transactional',
    styleUrls: ['./initiatetransactional.style.css'],
    templateUrl: './initiatetransactional.template.html',
    encapsulation: ViewEncapsulation.None
})
export class InitiateTransactionalComponent {

    public confirmStepData: any;
    public enableConfirmStep: boolean = false;
    public isSubmit: boolean = false;
    private subscriptionConfirm: ISubscription;
    public detailsData: boolean = false;
    public detailsStepData: any;
    public stepper_content: any;
    public isSubmitted: boolean = false;
    public architectureType: String;
    public buttonText: String;
    public loaderSaveButton: boolean = false;

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService) {
        this.registerToSSUEApiAnalysis();
    }

    ngOnInit() {
        this.architectureType = "Data Center";
        if (this.appService.get("filterContextValue").architecture_type != undefined) {
            this.architectureType = this.appService.get("filterContextValue").architecture_type[0];
        }
        if (this.architectureType == 'Data Center') {
            this.buttonText = 'Create & Initiate Analysis';
        }
        else if (this.architectureType == 'Wireless') {
            this.buttonText = 'Create';
        }
        this.stepper_content = document.getElementsByClassName("ssue-step-content");
    }

    ngOnDestroy() {
        this.subscriptionConfirm.unsubscribe();
    }

    setDetailsStepData(data) {
        if (!data) {
            this.detailsData = false;
        }
        else {
            this.detailsStepData = data;
            this.detailsData = true;
        }
        this.setConfirmStepData(this.confirmStepData);
    }

    setConfirmStepData(data) {
        if (data != null && this.detailsData) {
            this.isSubmit = true;
            this.confirmStepData = data;
        }
        else {
            this.isSubmit = false;
        }

    }

    public registerToSSUEApiAnalysis() {
        this.workflowapi.registerEvent('onCancel')
            .subscribe((response: any) => {
                this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
            });

        this.workflowapi.registerEvent('previousStepData')
            .subscribe((response: any) => {
                if (this.stepper_content.length == 0) {
                    return;
                }
                else {
                    this.stepper_content[0].scrollTop = 0;
                }
            });

        this.subscriptionConfirm = this.workflowapi.registerEvent('onConfirm')
            .subscribe((response: any) => {
                if (!this.isSubmitted) {
                    this.isSubmitted = true;
                    let postData: any;
                    let workflowData = response.payload;
                    if (workflowData) {
                        postData = JSON.parse(workflowData.step1);
                        if(this.confirmStepData != undefined){
                            postData['filePath'] = this.confirmStepData.filePath;
                            postData['uploadType'] = this.confirmStepData.upload;
                        }
                        postData['architecture'] = "Data Center";
                        if (this.appService.get("filterContextValue").architecture_type != undefined) {
                            postData['architecture'] = this.appService.get("filterContextValue").architecture_type[0];
                        }
                        this.createProject(postData);
                    }
                }
            });
    }

    public createProject(postData) {

        this.loaderSaveButton = true;
        this.apiService.postUrl((<any>window).acConfig.postTransactionalAssessmentAPI, JSON.stringify(postData)).subscribe(
            (result) => {

                let respData = result.json();
                if (result.status === 202 || result.status === 200) {
                    let alertMetaData = {
                        "name": "createproject",
                        "title": "Create Project",
                        "type": "SUCCESS",
                        "content": "Project '" + respData.name + "' has been created successfully."
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                    this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
                }
                else {
                    let alertMetaData = {
                        "name": "createprojectfailure",
                        "title": "Error on Creating Project",
                        "type": "DANGER",
                        "content": "Create project failure"
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                }
                this.loaderSaveButton = false;

            },
            (err) => {

                let errinfo = err.json();

                let alertMetaData = {
                    "name": "createprojectfailure",
                    "title": "Error on Creating Project",
                    "type": "DANGER",
                    "content": "Create project failure"
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                this.loaderSaveButton = false;

            });
        
    }

}