import { NgModule, Component, OnInit, ViewChild, Output, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { URLSearchParams } from "@angular/http";
import { Router } from '@angular/router';
import { ISubscription } from "rxjs/Subscription";

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { AssessmentService } from 'assessment/services/assessment.service';
import { workflowApi } from '@ssue-ui/cisco-workflow';

import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';


@Component({
    selector: 'project-details',
    styleUrls: ['./projectdetails.style.css'],
    templateUrl: './projectdetails.template.html'
})
export class ProjectDetailsComponent {

    public isSubmit: boolean = false;
    public projectData: any = {};
    public projectBasicForm: FormGroup;
    public isError: boolean = false;
    public errorMessage: String = "";
    public formComplete: boolean = false;
    public architectureType: String = "";
    public assessmentsList: any = [];
    public assessmentsListDC: any = [
        { "value": "ACI Health Check", "name": "ACI Health Check" },
        { "value": "Nexus Health Check", "name": "Nexus Health Check" },
        { "value": "SAN Health Check", "name": "SAN Health Check" },
        { "value": "UCS Health Check", "name": "UCS Health Check" },
        { "value": "UCS Operational Assessment", "name": "UCS Operational Assessment" }
    ];
    public assessmentsListWL: any = [
        { "value": "Wireless LAN", "name": "Wireless LAN" },
        { "value": "Wireless LAN with Mesh", "name": "Wireless LAN with Mesh" }
    ];
    @Output() detailsStepData: EventEmitter<any> = new EventEmitter();

    @ViewChild('dialogProjectList') dialogProjectList;

    constructor(public workflowapi: workflowApi, public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService) {
        (<any>window).localStorage.clear();
        (<any>window).sessionStorage.clear();
    }

    ngOnInit() {
        this.loadBasicForm();
        this.architectureType = "Data Center";
        if (this.appService.get("filterContextValue").architecture_type != undefined) {
            this.architectureType = this.appService.get("filterContextValue").architecture_type[0];
        }
        if (this.architectureType == 'Wireless') {
            this.assessmentsList = this.assessmentsListWL;
        }
        else if (this.architectureType == 'Data Center') {
            this.assessmentsList = this.assessmentsListDC;
        }
    }

    ngOnDestroy() {
    }

    public emitStepDataOnChange(data: any) {
        this.detailsStepData.emit(data);
    }

    public loadBasicForm() {
        this.projectBasicForm = new FormGroup({
            'name': new FormControl('', Validators.required),
            'catalogName': new FormControl('', Validators.required),
            'description': new FormControl('')
        });
    }

    public checkProjectName(formControlName) {
        this.isError = false;
        var name = this.projectBasicForm.controls[formControlName].value.trim();
        if (name != "" && name.length < 3) {
            this.isError = true;
            this.errorMessage = "Project name should have min 3 letters";
            this.isValidated();
        }
        else if (/^[a-zA-Z0-9- _]*$/.test(name)) {
            var firstChar = this.projectBasicForm.controls[formControlName].value.charAt(0);
            if ("-,".indexOf(firstChar) != -1) {
                this.isError = true;
                this.errorMessage = "Project name should start with letters, digits or _";
                this.isValidated();
            }
            else {
                let url = (<any>window).acConfig.getTransactionalAssessmentAPI + this.projectBasicForm.controls[formControlName].value;
                url = encodeURI(url);
                this.apiService.getAPI(url, '').subscribe(
                    data => {
                        this.isError = false;
                        this.errorMessage = "";
                        if (data.status == 200) {
                            this.isError = true;
                            this.errorMessage = "Project name already exist.";
                        }
                        this.isValidated();
                    },
                    err => {
                        this.isError = true;
                        this.errorMessage = "Invalid Project name";
                        if (err.status == 404) {
                            this.isError = false;
                            this.errorMessage = "";
                        }
                        this.isValidated();
                    }
                    , () => { }
                );
            }
        }
        else {
            this.isError = true;
            this.errorMessage = "Project name can contain only letters, digits, _ , - and space";
            this.isValidated();
        }

    }
    setValue(formControlName) {
        this.projectData[formControlName] = this.projectBasicForm.controls[formControlName].value;
        this.isValidated();
    }

    selectChange(formControlName, formControlField) {
        this.projectBasicForm.patchValue({ [formControlName]: formControlField.value });
        this.projectData[formControlName] = this.projectBasicForm.controls[formControlName].value;
        this.isValidated();
    }
    clickCheck(formControlName, formControlField) {
        this.projectBasicForm.patchValue({ [formControlName]: formControlField.value });
        this.projectData[formControlName] = this.projectBasicForm.controls[formControlName].value;
    }
    isValidated() {
        if (this.projectBasicForm.valid && !this.isError) {
            this.emitStepDataOnChange(JSON.stringify(this.projectData));
            this.formComplete = true;
        }
        else {
            this.emitStepDataOnChange('');
            this.formComplete = false;
        }
    }
}