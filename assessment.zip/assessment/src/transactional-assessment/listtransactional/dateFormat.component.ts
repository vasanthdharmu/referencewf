import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'listtransactional-date',
    template: `<span title="{{ date }}">{{ date }}</span>`
})

export class DateFormatComponent {
    public params: any;
    public date;

    agInit(params: any): void {
        this.params = params;
        this.date = this.params.context.componentParent.formatDate(this.params.value);
        
    }
    refresh(): boolean {
        return false;
    }
}