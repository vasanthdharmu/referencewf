import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod } from '@angular/http';
import { GridOptions } from 'ag-grid/main';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import * as FileSaver from 'file-saver';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { StatusLinkComponent } from './statuslink.component';
import { ReportLinkComponent } from './reportlink.component';
import { DateFormatComponent } from './dateFormat.component';
import { LogLinkComponent } from './loglink.component';

import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'list-transactional',
    templateUrl: './listtransactional.template.html',
    styleUrls: ['./listtransactional.style.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [DatePipe]
})
export class ListTransactionalComponent {

    public selectedNodesLength: any;
    public selectedNode: any;

    public gridOptions: GridOptions;
    public rowData: any[];
    public columnDefs: any[];
    public rowCount: string;
    public tableDataSource: any[];
    public rowModelPaginationType: string;

    public showActions: any;
    public showToolPanel: any;
    public currentAssessment: any;
    public selectedProjectName: string = "";
    public SSIDConfiguration: any;
    public isDownloadable = true;
    public loaderRuleList: boolean = true;
    public selectedCollectionJobId: string ;

    @ViewChild('showStatusHistory') showStatusHistory: ElementRef;
    @ViewChild('dialogSSIDConfiguration') dialogSSIDConfiguration;
    @ViewChild('dialogDelete') dialogDelete;
    @ViewChild('dialogReportTemplates') dialogReportTemplates;
    @ViewChild('dialogLog') dialogLog;

    public selectedAssessment: any;
    public reportTemplates: any;
    public loaderReportList: boolean = true;
    public enableDownload: boolean = false;    
    public templateForm;
    public deleteHeader: string = "Delete Project(s)";
    public deleteContent: string = "Are you sure you want to delete the selected Project(s)?";
    public deleteButtonLabel: string = "Delete Project(s)";
    public interval: any;
    public log: any;
    public downloadReportRequest:Subscription = null;
    constructor(private fb: FormBuilder, public datePipe: DatePipe, public http: Http, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public router: Router, public transactionalAssessmentService: TransactionalAssessmentService) {

    }

    ngOnInit() {

        this.gridOptions = <GridOptions>{
            context: {
                componentParent: this
            },
            suppressRowClickSelection: true,
            rowSelection: 'multiple',
            paginationPageSize: 10,
            pagination: true,
            enableFilter: true,
            floatingFilter: true,
            columnDefs: this.createColumnDefs(),
            overlayNoRowsTemplate: '<span style="padding: 10px;font-weight: bold;">There are no available projects</span>',
            overlayLoadingTemplate: '<div><h4 class="text-center">Loading...</h4><div class="loading-dots loading-dots--muted"><span></span><span></span><span></span></div></div>'
        };

        this.getAssessments();

    }

    ngOnDestroy() {
        if (this.interval) {
          clearInterval(this.interval);
        }
    }


    public onRowSelected($event) {

        let selectedNodes = this.gridOptions.api.getSelectedNodes();
        if (selectedNodes.length > 0)
            this.selectedNode = selectedNodes[0].data;
        this.selectedNodesLength = selectedNodes.length;

    }

    // deleteProject() {

    //     let selectedNodes = this.gridOptions.api.getSelectedNodes();
    //     let name = [];
    //     let status = [];
    //     for (let node of selectedNodes) {
    //         name.push(node.data.name);
    //         status.push(node.data.status);
    //     }
    //     let deleteLink = '/transactional-assessment/ssue?operation=deletproject&assessmentId=' + name.join("|");
    //     this.router.navigateByUrl(deleteLink);

    // }

    getAssessments() {

        let architecture = "Data Center";
        if(this.appService.get("filterContextValue").architecture_type != undefined){
            architecture = this.appService.get("filterContextValue").architecture_type[0];
        }
        let url = (<any>window).acConfig.getTransactionalAssessmentListAPI + "&architecture=" + architecture;
        this.apiService.getUrl(url, '').subscribe(
            data => {
                if (this.gridOptions != null && this.gridOptions.api != null) {
                    if (data.length > 0) {
                        this.gridOptions.api.setRowData(data);
                        this.gridOptions.api.hideOverlay();
                        this.gridOptions.api.sizeColumnsToFit();
                        this.interval = setInterval(() => { this.getAssessmentList(); }, 1000 * 60 * 3 );
                    } else {
                        this.gridOptions.api.setRowData([]);
                        this.gridOptions.api.showNoRowsOverlay();
                        this.gridOptions.api.sizeColumnsToFit();
                    }
                }

            },
            err => {
                let alertMetaData = {
                    "name": "listassessmentfailure",
                    "title": "List Assessment Failure",
                    "type": "INFO",
                    "content": "Problem loading the project list " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);                
                if (this.gridOptions != null && this.gridOptions.api != null){
                    this.gridOptions.api.setRowData([]);
                    this.gridOptions.api.showNoRowsOverlay();
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
            , () => { }
        );

    }

    getAssessmentList(){

        this.gridOptions.api.showLoadingOverlay();
        let architecture = "Data Center";
        if(this.appService.get("filterContextValue").architecture_type != undefined){
            architecture = this.appService.get("filterContextValue").architecture_type[0];
        }
        let url = (<any>window).acConfig.getTransactionalAssessmentListAPI + "&architecture=" + architecture;
        this.apiService.getUrl(url, '').subscribe(
            data => {

                if (this.gridOptions != null && this.gridOptions.api != null) {
                    if (data.length > 0) {
                        this.gridOptions.api.setRowData(data);
                        this.gridOptions.api.hideOverlay();
                        this.gridOptions.api.sizeColumnsToFit();
                    } else {
                        this.gridOptions.api.setRowData([]);
                        this.gridOptions.api.showNoRowsOverlay();
                        this.gridOptions.api.sizeColumnsToFit();
                    }
                }

            },
            err => {
                
                if (this.gridOptions != null && this.gridOptions.api != null){
                    this.gridOptions.api.setRowData([]);
                    this.gridOptions.api.showNoRowsOverlay();
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
            , () => { }
        );

    }


    public createColumnDefs() {

        this.columnDefs = [
            {
                headerName: "",
                field: "selectAllAssessments",
                width: 50,
                headerCheckboxSelection: false,
                headerCheckboxSelectionFilteredOnly: false,
                checkboxSelection: true,
                pinned: true,
                suppressFilter: true
            },
            {
                headerName: "Project Name", field: "name", width: 180, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "name", headerTooltip: "Project Name",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Assessment Type", field: "catalogName", width: 180, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "catalogName", headerTooltip: "Assessment Type",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Created Date", field: "createdTime", width: 150, sortingOrder: ['asc', 'desc'], sort: "desc", cellRendererFramework: DateFormatComponent, pinned: true,
                headerTooltip: "Created Date", suppressFilter: true, //, suppressSorting: true, suppressFilter: true
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Description", field: "description", width: 180, sortingOrder: ['asc', 'desc'], pinned: true,
                tooltipField: "description", headerTooltip: "Description",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Project Status", field: "jobStatus", width: 150, sortingOrder: ['asc', 'desc'], cellRendererFramework: StatusLinkComponent, pinned: true,
                tooltipField: "jobStatus", headerTooltip: "Project Status",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "ETA / Date Completed", field: "updatedTime", width: 180, sortingOrder: ['asc', 'desc'], cellRendererFramework: DateFormatComponent, pinned: true,
                headerTooltip: "ETA / Date Completed", suppressFilter: true, //, suppressSorting: true, suppressFilter: true
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Report", field: "assessmentId", width: 120, cellRendererFramework: ReportLinkComponent, pinned: true,
                tooltipField: "status", headerTooltip: "Report",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            },
            {
                headerName: "Log", field: "assessmentId", width: 100, cellRendererFramework: LogLinkComponent, pinned: true,
                tooltipField: "status", headerTooltip: "Log",
                icons: {
                    sortAscending: '<span class="sort-indicator icon-chevron-up"></span>',
                    sortDescending: '<span class="sort-indicator icon-chevron-down"></span>'
                }
            }
        ];
        //this.columnDefs.headerClass
        return this.columnDefs;

    }

    public formatDate(params) {

        const datepipe: DatePipe = new DatePipe('en-US');
        return datepipe.transform(params, 'yMMMdjms');

    }

    public calculateRowCount() {

        if (this.gridOptions.api && this.rowData) {
            var model = this.gridOptions.api.getModel();
            var totalRows = this.rowData.length;
            var processedRows = model.getRowCount();
            this.rowCount = processedRows.toLocaleString() + ' / ' + totalRows.toLocaleString();
        }

    }


    public onModelUpdated() {
        this.calculateRowCount();
    }

    public onReady() {
        this.calculateRowCount();
    }

    public showSSIDConfiguration(assessment) {
        this.loaderRuleList = true;
        this.currentAssessment = assessment;
        this.selectedProjectName = assessment.name;
        this.selectedCollectionJobId = assessment.collectionJobId;
        let dialog = this.dialogSSIDConfiguration;
        dialog.width = "70%";
        dialog.height = "90%";
        dialog.showDialog();

        let catalogurl = (<any>window).acConfig.getCatalogDetailsAPI + this.currentAssessment.catalogName;
        this.apiService.getUrl(catalogurl, '').subscribe(
            data => {
                this.currentAssessment['ruleList'] = data.icSubset;
                this.loaderRuleList = false;
            },
            err => {
                let alertMetaData = {
                    "name": "getrulelistofwlna",
                    "title" : "Get WLNA ruleList",
                    "type":"DANGER",
                    "content": "Error on getting ruleList. " + err._body
                }    
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                this.loaderRuleList = false;
                this.close();
            }
            ,() => {}
        );

    }

    public closeReportTemplates() {
        let dialog = this.dialogReportTemplates;
        dialog.cancelAction();
    }

    onClosePopup(){
        if(this.downloadReportRequest){
            this.downloadReportRequest.unsubscribe();
            this.enableDownload = false;
            }
    }

    changeTemplate(){

        this.enableDownload = false;
        this.templateForm.value.templates.forEach((template, index) => {
            if(template){
                this.enableDownload = true;
            }
        });
    }

    showTemplates(selectedAssessment){

        this.loaderReportList = true;
        this.reportTemplates = "";
        this.selectedAssessment = selectedAssessment;

        let dialog = this.dialogReportTemplates;
        dialog.width = "65%";
        dialog.height = "80%";
        dialog.showDialog();
        let url = (<any>window).acConfig.getReportAPI + this.selectedAssessment.assessmentId + "/collectionJobId/" + this.selectedAssessment.collectionJobId;
        this.apiService.getUrl(url, '').subscribe(
            data => {
                this.reportTemplates = data;
                console.log(this.reportTemplates);
                this.templateForm = this.fb.group({
                    templates: this.buildTemplates(this.reportTemplates)
                });
                this.loaderReportList = false;
            },
            err => {
                let alertMetaData = {
                    "name": "getreporttemplates",
                    "title": "Report Templates",
                    "type": "DANGER",
                    "content": "Problem with getting report templates. " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                this.closeReportTemplates();
            }
            , () => { }
        );
    }

    buildTemplates(reportTemplates){
        const templateArr = reportTemplates.reportList.map(template => {
            return this.fb.control(false);
        })
        return this.fb.array(templateArr);
    }

    downloadSelectedReport(){
        this.loaderReportList = true;
        let postData = {
            "reportRequestId": this.reportTemplates.reportRequestId,
            "reportList": [
            ]
        };
        this.templateForm.value.templates.forEach((template, index) => {
            if(template){
                let report = {
                    "name": this.reportTemplates.reportList[index].name
                };
                postData.reportList.push(report);
            }
        });

        let url = (<any>window).acConfig.downloadReportAPI;
        this.logger.info("post download data", JSON.stringify(postData));
        this.downloadReportRequest =  this.apiService.downloadFile(url, postData).subscribe(
            data => {
                var blob = new Blob([(<any>data)._body], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                });
                let fileName = this.selectedAssessment.name + ".zip";
                FileSaver.saveAs(blob, fileName);
                this.closeReportTemplates();
                this.loaderReportList = false;
            },
            err => {
                this.logger.error(err);
                let alertMetaData = {
                    "name": "downloadreports",
                    "title": "Download Reports",
                    "type": "DANGER",
                    "content": "Problem with downloading reports. " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                this.closeReportTemplates();
                this.loaderReportList = false;
            }
            , () => { }
        );

    }

    public downloadReport(assessmentId, downloadCheck, collectionJobId) {
        this.gridOptions.api.showLoadingOverlay();
        let url = (<any>window).acConfig.getReportAPI + assessmentId + "/collectionJobId/" + collectionJobId;
        let reportReferenceId: any;
        let templateList = [];
        this.apiService.getUrl(url, '').subscribe(
            data => {
                if (data && data.reportList.length > 0) {
                    this.callDownload(data, downloadCheck);
                }
            },
            err => {
                console.error(err);
                let alertMetaData = {
                    "name": "getreportfailure",
                    "title": "Get Report Failure",
                    "type": "INFO",
                    "content": err._body
                }
            }
            , () => { }
        );
    }

    public callDownload(data, downloadCheck) {
        if (data.reportRequestId != null && data.reportRequestId != '') {

            let postData = {
                "reportRequestId": data.reportRequestId,
                "reportList": [
                ]
            };
            data.reportList.forEach(file => {
                if (file.reportGenerationStatus == "Report Generation-Success") {
                    if (downloadCheck) {
                        this.isDownloadable = true;
                    }
                    else {
                        let report = {
                            "name": file.reportName
                        };
                        postData.reportList.push(report);
                    }
                }
            });
            if (!downloadCheck) {
                this.getReport(postData);
            }
        }
    }

    public getReport(postData) {
        let url = (<any>window).acConfig.downloadReportAPI;
        this.logger.info("post download data", JSON.stringify(postData));
        this.apiService.downloadFile(url, postData).subscribe(
            data => {
                var blob = new Blob([(<any>data)._body], {
                    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                });
                let fileName = "report.zip";
                FileSaver.saveAs(blob, fileName);
                this.gridOptions.api.hideOverlay()
            },
            err => {
                this.logger.error(err);
                let alertMetaData = {
                    "name": "getreportfailure",
                    "title": "Get Report Failure",
                    "type": "INFO",
                    "content": err._body
                }
                this.gridOptions.api.hideOverlay()
            }
            , () => { }
        );
    }

    public close() {
        let dialog = this.dialogSSIDConfiguration;
        dialog.cancelAction();        
    }

    public skip() {

        let postData = {
            "collectionJobId": this.currentAssessment.collectionJobId,
            "ruleList": this.currentAssessment['ruleList'],
            "deviceList": this.currentAssessment.devices,
            "ssids":{
                "guestSSID": [],
                "corporateSSID": [],
                "voiceSSID": [],
                "spWifiSSID": []
            }
        };
        this.startAnalysis(postData);
        this.close();
        this.gridOptions.api.refreshCells();
    }

    public saveAnalysis() {

        let corporate_ssid = [];
        let voice_ssid = [];
        let guest_ssid = [];
        let sp_wifi_ssid = [];
        this.SSIDConfiguration[1].items.forEach(ssid => {
            corporate_ssid.push(ssid.name)
        });
        this.SSIDConfiguration[2].items.forEach(ssid => {
            voice_ssid.push(ssid.name)
        });
        this.SSIDConfiguration[3].items.forEach(ssid => {
            guest_ssid.push(ssid.name)
        });
        this.SSIDConfiguration[4].items.forEach(ssid => {
            sp_wifi_ssid.push(ssid.name)
        });

        let postData = {
            "collectionJobId": this.currentAssessment.collectionJobId,
            "ruleList": this.currentAssessment['ruleList'],
            "deviceList": this.currentAssessment.devices,
            "ssids":{
                "guestSSID": guest_ssid,
                "corporateSSID": corporate_ssid,
                "voiceSSID": voice_ssid,
                "spWifiSSID": sp_wifi_ssid
            }
        };
        this.startAnalysis(postData);
        this.close();
        this.gridOptions.api.refreshCells();
    }

    public startAnalysis(postData){
        this.apiService.postUrl((<any>window).acConfig.postAnalysisAPI, JSON.stringify(postData)).subscribe(
            (result) => {
                let resultInfo = result.json();
                if (result.status === 202 || result.status === 200) {
                    let alertMetaData = {
                        "name": "startAnalysis",
                        "title": "Start Analysis",
                        "type": "SUCCESS",
                        "content": "Successfully started the analysis,  your report will be ready in some time."
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                }
                else {
                    let alertMetaData = {
                        "name": "errorstartAnalysis",
                        "title": "Error on start analysis",
                        "type": "DANGER",
                        "content": "Problem with starting an Analysis. " + result.statusText
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                }
                this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
            },
            (err) => {
                let alertMetaData = {
                    "name": "errorstartAnalysis",
                    "title": "Error on start analysis",
                    "type": "DANGER",
                    "content": "Problem with starting an Analysis. " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
              });
    }

    public configurationChange(value) {
        this.SSIDConfiguration = value;
    }

    public closeAction() {
        setTimeout(() => this.showActions = false, 250);
    }

    deleteProject() {

        let selectedNodes = this.gridOptions.api.getSelectedNodes();
        let combined: any;
        let observableBatch = [];
        for(let project of selectedNodes){
            let url = (<any>window).acConfig.deleteTransactionalAssessmentAPI + project.data.name;       
            var headers = new Headers();
            if((<any>top).ssue_accessToken != undefined){
                headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
            }else{
                headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
            }
            headers.append("Content-Type","application/json");
            headers.append("loggedin", this.appService.get("cecID"));
            headers.append("CUSTOMER", this.appService.get("cpyKey"));
            var requestOptions = new RequestOptions({
            method: RequestMethod.Delete,
            url: url,
            headers: headers,
            body: ''
            });
        
            observableBatch.push( this.http.request(new Request(requestOptions)).map((res: Response) => {  }) );   

        }

        combined = Observable.forkJoin(observableBatch);

        combined.subscribe(
        finalResponse => {
            var proejcts = selectedNodes.map(function(val) {
                return val.data.name;
              }).join(',');
            let alertMetaData = {
            "name": "deleteproject",
            "title" : "Delete Project Success",
            "type":"SUCCESS",
            "content": proejcts + (selectedNodes.length >1?" are ":"is") + " deleted successfully."       
            }    
            this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            // this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
            this.transactionalAssessmentService.onRefresh();

        },
        error => {
        let alertMetaData = {
            "name": "deleteproject",
            "title" : "Delete Project Failure",
            "type":"DANGER",
            "content": "Error during deleting some project"     
        }    
        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        // this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
        this.transactionalAssessmentService.onRefresh();
        });
    
        this.cancelDelete();
    }

    public showDeleteDialog(data) {
        // this.selectedCustomerForDelete = data;
        let dialog = this.dialogDelete;
        dialog.width = "500px";
        dialog.height = "255px";
        dialog.showDialog();
    }

    public cancelDelete() {
        let dialog = this.dialogDelete;
        dialog.cancelAction();
    }

    public viewLog(collectionJobId){
        this.log = '';
        let dialog = this.dialogLog; 
        dialog.width = "65%";
        dialog.height = "80%";
        dialog.showDialog();
        let url = (<any>window).acConfig.getLogAPI+collectionJobId+"/logs";
        this.apiService.getUrl(url, '').subscribe(
            data => {
                if (data != null || data != undefined)
                    this.log = data;
                else
                    this.log = "Logs currently not available !!"
            },
            err => {
                console.log("inside error"+err);
                let alertMetaData = {
                    "name": "getlogs",
                    "title": "Logs",
                    "type": "DANGER",
                    "content": "Problem with getting logs. " + err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
                dialog.cancelAction();
            }
            , () => { }
        );
    }
}
