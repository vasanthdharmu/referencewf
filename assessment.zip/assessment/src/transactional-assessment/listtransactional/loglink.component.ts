import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'listtransactional-log',
    template: `<a title="Log" (click)="viewLog()">View</a>`
})

export class LogLinkComponent implements ICellRendererAngularComp  {
    public params: any;
    public isDownloadEnable = false;
    
    constructor(public router: Router) {    
    }
    
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public viewLog() {
        let viewLink = '/transactional-assessment/auditlogdetail?auditName=' + this.params.data.name;
        this.router.navigateByUrl(viewLink);
        //this.params.context.componentParent.viewLog(this.params.data.collectionJobId);
    }
}