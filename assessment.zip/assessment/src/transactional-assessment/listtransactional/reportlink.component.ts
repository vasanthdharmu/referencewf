import { Component } from "@angular/core";
import { Router } from '@angular/router';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'listtransactional-report',
    template: `<a *ngIf="params.data.jobStatus == 'Report-Requested'" title="Download" (click)="reportDownload()">Download</a><span *ngIf="params.data.jobStatus != 'Report-Requested'" title="Report Unavailable">Report Unavailable<span>`
})

export class ReportLinkComponent implements ICellRendererAngularComp  {
    public params: any;
    public isDownloadEnable = false;
    
    constructor(public router: Router) {    
    }
    
    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }

    public reportDownload() {
        this.params.context.componentParent.showTemplates(this.params.data);
    }
}