import { Component } from "@angular/core";
import { Router } from '@angular/router';
import { AppService } from 'app/shared/app.service';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
    selector: 'listtransactional-status',
    template: `<a (click)="gotoLink()" *ngIf="(params.data.jobStatus == 'Extraction-Completed') && (architecture == 'Wireless')">User Input Needed</a>
    <span *ngIf="(params.data.jobStatus != 'Extraction-Completed') || (architecture != 'Wireless')">{{params.data.jobStatus}}</span>`
})

export class StatusLinkComponent implements ICellRendererAngularComp  {
    public params: any;
	public architecture: string;
	constructor(public router: Router, public appService: AppService) {    
	}
	
    agInit(params: any): void {
        this.params = params;
        this.architecture = "Data Center";
        if(this.appService.get("filterContextValue").architecture_type != undefined){
            this.architecture = this.appService.get("filterContextValue").architecture_type[0];
        }
    }

    refresh(): boolean {
        return false;
    }

    public gotoLink() {	
        this.params.context.componentParent.showSSIDConfiguration(this.params.data);
        
    }
}