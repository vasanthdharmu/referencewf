import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild } from '@angular/router';
import { Router } from '@angular/router';

import { AppService } from 'app/shared/app.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';

@Injectable()
export class CustomerCheckGuard implements CanActivate {

  constructor(private appService: AppService, public router: Router, public transactionalAssessmentService: TransactionalAssessmentService) {

  }

  canActivate() {

    console.log("domainFilter", this.appService.get("domainFilter"));

    if ((<any>top).ssue && (<any>top).ssue != ""){
      if((<any>top).ssue.common.api.access.domainFilter != undefined && (<any>top).ssue.common.api.access.domainFilter != ""){

        console.log("domainFilter length", this.appService.get("domainFilter").data.customer.length);

        if(this.appService.get("domainFilter").data.customer.length == 0){
          //let link = '/transactional-assessment/customermanager';
          //this.router.navigateByUrl(link);
          this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");
          return false;
        }
        

      }
    }
    console.log('i am checking to see if you are logged in');
    return true;
  }

}