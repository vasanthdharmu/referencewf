import { Component, Output,  EventEmitter, ViewEncapsulation, Input, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';

@Component({
    selector: 'ssid-configuration',
    templateUrl: './ssidconfiguration.template.html',
    styleUrls: ['./ssidconfiguration.style.css'],
    encapsulation: ViewEncapsulation.None
})

export class SsidConfigurationComponent {
   
    @Input() projectName: string = "";
    @Output() configurationChange: EventEmitter<any> = new EventEmitter();
    public loaderSSIDConfiguration: boolean = true;
    public onDrag:boolean =false;
    public hoverIndex:number;
    public allSSIDs = [
        {   
            listName: "Available SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "Corporate SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "Voice SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "Guest SSID(s)", 
            items: [], 
            dragging: false
        },
        {   
            listName: "SP Wifi", 
            items: [], 
            dragging: false
        }
      ];
    constructor(public router: Router, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public transactionalAssessmentService: TransactionalAssessmentService) {

    }

    ngOnInit() {

    }

    ngOnChanges(changes: {[propKey: string]: SimpleChange}) {
        let log: string[] = [];
		for (let propName in changes) {
		  let changedProp = changes[propName];
		  if (changedProp.isFirstChange()) {
            this.projectName = changedProp.currentValue;
            this.allSSIDs[0].items = [];
            this.getSSIDConfigurationList(this.projectName);
		  } else {
            //let from = JSON.stringify(changedProp.previousValue);
		  }
		}

	}

    getSSIDConfigurationList(projectName) {

        this.loaderSSIDConfiguration = true;
        let url = (<any>window).acConfig.getSSIDConfigurationListAPI + projectName;
        this.apiService.getAPI(url, '').subscribe(
            data => {

                if (data != null && data.status === 200) {
                    let respData = data.json();
                    this.logger.info("respData", respData);
                    respData.forEach(ssidname => {
                        this.allSSIDs[0].items.push({"name": ssidname});
                    });
                    this.loaderSSIDConfiguration = false;
                } else {

                    this.loaderSSIDConfiguration = false;
                    let errorAlert = {
                        "name": "SSIDConfigurationFailure",
                        "title": "SSID Configuration Failure",
                        "type": "DANGER",
                        "content": "Problem loading the SSID Configuration" + data.statusText
                    }
                    this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", errorAlert);

                }

            },
            err => {
                this.loaderSSIDConfiguration = false;
                this.logger.error(err);
                let alertMetaData = {
                    "name": "SSIDConfigurationFailure",
                    "title": "SSID Configuration Failure",
                    "type": "INFO",
                    "content": err._body
                }
                this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
            }
            , () => { }
        );

    }

    dragStarted(item,fromIndex,event){
        
        let selectedList:string[]=[];   
        let isSelected:boolean=false;
        item.selected=true; 
        for (let item of this.allSSIDs[fromIndex].items) {
            if(item.selected){
                selectedList.push(item);
                isSelected=true;
            }               
        }        
        if(isSelected){
            let selectionObject:any = {"fromIndex":fromIndex,
                                    "selection":selectedList};
            var j = JSON.stringify(selectionObject);
            event.dataTransfer.setData("text", j);
        }       
       this.onDrag=true;
    }

    drop(toindex,event){
        event.preventDefault();     
        if(event.dataTransfer.getData("text")){
            var obj = JSON.parse(event.dataTransfer.getData("text"));
            if(toindex!=obj.fromIndex){
                //ADD TO THE LIST
                if(this.allSSIDs[toindex].items.length>0){    
                    for(let item of obj.selection)
                        this.allSSIDs[toindex].items.push(item); 
                } 
                else    
                    this.allSSIDs[toindex].items = obj.selection;

                //REMOVE ITEMS FROM LIST
                var i = this.allSSIDs[obj.fromIndex].items.length;
                while (i--) {                
                    if (this.allSSIDs[obj.fromIndex].items[i].selected) { 
                        this.allSSIDs[obj.fromIndex].items.splice(i,1);
                    } 
                }
            }
            this.onDrag=false;  
            this.resetSelection();
            this.configurationChange.emit(this.allSSIDs);
        }
    }

    select(index,jsonIndex, evnt){
        evnt.stopPropagation();
        this.allSSIDs[jsonIndex].items[index].selected = !this.allSSIDs[jsonIndex].items[index].selected; 
    }


    dragOver(index,ev) {
        ev.preventDefault();
        ev.stopPropagation();
        this.hoverIndex=index;
    }

    resetSelection(){
        for (let SSID of this.allSSIDs) {
            for(let item of SSID.items){
                item.selected=false;
            }
        }
    }

}
