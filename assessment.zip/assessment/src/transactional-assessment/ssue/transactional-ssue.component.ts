import { Component, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response, RequestOptions, Headers, Request, RequestMethod, URLSearchParams, Jsonp } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { ApiService } from 'app/shared/api.service';
import { AppService } from 'app/shared/app.service';
import { LoggerService } from 'app/shared/logger.service';
import { TransactionalAssessmentService } from 'transactional-assessment/services/transactional-assessment.service';

import { FusionToaster } from 'aui/components/notification-toaster/fusion-notification-toaster.component';
import { ToasterAnchorDirective } from 'aui/components/notification-toaster/toasteranchor.directive';

import { FusionAlert } from 'aui/components/notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from 'aui/components/notification-alert/alertanchor.directive';

@Component({
  selector: 'transactional-ssue-operations',
  templateUrl: './transactional-ssue.template.html',
  styleUrls: [ './transactional-ssue.style.css' ],
  encapsulation: ViewEncapsulation.None,
  entryComponents: [ FusionToaster, FusionAlert ]
})
export class TransactionalSSUEComponent {
  
  public operation:any;

  @ViewChild(ToasterAnchorDirective) toasterAnchor;
  @ViewChild('toaster') toaster:ElementRef;

  @ViewChild(AlertAnchorDirective) alertAnchor;
  @ViewChild('deletefusionalert') deletefusionalert:ElementRef;

  constructor(public http:Http, public apiService: ApiService, public appService: AppService, public logger: LoggerService, public router: Router, public transactionalAssessmentService: TransactionalAssessmentService) {


  }


  ngOnInit(){

    let params = new URLSearchParams(window.location.search);
    this.operation = params.get('?operation');

    switch(this.operation){
      case "deletecustomer":
        this.deleteconfirmation("deletecustomer");
        break;
      case "deletproject":
        this.deleteconfirmation("deletproject");
        break;
    }

    this.appendCUIComponentstoWrapper();

  }


  public appendCUIComponentstoWrapper(){
    //document.getElementById("content-wrapper").appendChild(document.getElementById("deletefusionalert"));
    document.body.appendChild(document.getElementById("deletefusionalert"));
	}
  
  deleteconfirmation(purpose){      

      switch(purpose){

        case "deletecustomer":
          this.deleteCustomerConfirmation();
          break;
        case "deletproject":
          this.deleteProjectConfirmation();
          break; 
      }
      
  }

  deleteCustomerConfirmation(){

    let deletefusionalert = this.deletefusionalert.nativeElement;  
    let buttons =  [{
        label: "Yes",
    }, {
        label: "No"
    }];
    let params = new URLSearchParams(window.location.search);
    let customerId = decodeURIComponent(params.get('id'));
    let customerName = decodeURIComponent(params.get('name'));
    this.alertAnchor.createAlert(FusionAlert,"warning","Do you really want to delete the customer " + customerName +" ?","",deletefusionalert, buttons);

  }

  deleteProjectConfirmation(){

    let deletefusionalert = this.deletefusionalert.nativeElement;  
    let buttons =  [{
        label: "Yes",
    }, {
        label: "No"
    }];
    let params = new URLSearchParams(window.location.search);
    let assessmentId = decodeURIComponent(params.get('assessmentId')).split("|").join(", ");
    this.alertAnchor.createAlert(FusionAlert,"warning","Do you really want to delete the project " + assessmentId +" ?","",deletefusionalert, buttons);

  }

 
  onDeleteAlertButtonClick(event){
    
      let target = event.target || event.srcElement || event.currentTarget;
      let params = new URLSearchParams(window.location.search);
      let purpose = params.get('?operation');    
      switch(target.innerHTML){

        case "Yes":
    
            switch(purpose){
              case "deletecustomer":
                this.deleteCustomer();
                break;
              case "deletproject":
                this.deleteProject();
                break; 
            }
            
            break;
        
        case "No":

            switch(purpose){
              case "deletecustomer":
                this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");
                break;
              case "deletproject":
                this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
                break; 
              
            }                
            break;
        
      }

  }

  deleteCustomer(){

    let params = new URLSearchParams(window.location.search);
    let customerId = decodeURIComponent(params.get('id'));
    let customerName = decodeURIComponent(params.get('name'));
    let url = (<any>window).acConfig.deleteCustomer + "/" + customerId;
    this.apiService.deleteUrl(url, '').subscribe(
      data => {

        if (data != null && data.status === 200) {
          let alertMetaData = {
            "name": "deletecustomer",
            "title" : "Delete Customer Success",
            "type":"SUCCESS",
            "content": customerName + " has been deleted successfully."       
          }    
          this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          (<any>window).top.location.reload();
        }else{
          let alertMetaData = {
            "name": "deletecustomer",
            "title": "Delete customer Failure",
            "type": "INFO",
            "content": "Error deleting a customer " + customerName + " " + data.statusText
          }
          this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");
        }

      },
      err => {
          console.error(err);
          let alertMetaData = {
              "name": "deletecustomer",
              "title": "Delete customer Failure",
              "type": "INFO",
              "content": "Error deleting a customer " + customerName + " " + err._body
          }
          this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
          this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Customer");

      }
      , () => { }
    );


  }
  
  
  deleteProject(){

    let params = new URLSearchParams(window.location.search);
    let assessmentId = decodeURIComponent(params.get('assessmentId')).split("|");
    let combined: any;
    let observableBatch = [];

    for(let i = 0; i < assessmentId.length; i++){
        let url = (<any>window).acConfig.deleteTransactionalAssessmentAPI + assessmentId[i];       
        var headers = new Headers();
        if((<any>top).ssue_accessToken != undefined){
          headers.append("Authorization", "Bearer " + (<any>top).ssue_accessToken);
        }else{
          headers.append("Authorization", "Bearer " + this.appService.get("ssue_accessToken"));
        }
        headers.append("Content-Type","application/json");
        headers.append("loggedin", this.appService.get("cecID"));
        headers.append("CUSTOMER", this.appService.get("cpyKey"));
        var requestOptions = new RequestOptions({
          method: RequestMethod.Delete,
          url: url,
          headers: headers,
          body: ''
        });
      
        observableBatch.push( this.http.request(new Request(requestOptions)).map((res: Response) => {  }) );   

    }

    combined = Observable.forkJoin(observableBatch);

    combined.subscribe(
      finalResponse => {

        let msg = decodeURIComponent(params.get('assessmentId')).split("|").length == 1 ? "Project name " : "Project names ";
        let alertMetaData = {
          "name": "deleteproject",
          "title" : "Delete Project Success",
          "type":"SUCCESS",
          "content": msg + decodeURIComponent(params.get('assessmentId')).split("|").join(", ") + " deleted successfully."       
        }    
        this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
        this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");

      },
    error => {
      console.log("Delete error Response", error);
      let alertMetaData = {
        "name": "deleteproject",
        "title" : "Delete Project Failure",
        "type":"DANGER",
        "content": "Error during deleting some project"     
      }    
      this.transactionalAssessmentService.smartBridgeService("generateAlertMessageService", alertMetaData);
      this.transactionalAssessmentService.backtoSSUE("CFTAssessment:Projects");
    });

  }  


}