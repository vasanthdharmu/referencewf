import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'transactional-assessment-root',
  templateUrl: './transactional-assessment.template.html',
  styleUrls: ['./transactional-assessment.style.css']  
})
export class TransactionalAssessmentComponent {
  
  constructor(public router: Router) {
  
	
  } 
  
  ngOnInit() {	
	
	  
  }

}