import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule, JsonpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SmartbridgeClientAdapterModule } from "app/lib/partner/integration/angular/smartbridge-client-adapter";
import { TransactionalAssessmentService } from './services/transactional-assessment.service';

import { AuiModule } from 'aui/components/aui.module';

import { AgGridModule } from 'ag-grid-angular';
import { WorkflowModule, workflowApi } from '@ssue-ui/cisco-workflow';

import { TransactionalAssessmentRouting } from './transactional-assessment.routing';
import { CustomerCheckGuard } from './services/customer-check.service';
import { TransactionalAssessmentComponent } from './transactional-assessment.component';

import { DndListModule } from 'ngx-drag-and-drop-lists';

import { TransactionalSSUEComponent } from './ssue/transactional-ssue.component';
import { CustomerComponent } from './customermanager/customer.component';
import { ListTransactionalComponent } from './listtransactional/listtransactional.component';
import { DeleteCustomerLinkComponent } from './customermanager/deletecustomerlink.component';
import { InitiateTransactionalComponent } from './initiatetransactional/initiatetransactional.component';
import { SsidConfigurationComponent } from './ssidconfiguration/ssidconfiguration.component';
import { StatusLinkComponent } from './listtransactional/statuslink.component';
import { ProjectDetailsComponent } from './initiatetransactional/projectdetails/projectdetails.component';
import { DataSourceComponent } from './initiatetransactional/datasource/datasource.component';
import { ReportLinkComponent } from './listtransactional/reportlink.component';
import { DateFormatComponent } from './listtransactional/dateFormat.component';
import { DateFormatAuditComponent } from './auditlog/dateFormatAudit.component';
import { LogLinkComponent } from './listtransactional/loglink.component';

import { AuditLogComponent } from './auditlog/auditlog.component';
import { AuditNameLinkComponent } from './auditlog/auditnamelink.component';
import { ProjectStatusComponent } from './auditlog/projectstatus.component';
import { AuditLogDetailComponent } from './auditlog/auditlogdetail/auditlogdetail.component';
import { PlatformComponent } from './auditlog/platform.component';

@NgModule({
  imports: [
    CommonModule,
    TransactionalAssessmentRouting,
    HttpModule,
      FormsModule,
      ReactiveFormsModule,
      JsonpModule,
      AgGridModule.withComponents([
      StatusLinkComponent,
      DeleteCustomerLinkComponent,
      ReportLinkComponent,
      DateFormatComponent,
      LogLinkComponent,
      AuditNameLinkComponent,
      ProjectStatusComponent,
      PlatformComponent,
      DateFormatAuditComponent
      ]),
    AuiModule,
    SmartbridgeClientAdapterModule.forChild(),
    WorkflowModule,
    DndListModule
  ],
  declarations: [
    TransactionalAssessmentComponent,
    TransactionalSSUEComponent,
    CustomerComponent,
    StatusLinkComponent,
    ListTransactionalComponent,
    DeleteCustomerLinkComponent,
    InitiateTransactionalComponent,
    SsidConfigurationComponent,
    ProjectDetailsComponent,
    DataSourceComponent,
    ReportLinkComponent,
    DateFormatComponent,
    LogLinkComponent,
    AuditLogComponent,
    AuditNameLinkComponent,
    AuditLogDetailComponent,
    ProjectStatusComponent,
    PlatformComponent,
    DateFormatAuditComponent
  ],
  providers: [
    TransactionalAssessmentService,
    workflowApi,
    CustomerCheckGuard
  ],
  bootstrap: [ TransactionalAssessmentComponent ]
})
export class TransactionalAssessmentModule {
}