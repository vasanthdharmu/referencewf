import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TransactionalSSUEComponent } from './ssue/transactional-ssue.component';
import { TransactionalAssessmentComponent } from './transactional-assessment.component';
import { CustomerComponent } from './customermanager/customer.component';
import { CustomerCheckGuard } from './services/customer-check.service';
import { ListTransactionalComponent } from './listtransactional/listtransactional.component';
import { InitiateTransactionalComponent } from './initiatetransactional/initiatetransactional.component';

import { AuditLogComponent } from './auditlog/auditlog.component';
import { AuditLogDetailComponent } from './auditlog/auditlogdetail/auditlogdetail.component';

const routes: Routes = [
  {
	  path: '', component: TransactionalAssessmentComponent,
    children: [
      { path: 'customermanager', component: CustomerComponent  },
      { path: 'listtransactional', component: ListTransactionalComponent, canActivate: [CustomerCheckGuard] },
      { path: 'initiatetransactional', component: InitiateTransactionalComponent },
      { path: 'ssue', component: TransactionalSSUEComponent  },
      { path: 'auditlog', component: AuditLogComponent  , canActivate: [CustomerCheckGuard] },
      { path: 'auditlogdetail', component: AuditLogDetailComponent  }
    ]
  }
];

export const TransactionalAssessmentRouting: ModuleWithProviders = RouterModule.forChild(routes);
