import { Component, Input, Injectable, Injector, ElementRef, ViewContainerRef, ViewChild, Renderer } from '@angular/core';
import { Router } from '@angular/router';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';

import { FusionAlert } from 'aui/components/notification-alert/fusion-notification-alert.component';
import { AlertAnchorDirective } from 'aui/components/notification-alert/alertanchor.directive';

@Injectable()

@Component({
   selector: 'sopd-button',
   templateUrl: './sopdbutton.template.html',
   styleUrls: ['./sopdbutton.style.css'],
   entryComponents: [ FusionAlert ]
})
export class SopdButtonComponent{

  public workflowButtonObjet:any;
  public wizard:any;

  isSaveDisabled:boolean;
  isNextDisabled:boolean;
  isPreviousDisabled:boolean;

  @Input() workflowButtonMetaData:{};

  @ViewChild('saveBtn') saveButton;
  @ViewChild('nextBtn') nextButton;
  @ViewChild('previousBtn') previousButton;
  @ViewChild('cancelBtn') cancelButton;

  @ViewChild(AlertAnchorDirective) alertAnchor;
  @ViewChild('fusionalert') fusionalert:ElementRef;

  public showCancelButton;
  public showSaveButton;
  public showBackButton;
  public showNextButton;

  public loaderSaveButton;
  public loaderNextButton;
  constructor(public router: Router, public renderer : Renderer, public inj:Injector){
    this.wizard = this.inj.get(WorkflowManagerComponent);
  }
  ngOnInit() {
      this.workflowButtonObjet = this.workflowButtonMetaData;
      this.showNextButton = true;
      this.showCancelButton = this.workflowButtonObjet.showCancelButton;
      this.showSaveButton = this.workflowButtonObjet.showSaveButton;
      this.showBackButton = this.workflowButtonObjet.showBackButton;
  }
  public next(){
    this.wizard.next();
  }
  
  public cancel(){

    let fusionalert = this.fusionalert.nativeElement;

    let buttons =  [{
      label: "Yes",
    }, {
        label: "No"
    }];

    this.alertAnchor.createAlert(FusionAlert,"warning","Do you really want to Cancel?","",fusionalert, buttons);

  }

  onAlertButtonClick(event){

          let target = event.target || event.srcElement || event.currentTarget;

         switch(target.innerHTML){

          case "Yes":                 
                parent.window.top.postMessage({'message':'lnpJump','data':{'lnpResourceId': 'CAEntitlement:SSUE:LNPs:CFAssessment:Projects',
                  'refresh': true
                  }
                 },'*');                  
                break;
          case "No":
              break;

        }

  }

  public previous(){
    this.wizard.previous();
  }
  public save() {
    this.wizard.save();
  }

  public setEnabled(element){

        switch(element) {
          case "saveButton":
            this.saveButton.setEnabled();
            this.isSaveDisabled =false;
            break;
          case "nextButton":
            this.nextButton.setEnabled();
            this.isNextDisabled =false;
            break;
          case "previousButton":
            this.previousButton.setEnabled();
            this.isPreviousDisabled =false;
            break;
        }

   }

  public setDisabled(element){

    switch(element) {
      case "saveButton":
        //this.renderer.setElementAttribute(this.saveButton.nativeElement, "disabled", "true");
        this.saveButton.setDisabled();
        this.isSaveDisabled =true;
        break;
      case "nextButton":
        this.nextButton.setDisabled();
        this.isNextDisabled =true;
        break;
      case "previousButton":
        this.previousButton.setDisabled();
         this.isPreviousDisabled =true;
        break;
    }

  }

  public setLoaderEnabled(element){

        switch(element) {
          case "saveButton":
            this.showSaveButton = false;
            this.loaderSaveButton = true;
            break;
          case "nextButton":
            this.showNextButton = false;
            this.loaderNextButton = true;
            break;
        }

    }

   public setLoaderDisabled(element){

        switch(element) {
          case "saveButton":
            this.showSaveButton = true;
            this.loaderSaveButton = false;
            break;
          case "nextButton":
            this.showNextButton = true;
            this.loaderNextButton = false;
            break;
        }

    }

}
