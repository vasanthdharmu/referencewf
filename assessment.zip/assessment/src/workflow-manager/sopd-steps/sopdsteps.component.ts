import { Component, Input, Injectable, Injector, ElementRef, ViewContainerRef, ViewChild } from '@angular/core';

import{ WorkflowManagerComponent } from 'workflow-manager/sopd-workflow/workflowmanager.component';

@Injectable()

@Component({
   selector: 'sopd-steps',
   templateUrl: './sopdsteps.template.html',
   styleUrls: ['./sopdsteps.style.css'] 
})
export class SopdStepsComponent{

  public workflowStepsObjet:any; 
  public wizard:any;
  public isOpen:boolean;

  @Input() workflowStepsMetaData:{};

  constructor(public inj:Injector){
    this.wizard = this.inj.get(WorkflowManagerComponent);
    this.isOpen = true;
  }

  ngOnInit() {
      this.workflowStepsObjet = this.workflowStepsMetaData;
  }

  public setClasses(status) {
    let obj;
    if(status == 'active'){
      obj =  {active:true};
      return obj;
    }
     if(status == 'visited'){
      obj =  {visited:true};
      return obj;
    }
    else{
      obj =  {'not-active':false};
      return obj;
    }
   
  }

  public selectStepper(id, event){
    this.wizard.selectStepper(id, event);
  }

  toggleSteps(){
    
    if (this.isOpen) {
      this.isOpen = false;
    }else{
      this.isOpen = true;
    }

  }
  
  
}