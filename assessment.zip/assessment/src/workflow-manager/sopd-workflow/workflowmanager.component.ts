import {Component, Input, Output, Injectable, Injector, ElementRef, Attribute, ViewContainerRef, ViewChild, ComponentFactoryResolver} from '@angular/core';

import{ SopdButtonComponent } from 'workflow-manager/sopd-button/sopdbutton.component';

@Injectable()

@Component({
   selector: 'sopd-workflow',
   templateUrl: './workflowmanager.template.html',
   styleUrls: ['./workflowmanager.style.css'] 
})

export class WorkflowManagerComponent{
	
public workflowStepObject:any;
public workflowStepObjectLength:number;
public workflowIndex: number= 0;

public workflowButtonMetaData:any;
public workflowStepsMetaData:any;

public elementRef:any;
public viewContainerRef:any;
public currentFactory:any;
public factoryObject:any;
public comInstance:any = [];

public showSaveButton: boolean = false; 

@Input() workflowMetaData:any;

@ViewChild('container', {read: ViewContainerRef}) target;

@ViewChild(SopdButtonComponent) sopdButtonComponent: SopdButtonComponent;

   constructor(viewContainerRef:ViewContainerRef, elementRef: ElementRef, public componentFactoryResolver: ComponentFactoryResolver){
     this.elementRef = elementRef;
     this.viewContainerRef = viewContainerRef;
     this.factoryObject = [];
   }

   ngOnInit() {

      this.factoryObject = [];

      this.workflowButtonMetaData = this.workflowMetaData.buttons;
      this.workflowStepsMetaData = this.workflowMetaData.steps;

      this.workflowStepObject = this.workflowMetaData.steps;
      this.workflowStepObjectLength = this.workflowStepObject.length;

      console.log("ngOnInit:this.workflowStepObject", this.workflowStepObject);

      for(let j = 0; j < this.workflowStepObjectLength; j++){
         this.getStepperContent(j);
       }
      this.clearStepper();

      this.setButtonLabels();

      this.sopdButtonComponent.setDisabled('previousButton');

      if( this.workflowStepObject[this.workflowIndex].validationMandatory ){
          this.sopdButtonComponent.setDisabled('saveButton');
          this.sopdButtonComponent.setDisabled('nextButton');
      }

   }

   public setButtonLabels(){

      this.workflowButtonMetaData.backButtonLabel = "Back";

      if(this.workflowButtonMetaData.appendStepTitle){
        this.workflowButtonMetaData.backButtonLabel = (this.workflowIndex > 0) ? "Back: " + this.workflowStepObject[this.workflowIndex - 1].title : "Back";
      }

      this.workflowButtonMetaData.nextButtonLabel = "Next";

      if(this.workflowButtonMetaData.appendStepTitle){
        this.workflowButtonMetaData.nextButtonLabel = (this.workflowStepObjectLength - 1 == this.workflowIndex) ? this.workflowButtonMetaData.lastStepButtonName : "Next:" + this.workflowStepObject[this.workflowIndex + 1].title;
      }

   }

   public getWorkflowIndex(){
     return this.workflowIndex + 1;
   }

   public getStepKey(){
    return this.workflowStepObject[this.workflowIndex].key;
  }

  public getStepTitle(){
    return this.workflowStepObject[this.workflowIndex].title;
  }

  public getRedirectURL(){
    return this.workflowButtonMetaData.redirectURL;
  }
  

  public next(){

    
    if( this.workflowStepObject[this.workflowIndex].validationMandatory ){
       if( !this.comInstance[this.workflowIndex].isValidated() ){
         return false;
       }
    }
    
    if( this.workflowIndex == this.workflowStepObjectLength - 1){
      
      this.comInstance[this.workflowIndex].onSubmit("nextButton");
      
    }

    if( this.workflowStepObject[this.workflowIndex].validationMandatory ){

              if( this.workflowIndex < this.workflowStepObjectLength - 1){
                
                this.workflowStepObject[this.workflowIndex].visited = 'visited';
                this.comInstance[this.workflowIndex].onNext();
                this.workflowIndex++;
                this.workflowStepObject[this.workflowIndex].visited = 'active';
                this.comInstance[this.workflowIndex].preLoad();
                this.sopdButtonComponent.setEnabled('nextButton');
                if( this.workflowStepObject[this.workflowIndex].validationMandatory ){ 
                      if( !this.comInstance[this.workflowIndex].isValidated() ){
                         this.sopdButtonComponent.setDisabled('saveButton');
                         this.sopdButtonComponent.setDisabled('nextButton');
                      }
                 }
                this.clearStepper();
                if( this.workflowIndex == this.workflowStepObjectLength - 1){
                  //this.sopdButtonComponent.setDisabled('nextButton');
                }                
                this.sopdButtonComponent.setEnabled('previousButton');

            }

    }else{
       if( this.workflowIndex < this.workflowStepObjectLength - 1){
          this.workflowStepObject[this.workflowIndex].visited = 'visited';
          this.comInstance[this.workflowIndex].onNext();          
          this.workflowIndex++;
          this.workflowStepObject[this.workflowIndex].visited = 'active';
          this.clearStepper();
          this.sopdButtonComponent.setEnabled('nextButton');
          this.comInstance[this.workflowIndex].preLoad();
          if( this.workflowStepObject[this.workflowIndex].validationMandatory ){
                if( !this.comInstance[this.workflowIndex].isValidated() ){
                   this.sopdButtonComponent.setDisabled('saveButton');
                   this.sopdButtonComponent.setDisabled('nextButton');
                }
           }

          if( this.workflowIndex == this.workflowStepObjectLength - 1){
            //this.sopdButtonComponent.setDisabled('nextButton');
          }
          this.sopdButtonComponent.setEnabled('previousButton');       
     }
   }

   this.setButtonLabels();

  }
  public previous(){
    
     if( this.workflowIndex > 0){
        //this.comInstance[this.workflowIndex].preLoad();
        this.workflowStepObject[this.workflowIndex].visited = 'visited';
        this.workflowIndex--;        
        this.workflowStepObject[this.workflowIndex].visited = 'active';
        this.comInstance[this.workflowIndex].preLoadOnBack();
        this.clearStepper();
        if(  this.workflowIndex == 0 ){
         this.sopdButtonComponent.setDisabled('previousButton');
        }
        this.sopdButtonComponent.setEnabled('nextButton');
        this.sopdButtonComponent.setEnabled('saveButton');
     }
     this.setButtonLabels();

   }
 public clearStepper(){
      var node = this.elementRef.nativeElement.querySelectorAll('.dynamic-component');
      for(let i = 0; i< node.length; i++){
         node[i].style.display = "none";
      }
      node[this.workflowIndex].style.display = "";
      //this.showSaveButton = this.workflowStepObject[this.workflowIndex].showSaveButton; 
 }
  public getStepperContent(index){

     const factory  = this.componentFactoryResolver.resolveComponentFactory(this.workflowStepObject[index].component);
     var instance = this.target.createComponent(factory).instance;
     this.comInstance.push(instance);

  }

  public selectStepper(index, e){
    
     var visitedIndex = 0;
     for(let i = 0; i< index; i++){
         if( this.workflowStepObject[i].validationMandatory ){
          if( !this.comInstance[i].isValidated() ){
            visitedIndex = i;
            break;
           }
         }
      }

    if( this.workflowStepObject[visitedIndex].validationMandatory ){

        if( index > 0 ){ 
           if( this.workflowStepObject[index - 1].visited == 'active' ){ 

             this.next();

           }
        }
       
       if( this.workflowStepObject[index].visited == 'visited' || this.workflowStepObject[index-1].visited == 'visited'){ 
         for(let i = 0; i< (this.workflowIndex + 1 ); i++){
            this.workflowStepObject[i].visited = 'visited';
         }
         this.workflowStepObject[index].visited = 'active';
         this.workflowIndex = index;
         this.clearStepper();

         if(  this.workflowIndex == 0 ){
           this.sopdButtonComponent.setDisabled('previousButton');
         }else{
           this.sopdButtonComponent.setEnabled('previousButton');
         }
           this.sopdButtonComponent.setEnabled('nextButton');
           if( this.workflowStepObject[this.workflowIndex].validationMandatory ){ 
                if( !this.comInstance[this.workflowIndex].isValidated() ){
                   this.sopdButtonComponent.setDisabled('nextButton');
                }
            }
         if( this.workflowIndex == this.workflowStepObjectLength - 1){
             this.sopdButtonComponent.setDisabled('nextButton');
          }         

       }

    }else{
            
     if( index > 0 ){
         if( this.workflowStepObject[index - 1].visited == 'active' ){
           this.next();
         }
       }
       
       if( this.workflowStepObject[index].visited == 'visited' || this.workflowStepObject[index-1].visited == 'visited'){

         for(let i = 0; i< (this.workflowIndex + 1); i++){
            this.workflowStepObject[i].visited = 'visited';
         }
         this.workflowStepObject[index].visited = 'active';
         this.workflowIndex = index;
         this.clearStepper();
         if(  this.workflowIndex == 0 ){
           this.sopdButtonComponent.setDisabled('previousButton');
         }else{
           this.sopdButtonComponent.setEnabled('previousButton');
         }
         if( this.workflowIndex == this.workflowStepObjectLength - 1){
             this.sopdButtonComponent.setDisabled('nextButton');
          }else{
           this.sopdButtonComponent.setEnabled('nextButton'); 
         }        

       }

    }

    this.setButtonLabels();

  }
  
  public save() {
      this.comInstance[this.workflowIndex].onSave();
  }

  public setDisabled(element){
    this.sopdButtonComponent.setDisabled(element);
  }

  public setEnabled(element){
    this.sopdButtonComponent.setEnabled(element);
  }

  public setLoaderEnabled(element){
    this.sopdButtonComponent.setLoaderEnabled(element);
  }

  public setLoaderDisabled(element){
    this.sopdButtonComponent.setLoaderDisabled(element);
  }

  
}