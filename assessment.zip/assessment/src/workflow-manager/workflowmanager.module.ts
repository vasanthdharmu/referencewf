import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AuiModule } from 'aui/components/aui.module';

import { WorkflowManagerComponent} from './sopd-workflow/workflowmanager.component';
import { SopdButtonComponent} from './sopd-button/sopdbutton.component';
import { SopdStepsComponent} from './sopd-steps/sopdsteps.component';

@NgModule({
  imports:      [
					CommonModule,
					FormsModule, 
					ReactiveFormsModule,
					AuiModule
				],
  declarations: [ 
					WorkflowManagerComponent,
					SopdButtonComponent,
					SopdStepsComponent			
				],
  exports:      [   
					WorkflowManagerComponent,
					SopdButtonComponent,
					SopdStepsComponent			
				]
})

export class WorkflowManagerModule { }