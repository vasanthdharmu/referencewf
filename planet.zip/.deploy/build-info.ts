declare const require: any;

export const buildInfo: BuildInfo = {
  timestamp: new Date().toLocaleString(),
  version: require('../package.json').version
};

export interface BuildInfo {
  timestamp: string;
  version: string;
}
