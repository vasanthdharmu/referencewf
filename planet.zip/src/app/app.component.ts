import { Component, HostListener, OnInit } from '@angular/core';
import { HeaderMenu } from 'sfg-ng-brand-components/model/header-menu.model';


declare const document: any;
declare const window: any;
@Component({
  selector: 'ppr-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  isScrolledBreakpoint = false;

  // exampleHeaderMenu: HeaderMenu = {
  //   links: []
  // };

  constructor() { }

  ngOnInit() {
    // this.exampleHeaderMenu.links = [
    //   { linkLabel: 'Overview', linkUrl: '/plannet/overview/803333' },
    //   { linkLabel: 'Assets', dropdownLinks: [
    //       { linkLabel: 'Balance Details', linkUrl: 'https://google.com' },
    //       { linkLabel: 'Transaction History', linkUrl: 'https://google.com' },
    //       { linkLabel: 'Forfeitures & Unallocated', linkUrl: 'https://google.com' },
    //       { linkLabel: 'Financial Activity Report', linkUrl: 'https://google.com' }
    //     ]
    //   },
    //   { linkLabel: 'Performance', dropdownLinks: [
    //       { linkLabel: 'Rate of Return', linkUrl: '/plannet/performance/ror/803333' },
    //       { linkLabel: 'Unit Value/Share', linkUrl: '/plannet/performance/unit-value/803333' }
    //     ]
    //   },
    //   { linkLabel: 'Plan Details', dropdownLinks: [
    //       { linkLabel: 'Dropdown 1', linkUrl: 'https://google.com' },
    //       { linkLabel: 'Dropdown 2', linkUrl: 'https://google.com' },
    //       { linkLabel: 'Dropdown 3', linkUrl: 'https://google.com' }
    //     ]
    //   },
    //   { linkLabel: 'Manage Plan', linkUrl: 'https://google.com' },
    //   { linkLabel: 'Employees', linkUrl: 'https://google.com' }
    // ];
  }
/*
  @HostListener('window:scroll', [])
  onWindowScroll($event: any) {
    if (window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop > 20) {
      this.isScrolledBreakpoint = true;
    } else {
      this.isScrolledBreakpoint = false;
    }
  }

  getMarginTop(displayNotification: boolean) {
    let height = 0;
    if (window.innerWidth >= 1199) {
      if (this.isScrolledBreakpoint) {
        height = -25;
      } else {
        height = 40;
      }
      return (displayNotification ? 100 : 0) + height + 'px';
    } else {
      return displayNotification ? '100px' : '0px';
    }
  }*/
}
