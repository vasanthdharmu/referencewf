import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { clientRoutes } from './app.routes';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDropdownModule, ModalModule } from 'ngx-bootstrap';
import { ResponsiveModule } from 'ng2-responsive';
import { CoreModule } from './core/core.module';
import {
  MatButtonModule, MatDialogModule, MatInputModule, MatProgressSpinnerModule,
  MatSelectModule, MatSliderModule
} from '@angular/material';
import { ComponentLibraryModule } from 'sfg-ng-brand-components';
// import { LocationStrategy, HashLocationStrategy } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatSliderModule,
    clientRoutes,
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
    ResponsiveModule,
    CoreModule,
    ComponentLibraryModule.forRoot()
  ],
  providers: [
    // { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
