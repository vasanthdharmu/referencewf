import { ModuleWithProviders } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { PlannetOverviewResolver } from './core/route-resolver/plannet-overview-resolver';

export const routes: Routes = [
  {
    path: 'plan-overview',
    loadChildren: './plannet-overview/plannet-overview.module#PlannetOverviewModule'
  },
  {
    path: 'plan-performance',
    loadChildren: './plannet-performance/plannet-performance.module#PlannetPerformanceModule'
  },
  {
    path: 'plan-investment',
    loadChildren: './plannet-investment/plannet-investment.module#PlannetInvestmentModule'
  },
  {
    path: 'plan-transactions',
    loadChildren: './plannet-transactions/plannet-transactions.module#PlannetTransactionsModule'
  },
  {
    path: '**',
    redirectTo: 'plan-overview'
  },
];

export const clientRoutes: ModuleWithProviders = RouterModule.forRoot(routes, {
  preloadingStrategy: PreloadAllModules
});
