import { Injectable } from '@angular/core';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { ApiRelativePath } from '../../shared/interfaces/ApiRelativePath';
import { HttpClient } from '@angular/common/http';
import { CachedApiResponse } from '../../shared/interfaces/CachedApiResponse';
import { Observable } from 'rxjs/Observable';
import { environment } from '@environment';

export const RP_API: ApiRelativePath[] = [
  {
    ApiName: rpApiNames.PlanNetPlanSummary,
    RelativeUrl: '/plan/{0}/summary',
    MockUrl: '/assets/default/rp_api/plan/{0}/summary.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanOverview,
    RelativeUrl: '/plan/{0}/overview',
    MockUrl: '/assets/default/rp_api/plan/{0}/overview.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanPerformanceRor,
    RelativeUrl: '/plan/{0}/performance-ror',
    MockUrl: '/assets/default/rp_api/plan/{0}/performance_ror.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanPerformanceUnitValue,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/performance-unit-share', // 0:plan_id; 1: optional start (yyyymmdd); 2: optional end (yyyymmdd)
    MockUrl: '/assets/default/rp_api/plan/{0}/performance_unit_value.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanPerformanceUnitValueWithDates,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/performance-unit-share?beginDate={1}&endDate={2}', // 0:plan_id; 1: optional start (yyyymmdd); 2: optional end (yyyymmdd)
    MockUrl: '/assets/default/rp_api/plan/{0}/performance_unit_value.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanInvestmentBalance,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/balance-details', // 0:plan_id;
    MockUrl: '/assets/default/rp_api/plan/{0}/investment_balance.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanInvestmentBalanceWithDates,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/balance-details?beginDate={1}&endDate={2}', // 0:plan_id; 1: optional start (yyyymmdd); 2: optional end (yyyymmdd)
    MockUrl: '/assets/default/rp_api/plan/{0}/investment_balance.json'
  },
  {
    ApiName: rpApiNames.PlanNetRedemptionFees,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/redemption-fees', // 0:plan_id;
    MockUrl: '/assets/default/rp_api/plan/{0}/redemption-fees.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanTransactionDeposits,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/transaction-deposits', // 0:plan_id;
    MockUrl: '/assets/default/rp_api/plan/{0}/transaction_deposits.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanTransactionDistribution,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/transaction-distribution', // 0:plan_id;
    MockUrl: '/assets/default/rp_api/plan/{0}/transaction_distribution.json'
  },
  {
    ApiName: rpApiNames.PlanNetPlanTransactionLoan,
    // tslint:disable-next-line:max-line-length
    RelativeUrl: '/plan/{0}/transaction-loan', // 0:plan_id;
    MockUrl: '/assets/default/rp_api/plan/{0}/transaction_loan.json'
  }  
]

@Injectable()
export class ApiService {
  PlanId: string;
  private cachedResponses: CachedApiResponse[] = [];

  constructor(private httpClient: HttpClient) { }

  getRpData(apiName: string, useCache: boolean, ...params: any[]): Observable<any> {
    const api = RP_API.find(
      item => {
        return (item.ApiName === apiName);
      }
    )
    let url: string;
    if (api) {
      if (environment.rpApiMock === true) {
        url = environment.mockPath.concat(api.MockUrl);
      } else {
        url = environment.rpApiBaseUrl.concat(api.RelativeUrl);
      }
    }
    if (params && params.length > 0) {
      let i = 0;
      params.forEach(param => {
        const searchString = '{' + i + '}';
        ++i;
        const encodedParam = encodeURIComponent(param);
        url = url.replace(searchString, encodedParam);
      });
    }

    return this.getRpApiData(url, useCache);
  }

  private getRpApiData(url: string, useCache: boolean): Observable<any> {
    const found = this.cachedResponses.find(
      item => {
        return (item.Url === url);
      }
    )
    if (useCache === true) {
      if (found) {
        return Observable.of(found.CachedReponse);
      }
    }

    // Add a timestamp to break the browser cache for IE.
    let newUrl: string = url;
    if ((useCache === false) && (environment.rpApiMock === false)) {
      if (url.indexOf('?') < 0) {
        newUrl = url.concat('?t=').concat((new Date()).getTime().toString(10));
      } else {
        newUrl = url.concat('&t=').concat((new Date()).getTime().toString(10));
      }
    }

    return this.httpClient.get(newUrl)
      .do(response => {
        // Delete the cached item if it was found.
        if (found) {
          const index: number = this.cachedResponses.indexOf(found);
          this.cachedResponses = this.cachedResponses.splice(index, 1);
        }
        if (useCache === true) {
          this.cachedResponses.push({
            Url: url,
            CachedReponse: response
          });
        }
        return response;
      });
  }

}
