import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ApiRelativePath } from '../../shared/interfaces/ApiRelativePath';
import { CachedApiResponse } from '../../shared/interfaces/CachedApiResponse';
import { contentApiNames } from '../../shared/constants/contentApiNames';
import { environment } from '@environment';
import { HttpClient } from '@angular/common/http';

export const CONTENT_API: ApiRelativePath[] = [
  {
    ApiName: contentApiNames.PlanNetGlobalContent,
    RelativeUrl: '/int/PlanNetGlobalContent',
    MockUrl: '/assets/default/cms/PlanNetGlobalContent.json'
  },
  {
    ApiName: contentApiNames.PlanNetOverview,
    RelativeUrl: '/int/PlanNetOverview',
    MockUrl: '/assets/default/cms/PlanNetOverview.json'
  },
  {
    ApiName: contentApiNames.RpPromoList,
    RelativeUrl: '/int/RpPromoList',
    MockUrl: '/assets/default/cms/RpPromoList.json'
  },
  {
    ApiName: contentApiNames.PlanNetRedemptionFeeContent,
    RelativeUrl: '/int/RedemptionFeeContent',
    MockUrl: '/assets/default/cms/RedemptionFeeContent.json'
  }
]

@Injectable()
export class ContentService {
  private cachedResponses: CachedApiResponse[] = [];

  constructor(private httpClient: HttpClient) { }

  getContent(apiName: string): Observable<any> {
    const api = CONTENT_API.find(
      item => {
        return (item.ApiName === apiName);
      }
    )
    let url: string;
    if (api) {
      if (environment.contentMock === true) {
        url = environment.mockPath.concat(api.MockUrl);
      } else {
        url = environment.contentBaseUrl.concat(api.RelativeUrl);
      }
    }
    return this.getCmsContent(url);
  }

  private getCmsContent(url: string): Observable<any> {
    const found = this.cachedResponses.find(
      item => {
        return (item.Url === url);
      }
    )
    if (found) {
      return Observable.of(found.CachedReponse);
    }
    return this.httpClient.get(url)
      .map(response => {
        this.cachedResponses.push({
          Url: url,
          CachedReponse: response
        });
        return response;
      });
  }
}
