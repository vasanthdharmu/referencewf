import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ContentService } from './content/content-service';
import { ApiService } from './api/api-service';
import { PlannetOverviewResolver } from './route-resolver/plannet-overview-resolver';
import { RouteHistoryService } from './route-history/route-history.service';

// This module should only have services, and no exportable components.
@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    HttpClientModule
  ],
  declarations: [
  ],
  providers: [
    ContentService,
    ApiService,
    PlannetOverviewResolver,
    RouteHistoryService
  ]
})
export class CoreModule {
}
