import { ReflectiveInjector } from '@angular/core';
import { InjectionToken } from '@angular/core';

export const JQ_TOKEN = new InjectionToken<string>('jQuery');

export function jQueryFactory() {
  return window['jQuery'];
}

export const JQUERY_PROVIDER = [
  { provide: JQ_TOKEN, useFactory: jQueryFactory }
];
