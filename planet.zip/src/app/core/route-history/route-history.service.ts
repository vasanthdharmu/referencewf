import { Injectable, OnInit } from '@angular/core';
import { Router, RoutesRecognized } from '@angular/router';

@Injectable()
export class RouteHistoryService implements OnInit {
  currentRoute: string;
  previousRoute: string;

  constructor(private router: Router) {
    this.currentRoute = router.url;
    this.router.events
    .filter(e => e instanceof RoutesRecognized)
    .map(e => <RoutesRecognized> e)
    .subscribe((e) => {
      this.previousRoute = this.currentRoute;
      this.currentRoute = e.state.url;
    });
  }

  ngOnInit(): void {
  }

  goBack(): void {
    if (this.previousRoute) {
      this.router.navigate([this.previousRoute]);
    } else {
      this.router.navigate(['/plan-overview']);
    }
  }
}
