import { TestBed, inject } from '@angular/core/testing';

import { PlannetOverviewResolver } from './plannet-overview-resolver';

describe('Plannet.Overview.ResolverService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PlannetOverviewResolver]
    });
  });

  it('should be created', inject([PlannetOverviewResolver], (service: PlannetOverviewResolver) => {
    expect(service).toBeTruthy();
  }));
});
