import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { ApiService } from '../api/api-service';
import { ContentService } from '../content/content-service';
import { contentApiNames } from '../../shared/constants/contentApiNames';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class PlannetOverviewResolver implements Resolve<any> {

  constructor(private apiService: ApiService, private contentService: ContentService) { }

  resolve(route: ActivatedRouteSnapshot) {
    const plannetGlobalContentSource = this.contentService.getContent(contentApiNames.PlanNetGlobalContent);
    const plannetOverviewContentSource = this.contentService.getContent(contentApiNames.PlanNetOverview);
    const promoListSource = this.contentService.getContent(contentApiNames.RpPromoList);
    const planId = route.params['plan_id'];
    const cacheAPI = true;
    const rpApiSource = this.apiService.getRpData(rpApiNames.PlanNetPlanOverview, cacheAPI, planId);
    const source = Observable.combineLatest(
      plannetGlobalContentSource,
      plannetOverviewContentSource,
      promoListSource,
      rpApiSource,
      (source1, source2, source3, source4) => {
        return {
          GlobalContent: source1,
          PageContent: source2,
          PromoList: source3,
          ApiData: source4
        }
      }
    );
    return source;
  }
}
