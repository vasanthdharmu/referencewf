import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { EnrollPlanPage } from './enroll-plan.page';
import { EnrollPlanRouting } from './enroll-plan.routing';

@NgModule({
  declarations: [
    EnrollPlanPage
  ],
  imports: [
    CommonModule,
    SharedModule,
    EnrollPlanRouting
  ],
  providers: []
})
export class EnrollPlanModule { }
