import {Component} from '@angular/core';

@Component({
  selector: 'enroll-plan',
  templateUrl: './enroll-plan.page.html'
})
export class EnrollPlanPage {

  sessionId: string;

}
