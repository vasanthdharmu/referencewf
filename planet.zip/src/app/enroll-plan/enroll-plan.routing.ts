import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EnrollPlanPage } from './enroll-plan.page';

const routes: Routes = [
  {
    path: '',
    component: EnrollPlanPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EnrollPlanRouting {
}
