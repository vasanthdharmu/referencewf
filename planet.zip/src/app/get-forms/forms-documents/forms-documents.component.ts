import { Component } from '@angular/core';

@Component({
  selector: 'forms-documents',
  templateUrl: './forms-documents.component.html'
})
export class FormsDocumentsComponent {

}
