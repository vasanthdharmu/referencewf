import { Component, EventEmitter, Output } from '@angular/core';
import * as _ from 'lodash';
@Component({
  selector: 'forms-forms',
  templateUrl: './forms-forms.component.html'
})
export class FormsFormsComponent {
  _ = _;
  formData: any[] = [
    {
    Name: 'Investing Form',
    Download: [{
      Language: 'English',
      Url: 'https://stancorp.sharepoint.com/:b:/s/pnetpsc/ERq12A7g2m5KvAHhci8MyW8Bpzcm1Zhe6YlXtbaJJ_Rixg?e=MXULZh'
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, {
    Name: 'Plan Hightlight',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Enrollment Brochure',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Application for Rollover',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, {
    Name: 'Savings Form',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Mainspring Managed Savings Form',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, {
    Name: 'Beneficiary Designation Form',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Special Tax Notice Regarding Plan Payments',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Roth Special Tax Notice Regarding Plan Payments',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, {
    Name: 'Q A for Distributions',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Long Request Form',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Withdrawal Request Form',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: true,
    Content: '',
    Show: false
  }, {
    Name: 'Distribution Options for Your Requirement Plan',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, {
    Name: 'Electronic Funds Transfer Request Form (Payments from account only)',
    Download: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Mail: [{
      Language: 'English',
      Url: ''
    }, {
      Language: 'Spanish',
      Url: ''
    }],
    Order: false,
    Content: '',
    Show: false
  }, ];
  @Output() sendMail: EventEmitter<any> = new EventEmitter();
  @Output() documentUnavaibale: EventEmitter<any> = new EventEmitter();
}
