import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { GetFormsPage } from './get-forms.page';
import { GetFormsRouting } from './get-forms.routing';
import { FormsDocumentsComponent } from './forms-documents/forms-documents.component';
import { FormsFormsComponent } from './forms-forms/forms-forms.component';

@NgModule({
  declarations: [
    GetFormsPage,
    FormsDocumentsComponent,
    FormsFormsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    GetFormsRouting
  ],
  providers: []
})
export class GetFormsModule { }
