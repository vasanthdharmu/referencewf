import { Component, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'get-forms',
  templateUrl: './get-forms.page.html',
  styleUrls: ['./get-forms.page.css']
})
export class GetFormsPage {
  selectedView = 'All';
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  recepientEmailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  constructor() {

  }

}
