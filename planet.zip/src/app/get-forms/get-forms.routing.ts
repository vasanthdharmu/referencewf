import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GetFormsPage } from './get-forms.page';

const routes: Routes = [
  {
    path: '',
    component: GetFormsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GetFormsRouting {
}
