export const base = {
  appTitle: 'PlanNet ', //
  logoImageStandardUrl: '/assets/images/standard_web.gif ', //
  logoImageSkyRankerUrl: '/assets/images/skyranker_web.gif ', //
  planSummarysvg: '/assets/images/planSummary.svg ', //  Plan Summary
  empAccountssvg: '/assets/images/empAccountssvg.svg ', // Employee Accounts
  financeReports: '/assets/images/financeReports.svg ', // Financial Reports
  authorizeLoanssvg: '/assets/images/authorizeLoans.svg ', // Authorize Loans
  authorizeDistsvg: '/assets/images/authorizeDist.svg ', // Authorize Distribution
  participantReportsvg: '/assets/images/participantReport.svg ', // Participant Reports
  getFormsvg: '/assets/images/getForm.svg ', // Get Forms
  contactssvg: '/assets/images/contacts.svg ', // View All Contacts
  promoPorchSwing: '/assets/images/Desktop-porch-swing.jpg ', // Provide HTML Format promoPorchSwing
  promoDriving: '/assets/images/Desktop-mature-couple-driving.jpg ', // Provide HTML Format promoDriving
  promoRetiredCouple: '/assets/images/Desktop-retired-couple.jpg ', // Provide HTML Format promoRetiredCouples
};


