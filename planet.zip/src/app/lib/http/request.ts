import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';
import * as _ from 'lodash';

import { environment } from '../../../environments/environment';

const ERROR_MSG = '500 Internal Server Error';

export class Request {
  private static token = '';
  private http: HttpClient;
  private options: Object;
  private optionsHeader: Object;

  // private static buildRequestOptions() {
  //   const headers = new Headers();
  //   const options = {
  //     headers
  //   };
  //   return options;
  // }

  // private static buildRequestWithHeader() {
  //   const headers = Request.buildHeaders();
  //   const options = {
  //     headers,
  //     withCredentials: true
  //   };
  //   return options;
  // }
  //
  // // tslint:disable-next-line:member-ordering
  // private static buildHeaders() {
  //   return new HttpHeaders({
  //     'Content-Type': 'application/x-www-form-urlencoded'
  //   });
  // }

  // tslint:disable-next-line:member-ordering
  private static getUrl(path: string): string {

    return environment.apiPrefix.concat(path);

  }

  constructor(http: HttpClient) {
    this.http = http;
    // this.options = Request.buildRequestOptions();
    // this.optionsHeader = Request.buildRequestWithHeader();
  }

  httpGet(path: string): Observable<any> {
    return this.http.get(Request.getUrl(path))
      .pipe(
        map(res => res),
        catchError(this.handleError)
      );
  }

  // httpPost(path: string, data: any, formData = false): Observable<any> {
  //   const header = formData ?  this.options : this.optionsHeader;
  //   return this.http.post(Request.getUrl(path), data, header)
  //     .pipe(
  //       map(res => res),
  //       catchError(this.handleError)
  //     );
  // }

  private extractData(response: Response): any {
    const body = response.json();
    return body || {};
  }

  private handleError(error: Response): any {
    return Observable.throw(error || ERROR_MSG);
  }
}
