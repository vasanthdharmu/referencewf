import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetInvestmentBalanceComponent } from './plannet-investment-balance.component';

describe('PlannetInvestmentBalanceComponent', () => {
  let component: PlannetInvestmentBalanceComponent;
  let fixture: ComponentFixture<PlannetInvestmentBalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetInvestmentBalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetInvestmentBalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Test if a fund is a SDBA fund
  it('should be SDBA fund', () => {
    expect(component.isSdOrPc('SD')).toBeTruthy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
