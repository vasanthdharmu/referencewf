import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetInvestmentUnitValueComponent } from './plannet-investment-unit-value.component';

describe('PlannetInvestmentUnitValueComponent', () => {
  let component: PlannetInvestmentUnitValueComponent;
  let fixture: ComponentFixture<PlannetInvestmentUnitValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetInvestmentUnitValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetInvestmentUnitValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
