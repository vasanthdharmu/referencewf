import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { PlannetInvestmentBalanceComponent } from './plannet-investment-balance/plannet-investment-balance.component';
import { PlannetInvestmentUnitValueComponent } from './plannet-investment-unit-value/plannet-investment-unit-value.component';
import { SharedModule } from '../shared/shared.module';
import { PlannetInvestmentRouting } from './plannet-investment.routing';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NegativeNumberPipe } from '../shared/pipes/negative-number.pipe';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PlannetInvestmentRouting,
    TooltipModule.forRoot()
  ],
  declarations: [
    PlannetInvestmentBalanceComponent,
    PlannetInvestmentUnitValueComponent
  ],
  providers: [DatePipe, DecimalPipe, CurrencyPipe, NegativeNumberPipe]
})
export class PlannetInvestmentModule { }
