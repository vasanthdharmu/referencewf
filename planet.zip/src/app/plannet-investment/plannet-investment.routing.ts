import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlannetInvestmentBalanceComponent } from './plannet-investment-balance/plannet-investment-balance.component';
import { PlannetInvestmentUnitValueComponent } from './plannet-investment-unit-value/plannet-investment-unit-value.component';

const routes: Routes = [
  {
    path: 'unit-value',
    component: PlannetInvestmentUnitValueComponent
  },
  {
    path: 'balance',
    component: PlannetInvestmentBalanceComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlannetInvestmentRouting {
}
