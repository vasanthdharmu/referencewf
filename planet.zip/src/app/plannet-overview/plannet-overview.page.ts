// Code for the actual api.

import { Component, OnInit } from '@angular/core';
import { ApiService } from '../core/api/api-service';
import { Router } from '@angular/router';
import { IDateRangeConfig } from '../shared/interfaces/IDateRangeConfig';

@Component({
  selector: 'ppr-overview',
  templateUrl: './plannet-overview.page.html',
  styleUrls: ['./plannet-overview.page.css']
})
export class PlannetOverviewPage implements OnInit {
  PlanId: string = '';
  ErrorMessage: string = '';

  constructor(private router: Router, private apiService: ApiService) {
  }

  ngOnInit(): void {
    this.PlanId = this.apiService.PlanId;
  }

  PerformanceROR() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-performance/ror']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  PerformanceUnitValue() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-performance/unit-value']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  InvestmentBalance() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-investment/balance']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  InvestmentUnitValue() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-investment/unit-value']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  TransactionsDeposits() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-transactions/deposits']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }
  
  TransactionsDistribution() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-transactions/distributions']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  TransactionsLoan() {
    this.ErrorMessage = '';
    if (this.validatePlanId(this.PlanId)) {
      this.apiService.PlanId = this.PlanId;
      this.router.navigate(['/plan-transactions/loans']);
    } else {
      this.ErrorMessage = 'Please provide a valid 5-digit plan number.'
    }
  }

  validatePlanId(value): boolean {
    const planId = Number(value);
    return (isNaN(planId) === false);
  }

}
