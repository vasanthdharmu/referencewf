import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlannetOverviewPage } from './plannet-overview.page';

const routes: Routes = [
  {
    path: '',
    component: PlannetOverviewPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlannetOverviewRouting {
}
