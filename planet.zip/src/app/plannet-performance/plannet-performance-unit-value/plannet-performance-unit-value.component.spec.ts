import { async, ComponentFixture, TestBed, inject, tick } from '@angular/core/testing';
import { PlannetPerformanceUnitValueComponent } from './plannet-performance-unit-value.component';
import { SharedModule } from '../../shared/shared.module';
import { ApiService } from '../../core/api/api-service';
import { Observable } from 'rxjs/Observable';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { of } from 'rxjs/observable/of';
import { contentApiNames } from '../../shared/constants/contentApiNames';
import { ContentService } from '../../core/content/content-service';
import { DecimalPipe, DatePipe, CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { BsDatepickerModule, BsDropdownModule, TooltipModule } from 'ngx-bootstrap';
import { PlannetPerformanceRouting } from '../plannet-performance.routing';
import { PlannetPerformanceComponent } from '../plannet-performance/plannet-performance.component';
import { Router, NavigationExtras } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { RouteHistoryService } from '../../core/route-history/route-history.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Subscription } from 'rxjs/Subscription';
import { DebugElement } from '@angular/core';
import { IPlanSummary } from '../../shared/interfaces/IPlanSummary';
import { NegativeNumberPipe } from '../../shared/pipes/negative-number.pipe';

class MockApiService {
  PlanId: string = '806644';

  // tslint:disable-next-line:max-line-length:quotemark:whitespace
  getRpData(apiName: string, useCache: boolean, ...params: any[]): Observable<any> {
    if (apiName === rpApiNames.PlanNetPlanSummary) {
      return of(
        { 'data':
          { 'planId': '806644',
            'planCategory': 'DC',
            'legalPlanName': 'The Bike Gallery 401(k) & Profit Sharing Plan',
            'contractEffectiveDate': '1994-01-01',
            'informationAsOfDate': '2017-03-09',
            'productTypeCd': 'UNR'
          }
        }
      );
    } else if (apiName === rpApiNames.PlanNetPlanPerformanceUnitValue) {
      return of(
        { 'performanceUnitorShare':
          { 'planId': '806644',
            'startDate': '2017-01-01',
            'endDate': '2017-03-09',
            'validStartDate': '2016-04-01',
            'validEndDate': '2017-03-09',
            'funds': [
              { 'fundName': 'Vanguard Federal Mny Mkt Inv',
                'ticker': 'VMFXX',
                'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
                'investmentFundId': 'PC',
                'inPortfolio': 'Y',
                'unitorShareValues':
                { 'beginValue': 1,
                  'endValue': 1,
                  'percentChange': 0}
              },
              { 'fundName': 'PIMCO Real Return Instl',
                'ticker': 'PRRIX',
                'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
                'investmentFundId': '1D',
                'inPortfolio': 'N',
                'unitorShareValues':
                { 'beginValue': 10.92,
                  'endValue': 10.91,
                  'percentChange': -0.09
                }
              },
              { 'fundName': 'Vanguard S-T Bond Index Adm',
                'ticker': 'VBIRX',
                'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
                'investmentFundId': '2F',
                'inPortfolio': 'N',
                'unitorShareValues':
                { 'beginValue': 10.43,
                  'endValue': 10.39,
                  'percentChange': -0.38
                }
              }]}}
      );
    }
  }
}

class MockRouteHistoryService {
  goBack() { }
}

export class MockContentService {
  getContent(apiName: string): Observable<any> {
    if (apiName === contentApiNames.PlanNetRedemptionFeeContent) {
      return of(
        {
          'Summary': 'This fund is subject to a redemption fee.',
          // tslint:disable-next-line:max-line-length
          'Text': '<p>A redemption fee is imposed by certain investment funds if shares are redeemed before the end of a specified holding period. The redemption fee is collected by The Standard on the investment fund\'s behalf and paid to the fund company.</p><p>The fee shown in the table will apply to shares sold before the end of the holding period.</p>'
        }
      );
    }
  }
}

fdescribe('PlannetPerformanceUnitValueComponent', () => {
  let component: PlannetPerformanceUnitValueComponent;
  let fixture: ComponentFixture<PlannetPerformanceUnitValueComponent>;
  // tslint:disable-next-line:prefer-const
  let dropdownLabel: any;
  // let dateRangeInput: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetPerformanceComponent, PlannetPerformanceUnitValueComponent],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        SharedModule,
        PlannetPerformanceRouting,
        TooltipModule.forRoot() ],
      providers: [
        { provide: ApiService, useClass: MockApiService },
        { provide: ContentService, useClass: MockContentService },
        { provide: RouteHistoryService, useClass: MockRouteHistoryService },
        DatePipe, DecimalPipe, NegativeNumberPipe
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetPerformanceUnitValueComponent);
    component = fixture.componentInstance;
    dropdownLabel = fixture.debugElement.query(By.css('#ViewByButton')).nativeElement;
    // dateRangeInput = fixture.debugElement.query(By.css('#dateRange')).nativeElement;
    fixture.detectChanges();

  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  // it('should return true for GA', () => {
  //   component.apiPlanSummaryData = null;
  //   expect(component.isGa()).toBeTruthy();
  //   component.apiPlanSummaryData = {
  //     'planId': '806644',
  //     'planCategory': 'DC',
  //     'legalPlanName': 'The Bike Gallery 401(k) & Profit Sharing Plan',
  //     'contractEffectiveDate': '1994-01-01',
  //     'informationAsOfDate': '2017-03-09',
  //     'productTypeCd': 'UNR'
  //   };
  //   expect(component.isGa()).toBeTruthy();
  // });

  // it('should return false for GA', () => {
  //   component.apiPlanSummaryData.productTypeCd = 'NAV';
  //   expect(component.isGa()).toBeFalsy();
  // });

  // it('should have reportName "Share Values"', () => {
  //   component.apiPlanSummaryData.productTypeCd = 'NAV';
  //   component.setReportName();
  //   expect(component.reportName).toBe('Share Values');
  // });

  // it('should unsubscribe', () => {
  //   (<any>component).subscriptions = new Subscription();
  //   component.unsubscribe();
  //   expect((<any>component).subscriptions).toBe(null);
  // });

  // it('should go back to old route',
  //   inject([RouteHistoryService], (routeHistoryService: RouteHistoryService) => {
  //     component.goBack = true;
  //     (<any>component).subscriptions = null;
  //     const goBackSpy = spyOn(routeHistoryService, 'goBack');
  //     component.cancelFetching('closed');
  //     expect(goBackSpy.calls.count()).toBe(1);
  //     expect(component.goBack).toBeFalsy();
  //   })
  // );

  // it('should not go back to old route',
  //   inject([RouteHistoryService], (routeHistoryService: RouteHistoryService) => {
  //     component.goBack = true;
  //     (<any>component).subscriptions = null;
  //     const goBackSpy = spyOn(routeHistoryService, 'goBack');
  //     component.cancelFetching('');
  //     expect(goBackSpy.calls.count()).toBe(0);
  //   })
  // );

  // it('should generateReport on enter key', () => {
  //   const generateReportSpy = spyOn(component, 'generateReport').and.callFake(() => { });
  //   component.filterKeyEnter(dateRangeInput);
  //   expect(generateReportSpy.calls.count()).toBe(1);
  // });

  // it('should navigate to Rate of Return',
  //   inject([Router], (router: Router) => {
  //     const routerSpy = spyOn(router, 'navigate').and.callFake((route) => { });
  //     component.SelectedViewBy = 'Rate of Return';
  //     const routerArguments = routerSpy.calls.first().args[0];
  //     expect(routerArguments[0]).toEqual('/plan-performance/ror');
  //   })
  // );

  // it('should sort', () => {
  //   const sortFundsSpy = spyOn(component, 'sortFunds').and.callFake(() => { });
  //   component.sort('fundName');
  //   expect(component.sortedColumn).toEqual('fundName');
  //   expect(sortFundsSpy.calls.count()).toBe(1);
  // });

  // it('should apply sort', () => {
  //   const sortFundsSpy = spyOn(component, 'sortFunds').and.callFake((column) => { });
  //   component.sortedColumn = 'fundName';
  //   component.applySort();
  //   expect(sortFundsSpy.calls.first().args[0]).toEqual('fundName');
  // });

  // it('should not apply sort', () => {
  //   const sortFundsSpy = spyOn(component, 'sortFunds').and.callFake((column) => { });
  //   component.sortedColumn = null;
  //   component.applySort();
  //   expect(sortFundsSpy.calls.count()).toEqual(0);
  // });

  // it('should sort funds', () => {
  //   component.funds = [
  //     { 'fundName': 'c',
  //       'ticker': 'VMFXX',
  //       'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //       'isPcOrSd': false,
  //       'inPortfolio': 'Y',
  //       'beginValue': 1,
  //       'endValue': null,
  //       'percentChange': null
  //     },
  //     { 'fundName': 'b',
  //       'ticker': 'null',
  //       'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //       'isPcOrSd': false,
  //       'inPortfolio': 'N',
  //       'beginValue': 10.92,
  //       'endValue': 10.92,
  //       'percentChange': 0
  //     },
  //     { 'fundName': 'a',
  //       'ticker': 'null',
  //       'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //       'isPcOrSd': false,
  //       'inPortfolio': 'N',
  //       'beginValue': 10.43,
  //       'endValue': 10.39,
  //       'percentChange': -0.38
  //     }];
  //     const sortedAscending =  [
  //       { 'fundName': 'a',
  //         'ticker': 'null',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'N',
  //         'beginValue': 10.43,
  //         'endValue': 10.39,
  //         'percentChange': -0.38
  //       },
  //       { 'fundName': 'b',
  //         'ticker': 'null',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'N',
  //         'beginValue': 10.92,
  //         'endValue': 10.92,
  //         'percentChange': 0
  //       },
  //       { 'fundName': 'c',
  //         'ticker': 'VMFXX',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'Y',
  //         'beginValue': 1,
  //         'endValue': null,
  //         'percentChange': null
  //       }];

  //     component.sortDirections['fundName'] = true;
  //     component.sortFunds('fundName');
  //     expect(component.funds).toEqual(sortedAscending);

  //     const sortPercentChange = [
  //       { 'fundName': 'c',
  //         'ticker': 'VMFXX',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'Y',
  //         'beginValue': 1,
  //         'endValue': null,
  //         'percentChange': null
  //       },
  //       { 'fundName': 'a',
  //         'ticker': 'null',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'N',
  //         'beginValue': 10.43,
  //         'endValue': 10.39,
  //         'percentChange': -0.38
  //       },
  //       { 'fundName': 'b',
  //         'ticker': 'null',
  //         'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //         'isPcOrSd': false,
  //         'inPortfolio': 'N',
  //         'beginValue': 10.92,
  //         'endValue': 10.92,
  //         'percentChange': 0
  //       }
  //       ];
  //       component.sortDirections['percentChange'] = true;
  //       component.sortFunds('percentChange');
  //       expect(component.funds).toEqual(sortPercentChange);

  //       component.funds = [
  //         { 'fundName': 'a',
  //           'ticker': 'null',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'N',
  //           'beginValue': 10.43,
  //           'endValue': 10.39,
  //           'percentChange': -0.38
  //         },
  //         { 'fundName': 'c',
  //           'ticker': 'VMFXX',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'Y',
  //           'beginValue': 1,
  //           'endValue': null,
  //           'percentChange': null
  //         },
  //         { 'fundName': 'b',
  //           'ticker': 'null',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'N',
  //           'beginValue': 10.92,
  //           'endValue': 10.92,
  //           'percentChange': 0
  //         }
  //         ];
  //       const sortTickers = [
  //         { 'fundName': 'c',
  //           'ticker': 'VMFXX',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'Y',
  //           'beginValue': 1,
  //           'endValue': null,
  //           'percentChange': null
  //         },
  //         { 'fundName': 'a',
  //           'ticker': 'null',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'N',
  //           'beginValue': 10.43,
  //           'endValue': 10.39,
  //           'percentChange': -0.38
  //         },
  //         { 'fundName': 'b',
  //           'ticker': 'null',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'N',
  //           'beginValue': 10.92,
  //           'endValue': 10.92,
  //           'percentChange': 0
  //         }
  //         ];
  //         component.sortDirections['ticker'] = false;
  //         component.sortFunds('ticker');
  //         expect(component.funds).toEqual(sortTickers);

  //         component.funds = [
  //           { 'fundName': 'c',
  //             'ticker': 'VMFXX',
  //             'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //             'isPcOrSd': false,
  //             'inPortfolio': 'Y',
  //             'beginValue': 1,
  //             'endValue': null,
  //             'percentChange': null
  //           },
  //           { 'fundName': 'b',
  //             'ticker': 'null',
  //             'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //             'isPcOrSd': false,
  //             'inPortfolio': 'N',
  //             'beginValue': 10.92,
  //             'endValue': 10.92,
  //             'percentChange': 0
  //           },
  //           { 'fundName': 'a',
  //             'ticker': 'null',
  //             'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //             'isPcOrSd': false,
  //             'inPortfolio': 'N',
  //             'beginValue': 10.43,
  //             'endValue': 10.39,
  //             'percentChange': -0.38
  //           }
  //           ];

  //         const sortEndValues = [
  //           { 'fundName': 'b',
  //           'ticker': 'null',
  //           'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=PRRIX',
  //           'isPcOrSd': false,
  //           'inPortfolio': 'N',
  //           'beginValue': 10.92,
  //           'endValue': 10.92,
  //           'percentChange': 0
  //           },
  //           { 'fundName': 'a',
  //             'ticker': 'null',
  //             'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VBIRX',
  //             'isPcOrSd': false,
  //             'inPortfolio': 'N',
  //             'beginValue': 10.43,
  //             'endValue': 10.39,
  //             'percentChange': -0.38
  //           },
  //           { 'fundName': 'c',
  //             'ticker': 'VMFXX',
  //             'tickerLink': 'https://profile.morningstar.com/Profile/HTMLPage.asp?ClientCode=SI2&ID=VMFXX',
  //             'isPcOrSd': false,
  //             'inPortfolio': 'Y',
  //             'beginValue': 1,
  //             'endValue': null,
  //             'percentChange': null
  //           }
  //           ];
  //           component.sortDirections['endValue'] = false;
  //           component.sortFunds('endValue');
  //           expect(component.funds).toEqual(sortEndValues);
  // });

  // it('should format percentage to N/A', () => {
  //   const fund = {
  //     'percentChange': null,
  //     'isPcOrSd': true,
  //     'beginValue': 1.0,
  //     'endValue': 1.0
  //   }
  //   let value = component.formatPercent(fund);
  //   expect(value).toEqual('N/A');

  //   fund.percentChange = 1.0;
  //   value = component.formatPercent(fund);
  //   expect(value).toEqual('N/A');

  //   fund.beginValue = 0.5;
  //   value = component.formatPercent(fund);
  //   expect(value).toEqual('N/A');
  // });

  // it ('should validate date range missing validate dates',
  // inject([DatePipe], (datePipe: DatePipe) => {
  //   component.bsRangeValue = null;
  //   component.validStartDate = new Date();
  //   component.validStartDate.setDate(component.validStartDate.getDate() - 360);
  //   component.validEndDate = new Date();
  //   let errors = component.validateDateRange();
  // tslint:disable-next-line:max-line-length
  //   const expectedError = `Please select a date range that is on or after ${datePipe.transform(component.validStartDate, 'M/d/yyyy')} and on or before ${datePipe.transform(component.validEndDate, 'M/d/yyyy')}.`;
  //   expect(errors).toEqual([expectedError]);
  //   component.bsRangeValue = [new Date()];
  //   errors = component.validateDateRange();
  //   expect(errors).toEqual([expectedError]);
  // }));

  // it ('should validate; start date before end date',
  // inject([DatePipe], (datePipe: DatePipe) => {
  //   component.validStartDate = new Date();
  //   component.validStartDate.setDate(component.validStartDate.getDate() - 360);
  //   component.validEndDate = new Date();

  //   const date = new Date();
  //   date.setDate(date.getDate() - 5);
  //   component.bsRangeValue = [new Date(), date];
  //   let errors = component.validateDateRange();
  //   expect(errors).toEqual([
  //     'The start date has to be before the end date.'
  //     // ,`The end date has to be before ${datePipe.transform(component.validEndDate, 'M/d/yyyy')}.`
  //   ]);
  //   component.validStartDate = null;
  //   component.validateDateRange()
  //   errors = component.validateDateRange();
  //   expect(errors).toEqual([]);
  // }));

  // it ('should validate; start date after valid start date',
  // inject([DatePipe], (datePipe: DatePipe) => {
  //   component.validStartDate = new Date();
  //   component.validStartDate.setDate(component.validStartDate.getDate() - 360);
  //   component.validEndDate = new Date();

  //   const date = new Date();
  //   date.setDate(date.getDate() - 365);
  //   component.bsRangeValue = [date, new Date()];
  //   let errors = component.validateDateRange();
  //   expect(errors).toEqual([
  //     `The start date has to be after ${datePipe.transform(component.validStartDate, 'M/d/yyyy')}.`
  //     // `The end date has to be before ${datePipe.transform(component.validEndDate, 'M/d/yyyy')}.`
  //   ]);
  //   component.validStartDate = null;
  //   component.validateDateRange()
  //   errors = component.validateDateRange();
  //   expect(errors).toEqual([]);
  // }));

  // it ('should validate; end date before valid end date',
  // inject([DatePipe], (datePipe: DatePipe) => {
  //   component.validStartDate = new Date();
  //   component.validStartDate.setDate(component.validStartDate.getDate() - 360);
  //   component.validEndDate = new Date();

  //   const startDate = new Date();
  //   startDate.setDate(startDate.getDate() - 30);
  //   const endDate = new Date()
  //   endDate.setDate(endDate.getDate() + 3);
  //   component.bsRangeValue = [startDate, endDate];
  //   const errors = component.validateDateRange();
  //   expect(errors).toEqual([
  //     `The end date has to be before ${datePipe.transform(component.validEndDate, 'M/d/yyyy')}.`
  //   ]);
  // }));

  //   it('should set error messages', () => {
  //     component.setErrorMessage([]);
  //     expect(component.errorMessage).toEqual('');

  //     const message = 'The start date has to be before the end date.';
  //     component.setErrorMessage([message]);
  //     expect(component.errorMessage).toEqual(message);
  //     const message2 = 'another error';

  //     component.setErrorMessage([message, message2]);
  //     const errorMessage = '<ul><li>' + message2
  //       + '</li><li>'
  //       + message
  //       + '</li></ul>'
  //       expect(component.errorMessage).toEqual(errorMessage);
  //   });

  //   it ('should generate report',
  //   async(() => inject([DatePipe, ApiService], (datePipe: DatePipe, apiService: ApiService) => {
  //     const startDate = new Date();
  //     startDate.setDate(startDate.getDate() - 360);
  //     const endDate = new Date();
  //     component.bsRangeValue = [startDate, endDate];
  //     const validateDateRangeSpy = spyOn(component, 'validateDateRange').and.callFake(() => {
  //       return [];
  //     });
  //     const getRpDataSpy = spyOn(apiService, 'getRpData').and.callFake((...params: any[]) => {
  //       return of({
  //         'performanceUnitorShare': { }
  //       });
  //     })
  //     const mapDataSpy = spyOn(component, 'mapData').and.callFake(() => { });
  //     const applySortSpy = spyOn(component, 'applySort').and.callFake(() => { });
  //     const unsubscriptSpy = spyOn(component, 'unsubscribe').and.callFake(() => { });
  //     component.generateReport()
  //     tick();
  //     expect(component.modalStatus).toEqual('close');
  //   })));

  //   it ('should generate report with HTTP errors',
  //   async(() => inject([DatePipe, ApiService], (datePipe: DatePipe, apiService: ApiService) => {
  //     const startDate = new Date();
  //     startDate.setDate(startDate.getDate() - 360);
  //     const endDate = new Date();
  //     component.bsRangeValue = [startDate, endDate];
  //     const validateDateRangeSpy = spyOn(component, 'validateDateRange').and.callFake(() => {
  //       return [];
  //     });
  //     const getRpDataSpy = spyOn(apiService, 'getRpData').and.callFake((...params: any[]) => {
  //       return Observable.throw({status: 500});
  //     })
  //     const mapDataSpy = spyOn(component, 'mapData').and.callFake(() => { });
  //     const applySortSpy = spyOn(component, 'applySort').and.callFake(() => { });
  //     const unsubscriptSpy = spyOn(component, 'unsubscribe').and.callFake(() => { });
  //     component.generateReport()
  //     tick();
  //     expect(component.modalStatus).toEqual('open');
  //     const displayErrorMessage = `<div class="alert alert-danger">We're sorry.  There is an error.  Please try again.</div>`;
  //     expect(component.fetchingMessage.body).toEqual(displayErrorMessage);
  //   })));

  //   it('should generate report with validation errors', () => {
  //     const validateDateRangeSpy = spyOn(component, 'validateDateRange').and.callFake(() => {
  //       return ['this is an error'];
  //     });
  //     const setErrorMessageSpy = spyOn(component, 'setErrorMessage').and.callFake((errors) => { });
  //     component.generateReport();
  //     expect(setErrorMessageSpy.calls.count()).toEqual(1);
  //   });
});
