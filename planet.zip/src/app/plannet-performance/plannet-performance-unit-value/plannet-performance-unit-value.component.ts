import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteHistoryService } from '../../core/route-history/route-history.service';
import { Observable } from 'rxjs/Observable';
import { ApiService } from '../../core/api/api-service';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { IPlanSummary } from '../../shared/interfaces/IPlanSummary';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs/Subscription';
// import { ContentService } from '../../core/content/content-service';
import { contentApiNames } from '../../shared/constants/contentApiNames';
import { Title } from '@angular/platform-browser';
import { MatSelectModule } from '@angular/material/select';
import { IDateRangeConfig } from '../../shared/interfaces/IDateRangeConfig';
import { ISortableTableHeaderColumn } from '../../shared/interfaces/ISortableTableHeaderColumn';
import { DateRangePickerComponent } from '../../shared/components/date-range-picker/date-range-picker.component';
import { RedemptionModalComponent } from '../../shared/components/redemption-modal/redemption-modal.component';
import { TableUtility, IValidateDateRangeResults } from '../../shared/utilities/TableUtility';
import { StringUtility } from '../../shared/utilities/StringUtility';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { PlannetContainerComponent } from '../../shared/components/plannet-container/plannet-container.component';
import { PercentagePipe } from '../../shared/pipes/Percentage.pipe';
import { CustomDecimalPipe } from '../../shared/pipes/CustomDecimal.pipe';

@Component({
  selector: 'ppr-unit-value',
  templateUrl: './plannet-performance-unit-value.component.html',
  styleUrls: ['./plannet-performance-unit-value.component.css']
})
export class PlannetPerformanceUnitValueComponent implements OnInit, OnDestroy {
  @ViewChild(DateRangePickerComponent) dateRangePicker: DateRangePickerComponent;
  @ViewChild(RedemptionModalComponent) redemptionFeesComponent: RedemptionModalComponent;
  @ViewChild(ModalComponent) modalComponent: ModalComponent;
  @ViewChild(PlannetContainerComponent) containerComponent: PlannetContainerComponent;
  // globalContent: any;
  // pageContent: any;
  apiPlanSummaryData: IPlanSummary; // see /mock/rp_api_mock/plan/803333/summary.json
  apiData: any; // see /mock/rp_api_mock/plan/803333/performance_unit_value.json
  redemptionFeeData: any;
  errorMessage: string = '';
  goBack: boolean;
  reportName: string;
  validStartDate: Date = new Date();
  validEndDate: Date = new Date();
  reportStartDate: Date = new Date();
  reportEndDate: Date = new Date();
  bsRangeValue: Date[];
  private subscriptions: Subscription = null;
  fetchingMessage = {
    header: '',
    body: ''
  };
  private _selectedViewBy: string = 'Unit Values';
  reportOptionList: any[];
  dateRangeConfig: IDateRangeConfig = null;
  loading = true;
  funds: any[];
  redemptionFeeFunds: any[];
  sortProperties = [
    {
      property: 'fundName',
      label: 'Investment',
      borderLeft: true,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true
    },
    {
      property: 'inPortfolio',
      label: 'Portfolio',
      borderLeft: false,
      borderRight: true,
      sortDirection: true,
      isSorted: false,
      sortReversed: true,
      isVisible: false
    },
    {
      property: 'ticker',
      label: 'Ticker',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true
    },
    {
      property: 'beginValue',
      label: 'Beginning Value',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true
    },
    {
      property: 'endValue',
      label: 'Ending Value',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true
    },
    {
      property: 'percentChange',
      label: 'Percentage Change',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true
    }
  ];

  constructor(
    private router: Router,
    private routeHistoryService: RouteHistoryService,
    private apiService: ApiService,
    private datePipe: DatePipe,
    private percentagePipe: PercentagePipe,
    private customDecimalPipe: CustomDecimalPipe,
    // private contentService: ContentService,
    private titleService: Title
  ) {
    titleService.setTitle('The Standard | Performance');
  }

  ngOnInit(): void {
    this.goBack = false;
    const planId = this.apiService.PlanId;
    if (!planId) {
      this.routeHistoryService.goBack();
    } else {
      // const plannetGlobalContentSource = this.contentService.getContent(contentApiNames.PlanNetGlobalContent);
      const cacheAPI = true;
      const rpApiPlanSummarySource = this.apiService.getRpData(rpApiNames.PlanNetPlanSummary, cacheAPI, planId);
      const rpApiFormSource = this.apiService.getRpData(rpApiNames.PlanNetPlanPerformanceUnitValue, cacheAPI, planId);
      const redemptionFeeApi = this.apiService.getRpData(rpApiNames.PlanNetRedemptionFees, cacheAPI, this.apiService.PlanId);
      const source = Observable.combineLatest(
        // plannetGlobalContentSource,
        rpApiPlanSummarySource,
        rpApiFormSource,
        redemptionFeeApi,
        ( // source1,
          source2,
          source3,
          source4 ) => {
          return {
            // GlobalContent: source1,
            ApiPlanSummaryData: source2,
            ApiData: source3,
            RedemptionFeeData: source4
          }
        }
      );
      this.subscriptions = new Subscription();
      this.subscriptions.add(source.subscribe(dataSource => {
        // this.globalContent = dataSource.GlobalContent;
        // this.pageContent = dataSource.PageContent;

        this.apiPlanSummaryData = <IPlanSummary>dataSource.ApiPlanSummaryData.data;
        this.apiData = dataSource.ApiData.performanceUnitorShare;
        this.redemptionFeeData = dataSource.RedemptionFeeData.redemptionFees;
        this.showNoDataModal();
        this.setReportName();
        this.setReportOptions();
        this.showOrHidePreMixPortfolio();
        this.mapData();
        this.unsubscribe();
      }, error => {
        this.unsubscribe();
        this.fetchingMessage.header = 'Loading Error';
        this.fetchingMessage.body = `<p class="error-text">We're sorry.  There is an error.  Please try again.</p>`;
        this.modalComponent.openModal();
        this.goBack = true;
      }));
    }
  }

  ngOnDestroy(): void {
    this.cancelFetching('closed');
  }

  showNoDataModal() {
    if (!this.apiPlanSummaryData.validStartDate || !this.apiPlanSummaryData.validEndDate) {
      this.containerComponent.showNoDataModal();
    }
  }

  openRedemptionFeeModal() {
    this.redemptionFeesComponent.openRedemptionFeeModal(this.redemptionFeeFunds);
  }

  cancelFetching(status) {
    if (status === 'closed') {
      this.unsubscribe();
      if (this.goBack === true) {
        this.goBack = false;
        this.routeHistoryService.goBack();
      }
    }
  }

  unsubscribe() {
    this.loading = false;
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }
    this.subscriptions = null;
  }

  showOrHidePreMixPortfolio() {
    const properties = this.sortProperties.find((item) => {
      return (item.property === 'inPortfolio');
    })
    if (this.apiPlanSummaryData && this.apiData.preMixPortfolio === 'Y') {
      properties.isVisible = true;
    } else {
      properties.isVisible = false;
    }
  }

  setReportOptions() {
    this.reportOptionList = [
      {
        value: this.reportName
      },
      {
        value: 'Rate of Return'
      }
    ];
  }

  setReportName() {
    if (this.isGa() === true) {
      this.reportName = 'Unit Values';
    } else {
      this.reportName = 'Share Values';
    }
    this._selectedViewBy = this.reportName
  }

  set SelectedViewBy(value) {
    if (this._selectedViewBy !== null) {
      if (value === 'Rate of Return') {
        this.router.navigate(['/plan-performance/ror'])
      }
    }
    this._selectedViewBy = value;
  }
  get SelectedViewBy() {
    return this._selectedViewBy;
  }

  isGa() {
    if (this.apiPlanSummaryData) {
      return (this.apiPlanSummaryData.productTypeCd === 'UNR');
    }
    return true; // default GA
  }

  generateReport(selectedDates) {
    this.bsRangeValue = selectedDates;
    // tslint:disable-next-line:max-line-length
    const results: IValidateDateRangeResults = TableUtility.validateDateRange(this.datePipe, this.bsRangeValue, this.validStartDate, this.validEndDate);
    this.setErrorMessage(results.errors);
    if (results.errors.length === 0) {
      this.loading = true;
      const cacheAPI = false;
      const startDate = this.datePipe.transform(this.bsRangeValue[0], 'yyyy-MM-dd');
      const endDate = this.datePipe.transform(this.bsRangeValue[1], 'yyyy-MM-dd');
      this.subscriptions = new Subscription();
      this.subscriptions.add(this.apiService.getRpData(rpApiNames.PlanNetPlanPerformanceUnitValueWithDates, cacheAPI,
        this.apiPlanSummaryData.planId, startDate, endDate).subscribe( data => {
          this.apiData = data.performanceUnitorShare;
          this.mapData();
          this.applySort();
          this.dateRangePicker.clearDates();
          this.unsubscribe();
        }, error => {
          this.unsubscribe();
          this.errorMessage = `We're sorry.  There is an error.  Please try again.`;
        })
      );
    } else {
      this.dateRangePicker.showCalendar(results.calendar);
    }
  }

  applySort() {
    const property = this.sortProperties.find(prop => {
      return (prop.isSorted === true);
    });
    if (property) {
      this.sortFunds(property);
    }
  }

  setErrorMessage(errors: string[]) {
    let message = '';
    const numberOfErrors = errors.length;
    if (errors.length > 0) {
      if (numberOfErrors > 1) {
        message = '<ul>';
        errors.forEach((error) => {
          message += '<li>' + error + '</li>';
        });
        message += '</ul>';
      } else {
        message = errors[0];
      }
    }
    this.errorMessage = message;
  }

  mapData() {
    this.validEndDate = StringUtility.convertStringToDate(this.apiPlanSummaryData.validEndDate);
    this.validStartDate = StringUtility.convertStringToDate(this.apiPlanSummaryData.validStartDate);
    this.reportEndDate = StringUtility.convertStringToDate(this.apiData.endDate);
    this.reportStartDate = StringUtility.convertStringToDate(this.apiData.startDate);
    this.dateRangeConfig = Object.assign({},
      {
        startDate: this.datePipe.transform(this.validStartDate, 'M/d/yyyy'),
        endDate: this.datePipe.transform(this.validEndDate, 'M/d/yyyy')
      }
    );
    this.redemptionFeeFunds = [];
    this.funds = this.apiData.funds.map(fund => {
      const redemptionFeeFund = this.hasRedemptionFee(fund);
      if (redemptionFeeFund) {
        this.redemptionFeeFunds.push(redemptionFeeFund);
      }
      return {
        tickerLink: fund.tickerLink,
        fundName: fund.fundName,
        inPortfolio: fund.inPortfolio,
        isRedemptionFee: !!redemptionFeeFund, // convert redemptionFeeFund object to boolean
        ticker: fund.ticker,
        beginValue: fund.unitorShareValues.beginValue,
        endValue:  fund.unitorShareValues.endValue,
        percentChange: fund.unitorShareValues.percentChange,
        isPcOrSd: ((fund.investmentFundId === 'PC') || (fund.investmentFundId === 'SD'))
      };
    });
  }
  hasRedemptionFee(fund) {
    return this.redemptionFeeData.find(item => {
      return item.fundName === fund.fundName;
    });
  }

  formatBegin(fund: any) {
    if (!fund.beginValue
      || fund.beginValue === 1.0 && fund.isPcOrSd === true) {
        return 'N/A';
    }
    return this.customDecimalPipe.transform(fund.beginValue, '1.6-6');
  }

  formatEnd(fund: any) {
    if (!fund.endValue
      || fund.endValue === 1.0 && fund.isPcOrSd === true) {
        return 'N/A';
    }
    return this.customDecimalPipe.transform(fund.endValue, '1.6-6');
  }

  formatPercent(fund: any) {
    if (!fund.percentChange && fund.percentChange !== 0) {
      return 'N/A'
    } else if (fund.isPcOrSd === true &&
      (fund.beginValue === 1.0 || fund.endValue === 1.0)) {
        return 'N/A'
    }
    return this.percentagePipe.transform(fund.percentChange, '1.2-2');
  }

  sortFunds(property) {
    const direction = property.sortDirection ? 1 : -1;
    this.funds.sort(TableUtility.sortHandler(property.property, direction));
  }
}
