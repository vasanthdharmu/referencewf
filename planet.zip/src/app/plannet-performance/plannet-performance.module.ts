import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PlannetPerformanceComponent } from './plannet-performance/plannet-performance.component';
import { SharedModule } from '../shared/shared.module';
import { PlannetPerformanceUnitValueComponent } from './plannet-performance-unit-value/plannet-performance-unit-value.component';
import { PlannetPerformanceRouting } from './plannet-performance.routing';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap';
import { CustomDecimalPipe } from '../shared/pipes/CustomDecimal.pipe';
import { PercentagePipe } from '../shared/pipes/Percentage.pipe';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PlannetPerformanceRouting,
    TooltipModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [
    PlannetPerformanceComponent,
    PlannetPerformanceUnitValueComponent
  ],
  providers: [DatePipe, CustomDecimalPipe, PercentagePipe]
})
export class PlannetPerformanceModule { }
