import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlannetPerformanceComponent } from './plannet-performance/plannet-performance.component';
import { PlannetPerformanceUnitValueComponent } from './plannet-performance-unit-value/plannet-performance-unit-value.component';

const routes: Routes = [
    {
        path: 'unit-value',
        component: PlannetPerformanceUnitValueComponent
    },
    {
       path: 'ror',
       component: PlannetPerformanceComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlannetPerformanceRouting {
}
