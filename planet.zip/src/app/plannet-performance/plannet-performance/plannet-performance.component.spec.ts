import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetPerformanceComponent } from './plannet-performance.component';

describe('PlannetPerformance.PageComponent', () => {
  let component: PlannetPerformanceComponent;
  let fixture: ComponentFixture<PlannetPerformanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetPerformanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
