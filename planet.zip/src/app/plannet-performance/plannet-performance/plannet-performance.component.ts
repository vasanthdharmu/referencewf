import {Component, OnInit, OnDestroy, TemplateRef, ViewChild, ElementRef} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteHistoryService } from '../../core/route-history/route-history.service';
import { IPlanSummary } from '../../shared/interfaces/IPlanSummary';
import { Subscription } from 'rxjs/Subscription';
import { ApiService } from '../../core/api/api-service';
import { DatePipe } from '@angular/common';
import { ContentService } from '../../core/content/content-service';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { Observable } from 'rxjs/Observable';
import { Title } from '@angular/platform-browser';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RedemptionModalComponent } from '../../shared/components/redemption-modal/redemption-modal.component';
import { TableUtility } from '../../shared/utilities/TableUtility';
import { StringUtility } from '../../shared/utilities/StringUtility';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { PlannetContainerComponent } from '../../shared/components/plannet-container/plannet-container.component';

@Component({
  selector: 'ppr-plannet-performance',
  templateUrl: './plannet-performance.component.html',
  styleUrls: ['./plannet-performance.component.css']
})
export class PlannetPerformanceComponent implements OnInit, OnDestroy {
  @ViewChild(RedemptionModalComponent) redemptionFeesComponent: RedemptionModalComponent;
  @ViewChild(ModalComponent) modalComponent: ModalComponent;
  @ViewChild(PlannetContainerComponent) containerComponent: PlannetContainerComponent;
  // globalContent: any;
  // pageContent: any;
  apiPlanSummaryData: IPlanSummary; // see /mock/rp_api_mock/plan/803333/summary.json
  apiData: any; // see /mock/rp_api_mock/plan/803333/performance_unit_value.json
  redemptionFeeData: any; // see /mock/rp_api_mock/plan/803333/redemption-fees.json
  errorMessage: string = '';
  goBack: boolean;
  reportName: string;
  modalRef: BsModalRef;
  bsRangeValue: Date[];
  private subscriptions: Subscription = null;
  fetchingMessage = {
    header: '',
    body: ''
  };
  private _selectedViewBy: string = 'Rate of Return';
  reportOptionList: any[];
  loading = true;

  funds: any[];
  redemptionFeeFunds: any[];

  sortProperties = [
    {
      property: 'fundName',
      label: 'Investment',
      borderLeft: true,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'inPortfolio',
      label: 'Portfolio',
      borderLeft: false,
      borderRight: true,
      sortDirection: true,
      isSorted: false,
      sortReversed: true,
      isVisible: false,
      noBorderTop: true
    },
    {
      property: 'ticker',
      label: 'Ticker',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'firstPeriod',
      label: 'Last Month',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'yearToDate',
      label: 'YTD',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'yearOne',
      label: '1-Year',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'yearThree',
      label: '3-Year',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'yearFive',
      label: '5-Year',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    },
    {
      property: 'yearTen',
      label: '10-Year',
      borderLeft: false,
      borderRight: false,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      noBorderTop: true
    }
  ];

   // redemptionFees = {
   //   title: '',
   //   content: '',
   //   feeList: []
   // };

  constructor(
    private router: Router,
    private routeHistoryService: RouteHistoryService,
    private apiService: ApiService,
    private datePipe: DatePipe,
    private contentService: ContentService,
    private titleService: Title,
    private modalService: BsModalService
  ) {
    titleService.setTitle('The Standard | Performance');
   }

  ngOnInit(): void {
    this.goBack = false;
    const planId = this.apiService.PlanId; // param['plan_id'];
    if (!planId) {
      this.routeHistoryService.goBack();
    } else {
      // const plannetGlobalContentSource = this.contentService.getContent(contentApiNames.PlanNetGlobalContent);
      const cacheAPI = true;
      const rpApiPlanSummarySource = this.apiService.getRpData(rpApiNames.PlanNetPlanSummary, cacheAPI, planId);
      const rpApiFormSource = this.apiService.getRpData(rpApiNames.PlanNetPlanPerformanceRor, cacheAPI, planId);
      const redemptionFeeApi = this.apiService.getRpData(rpApiNames.PlanNetRedemptionFees, cacheAPI, this.apiService.PlanId);
      const source = Observable.combineLatest(
        // plannetGlobalContentSource,
        rpApiPlanSummarySource,
        rpApiFormSource,
        redemptionFeeApi,
        ( // source1,
          source2,
          source3,
          source4,
          ) => {
          return {
            // GlobalContent: source1,
            ApiPlanSummaryData: source2,
            ApiData: source3,
            RedemptionFeeData: source4
          }
        }
      );
      this.subscriptions = new Subscription();
      this.subscriptions.add(source.subscribe(dataSource => {
        // this.globalContent = dataSource.GlobalContent;
        // this.pageContent = dataSource.PageContent;
        this.apiPlanSummaryData = <IPlanSummary>dataSource.ApiPlanSummaryData.data;
        this.apiData = dataSource.ApiData.performanceROR;
        this.redemptionFeeData = dataSource.RedemptionFeeData.redemptionFees;
        this.showNoDataModal();
        this.setReportName();
        this.setReportOptions();
        this.showOrHidePreMixPortfolio();
        this.setFirstPeriodLabel();
        this.mapData();
        this.unsubscribe();
      }, error => {
        this.unsubscribe();
        this.fetchingMessage.header = 'Loading Error';
        this.fetchingMessage.body = `<p class="error-text">We're sorry.  There is an error.  Please try again.</p>`;
        this.modalComponent.openModal();
        this.goBack = true;
      }));
    }
  }

  ngOnDestroy(): void {
    this.cancelFetching('closed');
  }

  showNoDataModal() {
    if (!this.apiPlanSummaryData.validStartDate || !this.apiPlanSummaryData.validEndDate) {
      this.containerComponent.showNoDataModal();
    }
  }

  openBaseModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template,
      {
        keyboard: true,
        ignoreBackdropClick: false,
        backdrop: false
      }
    );
  }

  openRedemptionFeeModal() {
    this.redemptionFeesComponent.openRedemptionFeeModal(this.redemptionFeeFunds);
  }

  cancelFetching(status) {
    if (status === 'closed') {
      this.unsubscribe();
      if (this.goBack === true) {
        this.goBack = false;
        this.routeHistoryService.goBack();
      }
    }
  }

  unsubscribe() {
    this.loading = false;
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }
    this.subscriptions = null;
  }

  setReportOptions() {
    this.reportOptionList = [
      {
        value: 'Rate of Return'
      },
      {
        value: this.reportName
      }
    ];
  }

  setReportName() {
    if (this.isGa() === true) {
      this.reportName = 'Unit Values';
    } else {
      this.reportName = 'Share Values';
    }
  }

  set SelectedViewBy(value) {
    if (this._selectedViewBy !== null) {
      if (value === 'Share Values' || value === 'Unit Values') {
        this.router.navigate(['/plan-performance/unit-value'])
      }
    }
    this._selectedViewBy = value;
  }
  get SelectedViewBy() {
    return this._selectedViewBy;
  }
  isGa() {
    if (this.apiPlanSummaryData) {
      return (this.apiPlanSummaryData.productTypeCd === 'UNR');
    }
    return true; // default GA
  }

  showOrHidePreMixPortfolio() {
    const properties = this.sortProperties.find((item) => {
      return (item.property === 'inPortfolio');
    })
    if (this.apiPlanSummaryData && this.apiData.preMixPortfolio === 'Y') {
      properties.isVisible = true;
    } else {
      properties.isVisible = false;
    }
  }

  setFirstPeriodLabel() {
    const property = this.sortProperties.find( item => {
      return (item.property === 'firstPeriod');
    });
    if (property) {
      if (this.isGa() === true) {
        // GA
        property.label = 'Last Month';
      } else {
        // NAV
        property.label = 'Last Quarter';
      }
    }
  }

  mapData() {
    const useLastMonth = this.isGa();
    this.redemptionFeeFunds = [];
    this.funds = this.apiData.funds.map(fund => {
      const redemptionFeeFund = this.hasRedemptionFee(fund);
      if (redemptionFeeFund) {
        this.redemptionFeeFunds.push(redemptionFeeFund);
      }
      return {
        tickerLink: fund.tickerLink,
        fundName: fund.fundName,
        inPortfolio: fund.inPortfolio,
        isRedemptionFee: !!redemptionFeeFund, // convert redemptionFeeFund object to boolean
        ticker: fund.ticker,
        firstPeriod: useLastMonth === true ? fund.rateOfReturn.lastMonth : fund.rateOfReturn.lastQuarter,
        yearToDate: fund.rateOfReturn.yearToDate,
        yearOne: fund.rateOfReturn.yearOne,
        yearThree: fund.rateOfReturn.yearThree,
        yearFive: fund.rateOfReturn.yearFive,
        yearTen: fund.rateOfReturn.yearTen
      };
    });
  }

  hasRedemptionFee(fund) {
    return this.redemptionFeeData.find(item => {
      return item.fundName === fund.fundName;
    });
  }

  getAsOfDate() {
    if (this.apiData && this.apiData.perfAsOfDate) {
      return StringUtility.convertStringToDate(this.apiData.perfAsOfDate);
    }
    return new Date();
  }

  sortFunds(property) {
    const direction = property.sortDirection ? 1 : -1;
    this.funds.sort(TableUtility.sortHandler(property.property, direction));
  }
}
