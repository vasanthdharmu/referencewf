import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetTransactionsDepositsComponent } from './plannet-transactions-deposits.component';

describe('PlannetTransactionsDepositsComponent', () => {
  let component: PlannetTransactionsDepositsComponent;
  let fixture: ComponentFixture<PlannetTransactionsDepositsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetTransactionsDepositsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetTransactionsDepositsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
