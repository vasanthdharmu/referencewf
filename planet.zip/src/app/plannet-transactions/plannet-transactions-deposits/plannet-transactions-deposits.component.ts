import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteHistoryService } from '../../core/route-history/route-history.service';
import { IPlanSummary } from '../../shared/interfaces/IPlanSummary';
import { Subscription } from 'rxjs/Subscription';
import { ApiService } from '../../core/api/api-service';
import { DatePipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { ContentService } from '../../core/content/content-service';
import { contentApiNames } from '../../shared/constants/contentApiNames';
import { rpApiNames } from '../../shared/constants/rpApiNames';
import { Observable } from 'rxjs/Observable';
import { Title } from '@angular/platform-browser';
import { NegativeNumberPipe } from '../../shared/pipes/negative-number.pipe';
import { IDateRangeConfig } from '../../shared/interfaces/IDateRangeConfig';
import { DateRangePickerComponent } from '../../shared/components/date-range-picker/date-range-picker.component';
import { RedemptionModalComponent } from '../../shared/components/redemption-modal/redemption-modal.component';
import { TableUtility, IValidateDateRangeResults } from '../../shared/utilities/TableUtility';
import { StringUtility } from '../../shared/utilities/StringUtility';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { PlannetContainerComponent } from '../../shared/components/plannet-container/plannet-container.component';

@Component({
  selector: 'ppr-plannet-transactions-deposits',
  templateUrl: './plannet-transactions-deposits.component.html',
  styleUrls: ['./plannet-transactions-deposits.component.css']
})
export class PlannetTransactionsDepositsComponent implements OnInit, OnDestroy {
  // globalContent: any;
  // pageContent: any;
  @ViewChild(DateRangePickerComponent) dateRangePicker: DateRangePickerComponent;
  @ViewChild(RedemptionModalComponent) redemptionFeesComponent: RedemptionModalComponent;
  @ViewChild(ModalComponent) modalComponent: ModalComponent;
  @ViewChild(PlannetContainerComponent) containerComponent: PlannetContainerComponent;
  apiPlanSummaryData: IPlanSummary; // see /mock/rp_api_mock/plan/803333/summary.json
  apiData: any; // see /mock/rp_api_mock/plan/803333/investment_balance.json
  redemptionFeeData: any;
  errorMessage: string = '';
  goBack: boolean;
  reportName: string;
  validStartDate: Date = new Date();
  validEndDate: Date = new Date();
  reportStartDate: Date = new Date();
  reportEndDate: Date = new Date();
  bsRangeValue: Date[];
  private subscriptions: Subscription = null;
  fetchingMessage = {
    header: '',
    body: ''
  };
  private _selectedViewBy: string = 'Deposits';
  reportOptionList: any[];
  dateRangeConfig: IDateRangeConfig = null;
  loading = true;
  deposits: any[];
  redemptionFeeFunds: any[];

  sortProperties = [
    {
      property: 'depositDate',
      label: 'Deposit',
      borderLeft: true,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'payrollDate',
      label: 'Payroll',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'depositTotal',
      label: 'Total',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'employeeSum',
      label: 'Employee',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'employerSum',
      label: 'Employer',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'loanPayment',
      label: 'Loan Payment',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'rollOverSum',
      label: 'Rollover',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: true,
      class: null
    },
    {
      property: 'detail',
      label: 'Detail',
      borderLeft: false,
      borderRight: true,
      sortDirection: false,
      isSorted: false,
      sortReversed: false,
      isVisible: true,
      sortable: false,
      class: null
    }
  ];


  constructor(
    private router: Router,
    private routeHistoryService: RouteHistoryService,
    private apiService: ApiService,
    private datePipe: DatePipe,
    private decimalPipe: DecimalPipe,
    private currencyPipe: CurrencyPipe,
    private negativeNumberPipe: NegativeNumberPipe,
    private contentService: ContentService,
    private titleService: Title
  ) {
    titleService.setTitle('The Standard | Transcations');
  }

  ngOnInit(): void {
    this.goBack = false;
    const planId = this.apiService.PlanId; // param['plan_id'];
    if (!planId) {
      this.routeHistoryService.goBack();
    } else {
      // const plannetGlobalContentSource = this.contentService.getContent(contentApiNames.PlanNetGlobalContent);
      const cacheAPI = true;
      const rpApiPlanSummarySource = this.apiService.getRpData(rpApiNames.PlanNetPlanSummary, cacheAPI, planId);
      const rpApiFormSource = this.apiService.getRpData(rpApiNames.PlanNetPlanTransactionDeposits, cacheAPI, planId);
      const redemptionFeeApi = this.apiService.getRpData(rpApiNames.PlanNetRedemptionFees, cacheAPI, this.apiService.PlanId);
      const source = Observable.combineLatest(
        // plannetGlobalContentSource,
        rpApiPlanSummarySource,
        rpApiFormSource,
        redemptionFeeApi,
        ( // source1,
          source2,
          source3,
          source4) => {
          return {
            // GlobalContent: source1,
            ApiPlanSummaryData: source2,
            ApiData: source3,
            RedemptionFeeData: source4
          }
        }
      );
      this.subscriptions = new Subscription();
      this.subscriptions.add(source.subscribe(dataSource => {
        // this.globalContent = dataSource.GlobalContent;
        // this.pageContent = dataSource.PageContent;
        this.apiPlanSummaryData = <IPlanSummary>dataSource.ApiPlanSummaryData.data;
        this.apiData = dataSource.ApiData.depostiTransactions;
        this.redemptionFeeData = dataSource.RedemptionFeeData.redemptionFees;
        this.showNoDataModal();
        this.setReportOptions();
        this.mapData();
        this.unsubscribe();
      }, error => {
        this.unsubscribe();
        this.fetchingMessage.header = 'Loading Error';
        this.fetchingMessage.body = `<p class="error-text">We're sorry.  There is an error.  Please try again.</p>`;
        this.modalComponent.openModal();
        this.goBack = true;
      }));
    }
  }

  ngOnDestroy(): void {
    this.cancelFetching('closed');
  }

  showNoDataModal() {
    if (!this.apiPlanSummaryData.validStartDate || !this.apiPlanSummaryData.validEndDate) {
      this.containerComponent.showNoDataModal();
    }
  }

  openRedemptionFeeModal() {
    this.redemptionFeesComponent.openRedemptionFeeModal(this.redemptionFeeFunds);
  }

  cancelFetching(status) {
    if (status === 'closed') {
      this.unsubscribe();
      if (this.goBack === true) {
        this.goBack = false;
        this.routeHistoryService.goBack();
      }
    }
  }
  unsubscribe() {
    this.loading = false;
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }
    this.subscriptions = null;
  }

  setReportOptions() {
    this.reportOptionList = [
      {
        value: 'Deposits'
      },
      {
        value: 'Distributions'
      },
      {
        value: 'Loans'
      }
    ];
  }

  set SelectedViewBy(value) {

    if (this._selectedViewBy !== null) {
      if (value === 'Distributions') {
        this.router.navigate(['/plan-transactions/distributions'])
      }
      if (value === 'Loans') {
        this.router.navigate(['/plan-transactions/loans'])
      }
    }
    this._selectedViewBy = value;
    
  }

  get SelectedViewBy() {
    return this._selectedViewBy;
  }

  isGa() {
    if (this.apiPlanSummaryData) {
      return (this.apiPlanSummaryData.productTypeCd === 'UNR');
    }
    return true; // default GA
  }

  // Check if the fund is SDBA or PCRA fund
  isSdOrPc(investmentFundId) {
    return (investmentFundId === 'SD' || investmentFundId === 'PC');
  }

  mapData() {
    this.validEndDate = StringUtility.convertStringToDate(this.apiPlanSummaryData.validEndDate);
    this.validStartDate = StringUtility.convertStringToDate(this.apiPlanSummaryData.validStartDate);
    this.reportEndDate = StringUtility.convertStringToDate(this.apiData.endDate);
    this.reportStartDate = StringUtility.convertStringToDate(this.apiData.beginDate);
    this.dateRangeConfig = Object.assign({},
      {
        startDate: this.datePipe.transform(this.validStartDate, 'M/d/yyyy'),
        endDate: this.datePipe.transform(this.validEndDate, 'M/d/yyyy')
      }
    );

    this.redemptionFeeFunds = [];
    console.log("this.apiData.deposits", this.apiData.deposits);
    this.deposits = this.apiData.deposits.map(deposit => {
      const redemptionFeeFund = this.hasRedemptionFee(deposit);
      if (redemptionFeeFund) {
        this.redemptionFeeFunds.push(redemptionFeeFund);
      }
      return {
        depositDate: deposit.depositDate,
        payrollDate: deposit.payrollDate,
        depositTotal: deposit.depositTotal,
        employeeSum: deposit.employeeSum,
        employerSum: deposit.employerSum,
        loanPayment: deposit.loanPayment,
        rollOverSum: deposit.rollOverSum
      };
    });
  }
  hasRedemptionFee(fund) {
    return this.redemptionFeeData.find(item => {
      return item.fundName === fund.fundName;
    });
  }
  getAsOfDate() {
    if (this.apiData && this.apiData.perfAsOfDate) {
      return StringUtility.convertStringToDate(this.apiData.perfAsOfDate);
    }
    return new Date();
  }

  formatPercent(value) {
    if (value === null || value === undefined) {
      return 'N/A';
    }
    return this.negativeNumberPipe.transform(this.decimalPipe.transform(value, '1.2-2') + '%');
  }

  // Format a negative dollar value to a dollar value enclosed by parentheses
  formatDollar(value) {
    if (value === null || value === undefined) {
      return 'N/A';
    }

    const currencyValue = this.currencyPipe.transform(value, 'USD', 'symbol', '1.2-2');

    return this.negativeNumberPipe.transform(currencyValue);
  }

  sortDeposits(property) {
    const direction = property.sortDirection ? 1 : -1;
    this.deposits.sort(TableUtility.sortHandler(property.property, direction));
  }

  generateReport(selectedDates) {
    this.bsRangeValue = selectedDates;
    // tslint:disable-next-line:max-line-length
    const results: IValidateDateRangeResults = TableUtility.validateDateRange(this.datePipe, this.bsRangeValue, this.validStartDate, this.validEndDate);
    this.setErrorMessage(results.errors);
    if (results.errors.length === 0) {
      this.loading = true;
      const cacheAPI = false;
      const startDate = this.datePipe.transform(this.bsRangeValue[0], 'yyyy-MM-dd');
      const endDate = this.datePipe.transform(this.bsRangeValue[1], 'yyyy-MM-dd');
      this.subscriptions = new Subscription();
      this.subscriptions.add(this.apiService.getRpData(rpApiNames.PlanNetPlanTransactionDeposits, cacheAPI,
        this.apiPlanSummaryData.planId, startDate, endDate).subscribe( data => {
          this.apiData = data.depostiTransactions;
          this.mapData();
          this.applySort();
          this.dateRangePicker.clearDates();
          this.unsubscribe();
        }, error => {
          this.unsubscribe();
          this.errorMessage = `We're sorry.  There is an error.  Please try again.`;
        })
      );
    } else {
      this.dateRangePicker.showCalendar(results.calendar);
    }
  }

  applySort() {
    const property = this.sortProperties.find(prop => {
      return (prop.isSorted === true);
    });
    if (property) {
      this.sortDeposits(property);
    }
  }

  setErrorMessage(errors: string[]) {
    let message = '';
    const numberOfErrors = errors.length;
    if (errors.length > 0) {
      if (numberOfErrors > 1) {
        message = '<ul>';
        errors.forEach((error) => {
          message += '<li>' + error + '</li>';
        });
        message += '</ul>';
      } else {
        message = errors[0];
      }
    }
    this.errorMessage = message;
  }
}
