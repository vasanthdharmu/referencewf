import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetTransactionsDistributionComponent } from './plannet-transactions-distribution.component';

describe('PlannetTransactionsDistributionComponent', () => {
  let component: PlannetTransactionsDistributionComponent;
  let fixture: ComponentFixture<PlannetTransactionsDistributionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetTransactionsDistributionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetTransactionsDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
