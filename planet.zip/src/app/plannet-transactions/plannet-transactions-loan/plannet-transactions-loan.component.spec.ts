import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetTransactionsLoanComponent } from './plannet-transactions-loan.component';

describe('PlannetTransactionsLoanComponent', () => {
  let component: PlannetTransactionsLoanComponent;
  let fixture: ComponentFixture<PlannetTransactionsLoanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetTransactionsLoanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetTransactionsLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
