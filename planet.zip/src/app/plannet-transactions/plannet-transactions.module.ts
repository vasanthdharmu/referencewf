import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe, CurrencyPipe } from '@angular/common';
import { PlannetTransactionsDepositsComponent } from './plannet-transactions-deposits/plannet-transactions-deposits.component';
import { PlannetTransactionsDistributionComponent } from './plannet-transactions-distribution/plannet-transactions-distribution.component';
import { PlannetTransactionsLoanComponent } from './plannet-transactions-loan/plannet-transactions-loan.component';
import { SharedModule } from '../shared/shared.module';
import { PlannetTransactionsRouting } from './plannet-transactions.routing';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NegativeNumberPipe } from '../shared/pipes/negative-number.pipe';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PlannetTransactionsRouting,
    TooltipModule.forRoot()
  ],
  declarations: [
    PlannetTransactionsDepositsComponent,
    PlannetTransactionsDistributionComponent,
    PlannetTransactionsLoanComponent
  ],
  providers: [DatePipe, DecimalPipe, CurrencyPipe, NegativeNumberPipe]
})
export class PlannetTransactionsModule { }
