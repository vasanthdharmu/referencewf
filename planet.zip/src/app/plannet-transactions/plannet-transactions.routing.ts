import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlannetTransactionsDepositsComponent } from './plannet-transactions-deposits/plannet-transactions-deposits.component';
import { PlannetTransactionsDistributionComponent } from './plannet-transactions-distribution/plannet-transactions-distribution.component';
import { PlannetTransactionsLoanComponent } from './plannet-transactions-loan/plannet-transactions-loan.component';

const routes: Routes = [
    {
        path: 'deposits',
        component: PlannetTransactionsDepositsComponent
    },
    {
        path: 'distributions',
        component: PlannetTransactionsDistributionComponent
    },
    {
        path: 'loans',
        component: PlannetTransactionsLoanComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlannetTransactionsRouting {
}
