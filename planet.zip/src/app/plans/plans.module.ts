import { NgModule } from '@angular/core';
import { PlansPage } from './plans.page';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { PlansRouting } from './plans.routing';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PlansRouting
  ],
  declarations: [
    PlansPage
  ],
  providers: [

  ],
  exports: [

  ]
})
export class PlansModule {

}
