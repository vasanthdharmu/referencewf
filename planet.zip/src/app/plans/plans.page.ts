import { Component } from '@angular/core';
// import { PlanSummaryApi } from '../core/api/plan-summary.api';
import * as _ from 'lodash';

@Component({
  selector: 'app-plans',
  templateUrl: './plans.page.html',
  styleUrls: ['./plans.page.css']
})
export class PlansPage {
  _: any = _;
  plans: any[];
  loading = false;
  constructor() {
    // this.getPlans();
  }

  getPlansRedis(planNo: string) {
    this.loading = true;
    /* this.planSummaryApi.getPlansRedis(planNo)
      .subscribe((res) => {
        this.plans = res;
        this.loading = false;
      }, (err: any) => {
        this.plans = [];
        this.loading = false;
      }); */
  }

  redisSearchPlan(text: string) {
    this.getPlansRedis(text);
  }

  getPlansOracle(planNo: string) {
    this.loading = true;
    /*this.planSummaryApi.getPlansOracle(planNo)
      .subscribe((res) => {
        this.plans = res;
        this.loading = false;
      }, (err: any) => {
        this.plans = [];
        this.loading = false;
      });*/
  }

  oracleSearchPlan(text: string) {
    this.getPlansOracle(text);
  }

  identify(index) {
    return index;
  }
}
