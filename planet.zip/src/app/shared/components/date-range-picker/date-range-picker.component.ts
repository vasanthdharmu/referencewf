import { Component, OnInit, Input, Inject, ViewChild, ElementRef, Output, EventEmitter, OnDestroy } from '@angular/core';
import { IDateRangeConfig } from '../../interfaces/IDateRangeConfig';
import { JQ_TOKEN } from '../../../core/library/jquery.service';

@Component({
  selector: 'ppr-date-range-picker',
  templateUrl: './date-range-picker.component.html',
  styleUrls: ['./date-range-picker.component.css']
})
export class DateRangePickerComponent implements OnInit, OnDestroy {

  @ViewChild('dateRangePicker') dateRangePickerElement: ElementRef;
  private _config: IDateRangeConfig = null;
  @Input() set config(value: IDateRangeConfig) {
    // Create the date range picker only if there are valid start and end dates.
    if (value !== null) {
      this._config = value;
      this.createRangeDatePicker(value);
    }
  }
  get config() {
    return this._config;
  }

  private dateRangePickerNativeElement: any = null;
  // tslint:disable-next-line:no-output-rename
  @Output('dateSelected') dateSelectedEmitter: EventEmitter<Date[]> = new EventEmitter<Date[]>();
  // tslint:disable-next-line:no-output-rename
  @Output('applyClicked') applyClickedEmitter: EventEmitter<Date[]> = new EventEmitter<Date[]>();

  dateRangeInstant: any = null;
  dateInputs: any [];

  constructor(@Inject(JQ_TOKEN) private jquery: any) { }

  ngOnInit() {
  }

  private createRangeDatePicker(range: IDateRangeConfig) {
    if (this.dateRangeInstant === null) {
      this.dateRangePickerNativeElement = this.dateRangePickerElement.nativeElement;
      this.dateInputs = this.jquery(this.dateRangePickerNativeElement).find('input');
      this.dateRangeInstant = this.jquery(this.dateRangePickerNativeElement).datepicker({
        keyboardNavigation: false,
        format: 'm/d/yyyy',
        minViewMode: 0,
        maxViewMode: 2,
        orientation: 'bottom',
        startDate: range.startDate,
        endDate: range.endDate,
        templates: {
          rightArrow: '<span><i class="fa fa-angle-right f-sm"></i></span>',
          leftArrow: '<span><i class="fa fa-angle-left f-sm"></i></span>'
        }
      });
      this.dateRangeInstant.on('changeDate', () => {
        this.notifyDateChanged(this.readInputs());
      });
    }
  }

  convertToDate(value: string): Date {
    if (!!value) {
      const parts = value.split('/');
      if (parts.length === 3) {
        return new Date(+parts[2], +parts[0] - 1, +parts[1]);
      }
    }
    return null;
  }

  ngOnDestroy(): void {
    if (this.dateRangeInstant !== null) {
      this.dateRangeInstant.off('changeDate');
      this.dateRangeInstant = null;
      this.dateInputs = null;
      this.jquery(this.dateRangePickerElement.nativeElement).datepicker('destroy');
    }
  }

  clearDates() {
    this.jquery(this.dateRangePickerElement.nativeElement).datepicker('clearDates');
  }

  notifyDateChanged(dateList: Date[]) {
    this.dateSelectedEmitter.emit(dateList);
  }

  showCalendar(index: number) {
    if (index >= 0) {
      setTimeout(() => {
        this.onClicked(index);
      }, 200);
    }
  }

  onClicked(index) {
    if (this.dateInputs) {
      this.jquery(this.dateInputs[index]).focus();
    }
  }

  readInputs(): Date[] {
    return [
      this.convertToDate(this.dateInputs[0].value),
      this.convertToDate(this.dateInputs[1].value)
    ];
  }

  onApply() {
    this.applyClickedEmitter.emit(this.readInputs());
  }
}
