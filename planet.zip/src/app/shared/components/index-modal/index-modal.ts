import { Component, Input, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { defaultModalConfig } from '../../constants/defaultModalConfig';
import * as _ from 'lodash';

@Component({
  selector: 'index-modal',
  templateUrl: './index-modal.html'
})
export class IndexModal {
  modalConfig: any;
  @Input() title: string;
  @Input() modalContentClass: string;
  @Input() modalBodyClass: string;
  @ViewChild('indexModal') modal: ModalDirective;

  constructor() {
    this.modalConfig = _.cloneDeep(defaultModalConfig);
  }

  show() {
    this.modal.show();
  }

  hide() {
    this.modal.hide();
  }
}
