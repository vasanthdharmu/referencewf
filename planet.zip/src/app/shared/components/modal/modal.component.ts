import { Component, Input, TemplateRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

@Component({
  selector: 'ppr-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent {
  modalRef: BsModalRef = null;
  config = {
    keyboard: false,
    ignoreBackdropClick: true
  };
  @ViewChild('modalContainer') modalContainerRef: TemplateRef<any>;

  @Input('message') message = {
    header: '',
    body: ''
  };

  @Output() notify: EventEmitter<string> = new EventEmitter<string>();

  constructor(private modalService: BsModalService) { }

  closeModal() {
    this.modalRef.hide();
    this.modalRef = null;
    this.notify.emit('closed');
  }

  openModal() {
    if (!this.modalRef) {
      Promise.resolve(null).then(() => { // Use Promise to avoid the error ExpressionChangedAfterItHasBeenCheckedError.
        this.modalRef = this.modalService.show(this.modalContainerRef, this.config);
      });
    }
  }

  delayClose() {
    if (this.modalRef) {
      setTimeout(() => {
        this.closeModal();
      }, 200);
    }
  }
}
