import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannetContainerComponent } from './plannet-container.component';

describe('PlannetContainerComponent', () => {
  let component: PlannetContainerComponent;
  let fixture: ComponentFixture<PlannetContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlannetContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannetContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
