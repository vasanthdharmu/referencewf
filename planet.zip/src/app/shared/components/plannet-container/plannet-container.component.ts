import { Component, OnInit, Input, ViewChild, TemplateRef } from '@angular/core';
import { IPlanSummary } from '../../interfaces/IPlanSummary';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '@environment';
import { Router } from '@angular/router';
import { ModalComponent } from '../modal/modal.component';
import { RouteHistoryService } from '../../../core/route-history/route-history.service';

@Component({
  selector: 'ppr-plannet-container',
  templateUrl: './plannet-container.component.html',
  styleUrls: ['./plannet-container.component.css']
})
export class PlannetContainerComponent implements OnInit {
  @ViewChild(ModalComponent) modalComponent: ModalComponent;
  partnerLogoUrl: string = null;
  private _planSummary: IPlanSummary = null;
  noData = false;
  fetchingMessage = {
    header: '',
    body: ''
  };
  goBack = false;
  @Input('PlanSummary')
  set PlanSummary(data: IPlanSummary) {
    if (data && data.planId) {
      this._planSummary = data;
      const planId = Number(data.planId);
      if (isNaN(planId) === false) {
        // this.partnerLogoUrl = environment.mockPath + '/assets/default/cms/images/' + planId + '.png'
        this.partnerLogoUrl = environment.mockPath + '/assets/default/cms/images/803333.png'
      }
    }
  }
  get PlanSummary() {
    return this._planSummary;
  }

  @Input() loading = true;

  constructor(private router: Router, private routeHistoryService: RouteHistoryService) { }

  ngOnInit() {
  }
  showNoDataModal() {
    this.noData = true;
    this.fetchingMessage.header = 'No Data';
    this.fetchingMessage.body = `<p class="error-text">There is currently no data available for the plan.</p>`;
    this.modalComponent.openModal();
    this.goBack = true;
  }
  cancelFetching(status) {
    if (status === 'closed') {
      if (this.goBack === true) {
        this.goBack = false;
        this.routeHistoryService.goBack();
      }
    }
  }
  gotoViewAllPlans() {
    this.router.navigate(['/plan-overview'])
  }
}
