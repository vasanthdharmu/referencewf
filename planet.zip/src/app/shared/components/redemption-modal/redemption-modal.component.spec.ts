import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RedemptionModalComponent } from './redemption-modal.component';

describe('RedemptionModalComponent', () => {
  let component: RedemptionModalComponent;
  let fixture: ComponentFixture<RedemptionModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RedemptionModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RedemptionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
