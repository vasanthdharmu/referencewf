import {Component, ElementRef, OnDestroy, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {contentApiNames} from '../../constants/contentApiNames';
import {rpApiNames} from '../../constants/rpApiNames';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import {ApiService} from '../../../core/api/api-service';
import {DatePipe, DecimalPipe} from '@angular/common';
import {ContentService} from '../../../core/content/content-service';
import {NegativeNumberPipe} from '../../pipes/negative-number.pipe';
import {ModalComponent} from '../modal/modal.component';
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'ppr-redemption-modal',
  templateUrl: './redemption-modal.component.html',
  styleUrls: ['./redemption-modal.component.css']
})
export class RedemptionModalComponent implements OnInit, OnDestroy {
  @ViewChild('redemptionFeeModal') redemptionFeesModalElement: ElementRef;
  loading = true;
  modalRef: BsModalRef;
  config = {
    keyboard: true,
    ignoreBackdropClick: false,
    backdrop: false
  };
  redemptionFeeData: any; // see /mock/rp_api_mock/plan/803333/redemption-fees.json

  redemptionFees = {
    title: '',
    content: '',
    feeList: []
  };

  constructor(
    private apiService: ApiService,
    private contentService: ContentService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {}

  ngOnDestroy(): void {
  }

  openRedemptionFeeModal(funds) {
    this.modalRef = this.modalService.show(this.redemptionFeesModalElement, this.config);
    this.redemptionFees.feeList = funds;
    this.retrieveContent();
  }

  retrieveContent() {
    this.contentService.getContent(contentApiNames.PlanNetRedemptionFeeContent)
      .subscribe(
        data => {
          this.redemptionFees.title = data.Summary;
          this.redemptionFees.content = data.Text;
          this.loading = false;
        });
  }
}
