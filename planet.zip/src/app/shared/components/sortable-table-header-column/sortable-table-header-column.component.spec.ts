import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortableTableHeaderColumnComponent } from './sortable-table-header-column.component';

describe('SortableTableHeaderColumnComponent', () => {
  let component: SortableTableHeaderColumnComponent;
  let fixture: ComponentFixture<SortableTableHeaderColumnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortableTableHeaderColumnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortableTableHeaderColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
