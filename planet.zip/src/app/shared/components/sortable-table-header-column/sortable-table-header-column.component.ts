import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ISortableTableHeaderColumn } from '../../interfaces/ISortableTableHeaderColumn';

@Component({
  selector: '[ppr-sortable-table-header-column]',
  templateUrl: './sortable-table-header-column.component.html',
  styleUrls: ['./sortable-table-header-column.component.css']
})
export class SortableTableHeaderColumnComponent implements OnInit {
  private _properties: ISortableTableHeaderColumn[];
  @Input('properties')
  set properties(propertyList: ISortableTableHeaderColumn[]) {
    this._properties = propertyList;
    this._properties.forEach(property => {
      this.splitWords(property);
      if (property.noBorderTop === undefined) {
        property.noBorderTop = false;
      }
      if (property.sortable === undefined) {
        property.sortable = true;
      }
      if (property.sortable === false) {
        property.nonWrapLabel = property.label;
      }
      if (property.class === undefined) {
        property.class = '';
      }
    });
  }
  get properties() {
    return this._properties;
  }
  @Output() notify: EventEmitter<ISortableTableHeaderColumn> = new EventEmitter<ISortableTableHeaderColumn>();

  constructor() { }

  ngOnInit() {
  }

  splitWords(property: ISortableTableHeaderColumn) {
    const index = property.label.lastIndexOf(' ');
    if (index > 0) {
      property.nonWrapLabel = property.label.substring(0, index);
      property.wrapLabel = property.label.substring(index + 1);
    } else {
      property.nonWrapLabel = '';
      property.wrapLabel = property.label;
    }
  }

  sort(property) {
    if (property.sortable === true) {
      let prop;
      this.properties.forEach((item) => {
        if (item.property === property.property) {
          item.isSorted = true;
          item.sortDirection = !item.sortDirection;
          prop = item;
        } else {
          item.isSorted = false;
        }
      });

      this.notify.emit(prop);
    }
  }
}
