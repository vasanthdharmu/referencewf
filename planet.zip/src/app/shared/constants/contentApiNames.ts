export const contentApiNames = {
    PlanNetGlobalContent: 'PlanNetGlobalContent',
    PlanNetOverview: 'PlanNetOverview',
    RpPromoList: 'RpPromoList',
    PlanNetRedemptionFeeContent: 'PlanNetRedemptionFeeContent'
}
