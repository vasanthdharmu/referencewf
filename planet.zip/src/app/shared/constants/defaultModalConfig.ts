export const defaultModalConfig = {
  keyboard: false,
  ignoreBackdropClick: true
};
