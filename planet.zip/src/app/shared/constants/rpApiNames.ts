export const rpApiNames = {
    PlanNetPlanSummary: 'PlanNetPlanSummary',
    PlanNetPlanOverview: 'PlanNetPlanOverview',
    PlanNetPlanPerformanceRor: 'PlanNetPlanPerformanceRor',
    PlanNetPlanPerformanceUnitValue: 'PlanNetPlanPerformanceUnitValue',
    PlanNetPlanPerformanceUnitValueWithDates: 'PlanNetPlanPerformanceUnitValueWithDates',
    PlanNetPlanInvestmentBalance: 'PlanNetPlanInvestmentBalance',
    PlanNetPlanInvestmentBalanceWithDates: 'PlanNetPlanInvestmentBalanceWithDates',
    PlanNetRedemptionFees: 'PlanNetRedemptionFees',
    PlanNetPlanTransactionDeposits: 'PlanNetPlanTransactionDeposits',
    PlanNetPlanTransactionDistribution: 'PlanNetPlanTransactionDistribution',
    PlanNetPlanTransactionLoan: 'PlanNetPlanTransactionLoan'
}
