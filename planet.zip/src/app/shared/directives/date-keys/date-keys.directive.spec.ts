import { DateKeysDirective } from './date-keys.directive';

describe('DateKeysDirective', () => {
  it('should create an instance', () => {
    const directive = new DateKeysDirective();
    expect(directive).toBeTruthy();
  });
});
