export interface ApiRelativePath {
    ApiName: string;
    RelativeUrl: string;
    MockUrl: string;
}
