export interface CachedApiResponse {
    Url: string;
    CachedReponse: any;
}
