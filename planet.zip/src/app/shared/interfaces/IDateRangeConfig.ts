export interface IDateRangeConfig {
  startDate: string,
  endDate: string
}
