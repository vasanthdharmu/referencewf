export interface IPlanSummary {
    planId: string;
    productTypeCd: string;
    planCategory: string;
    legalPlanName: string;
    contractEffectiveDate: string; // yyyy-mm-dd
    informationAsOfDate: string; // yyyy-mm-dd
    validStartDate: Date;
    validEndDate: Date;
}
