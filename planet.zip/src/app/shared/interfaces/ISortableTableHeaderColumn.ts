export interface ISortableTableHeaderColumn {
  property: string,
  label: string,
  borderLeft: boolean,
  borderRight: boolean,
  sortDirection: boolean,
  isSorted: boolean,
  sortReversed: boolean,
  isVisible: boolean,
  nonWrapLabel: string,
  wrapLabel: string,
  noBorderTop: boolean,
  sortable: boolean,
  class: string
}
