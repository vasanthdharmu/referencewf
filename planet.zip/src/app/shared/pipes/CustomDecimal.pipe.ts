import { Pipe, PipeTransform } from '@angular/core';
import { NegativeNumberPipe } from './negative-number.pipe';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'customDecimal'
})

// Format a posotive percentage value to a percentage value with (digits) after decimal point
// Format a negative percentage value to a percentage value enclosed by parentheses
export class CustomDecimalPipe implements PipeTransform {

  transform(value: any, digits: any): any {
    const decimalPipe: DecimalPipe = new DecimalPipe('en-US');
    const negativeNumberPipe: NegativeNumberPipe = new NegativeNumberPipe();

    if (value === null || value === undefined) {
      return 'N/A';
    }
    return negativeNumberPipe.transform(decimalPipe.transform(value, digits));
  }

}
