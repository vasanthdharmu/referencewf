import { Pipe, PipeTransform } from '@angular/core';
import {NegativeNumberPipe} from './negative-number.pipe';
import {CurrencyPipe} from '@angular/common';

@Pipe({
  name: 'dollar'
})

// Format a positive dollar value to a dollar value with (digits) after decimal point
// Format a negative dollar value to a dollar value enclosed by parentheses
export class DollarPipe implements PipeTransform {

  transform(value: any, digits: any): any {
    const currencyPipe: CurrencyPipe = new CurrencyPipe('en-US');
    const negativeNumberPipe: NegativeNumberPipe = new NegativeNumberPipe();

    if (value === null || value === undefined) {
      return 'N/A';
    }

    return negativeNumberPipe.transform(currencyPipe.transform(value, 'USD', 'symbol', digits));
  }

}
