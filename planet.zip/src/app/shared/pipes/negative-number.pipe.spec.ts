import { NegativeNumberPipe } from './negative-number.pipe';

fdescribe('NegativeNumberPipe', () => {
  it('create an instance', () => {
    const pipe = new NegativeNumberPipe();
    expect(pipe).toBeTruthy();
  });
  it ('should format negative number', () => {
    const pipe = new NegativeNumberPipe();
    expect(pipe.transform('-1')).toBe('(1)');
    expect(pipe.transform('1')).toBe('1');
  });
});
