import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {
  MatButtonModule, MatDialogModule, MatInputModule, MatProgressSpinnerModule,
  MatSelectModule, MatSliderModule
} from '@angular/material';
import { BsDropdownModule } from 'ngx-bootstrap';
import { ResponsiveConfig, ResponsiveModule } from 'ng2-responsive';
import { ModalModule } from 'ngx-bootstrap';
import { IndexModal } from './components/index-modal/index-modal';
import { ModalComponent } from './components/modal/modal.component';
import { PlannetContainerComponent } from './components/plannet-container/plannet-container.component';
import { ComponentLibraryModule } from 'sfg-ng-brand-components';
import { DateKeysDirective } from './directives/date-keys/date-keys.directive';
import { NegativeNumberPipe } from './pipes/negative-number.pipe';
import { DollarPipe } from '../shared/pipes/Dollar.pipe';
import { PercentagePipe } from '../shared/pipes/Percentage.pipe';
import { JQUERY_PROVIDER } from '../core/library/jquery.service';
import { DateRangePickerComponent } from './components/date-range-picker/date-range-picker.component';
import { SortableTableHeaderColumnComponent } from './components/sortable-table-header-column/sortable-table-header-column.component';
import { RedemptionModalComponent } from './components/redemption-modal/redemption-modal.component';
import { CustomDecimalPipe } from './pipes/CustomDecimal.pipe';

const config = {
  breakPoints: {
    sm: {max: 420},
    md: {min: 430, max: 768},
    lg: {min: 768}
  },
  debounceTime: 100 // allow to debounce checking timer
};

export function ResponsiveDefinition() {
  return new ResponsiveConfig(<any>config);
}

const MODULES = [
  CommonModule,
  RouterModule,
  FormsModule,
  HttpClientModule,
  ReactiveFormsModule,
  BsDropdownModule,
  MatSelectModule,
  MatInputModule,
  MatButtonModule,
  MatDialogModule,
  MatProgressSpinnerModule,
  MatSliderModule,
  ResponsiveModule
];

export const SHARED_MODULES_WITH_PROVIDERS: any[] = [
  ModalModule.forRoot()
  // ,ComponentLibraryModule.forRoot()
];

const PIPES: any[] = [
  NegativeNumberPipe,
  DollarPipe,
  PercentagePipe,
  CustomDecimalPipe
];

const COMPONENTS: any[] = [
  IndexModal,
  ModalComponent,
  PlannetContainerComponent,
  DateRangePickerComponent,
  SortableTableHeaderColumnComponent,
  RedemptionModalComponent
];

const DIRECTIVES: any[] = [
  DateKeysDirective
];

const PROVIDERS: any[] = [
  {
    provide: ResponsiveConfig,
    useFactory: ResponsiveDefinition },
    JQUERY_PROVIDER
];

@NgModule({
  imports: [
    ...MODULES,
    ...SHARED_MODULES_WITH_PROVIDERS
  ],
  declarations: [
    ...PIPES,
    ...COMPONENTS,
    ...DIRECTIVES
  ],
  providers: [
    ...PROVIDERS
  ],
  exports: [
    ...MODULES,
    ...PIPES,
    ...COMPONENTS,
    ...DIRECTIVES
  ]
})
export class SharedModule {
}
