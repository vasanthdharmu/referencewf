import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StringUtility } from './StringUtility';

describe('StringUtility', () => {
  it('should convert string to Date.', () => {
    const dateString = '2018-01-01'
    const dateObject = StringUtility.convertStringToDate(dateString);
    expect(dateObject).toEqual(new Date(2018, 0, 1));
  });

  it('should convert invalid date string to null.', () => {
    const dateString = 'abc'
    const dateObject = StringUtility.convertStringToDate(dateString);
    expect(dateObject).toBe(null);
  });
});
