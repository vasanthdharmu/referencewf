export class StringUtility {
  static dateStringRegExp = new RegExp('^(\\d{4})-(\\d{1,2})-(\\d{1,2})$');

  static convertStringToDate(value) {
    const match = this.dateStringRegExp.exec(value);
    if (match === null) {
      return null;
    }
    return new Date(+match[1], +match[2] - 1, +match[3]);
  }
}
