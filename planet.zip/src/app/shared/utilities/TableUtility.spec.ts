import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TableUtility } from './TableUtility';
import { DatePipe } from '@angular/common';

describe('TableUtility', () => {
  it('should use sortHandler to compare string values in ascending order.', () => {
    const direction = 1; // ascending order
    const comparator = TableUtility.sortHandler('fundName', direction);
    const aProperty = { };
    aProperty['fundName'] = 'abc';
    const bProperty = { };
    bProperty['fundName'] = 'xyz';
    const result = comparator(aProperty, bProperty);

    expect(result).toBe(aProperty['fundName'].localeCompare(bProperty['fundName']));
  });

  it('should use sortHandler to compare string values in descending order.', () => {
    const direction = -1; // descending order
    const comparator = TableUtility.sortHandler('fundName', direction);
    const aProperty = {
      fundName: 'abc'
    };
    const bProperty = {
      fundName: 'xyz'
    };
    const result = comparator(aProperty, bProperty);

    expect(result).toBe(-1 * aProperty.fundName.localeCompare(bProperty.fundName));
  });

  it('should use sortHandler to compare numbers.', () => {
    const direction = 1; // ascending order
    const comparator = TableUtility.sortHandler('amount', direction);
    const aProperty = {
      amount: 123
    };
    const bProperty = {
      amount: 99
    };
    let result = comparator(aProperty, bProperty);
    let expectedResult = aProperty.amount < bProperty.amount ? -1 : 1;
    expect(result).toBe(expectedResult * direction);

    result = comparator(bProperty, aProperty);
    expectedResult = bProperty.amount < aProperty.amount ? -1 : 1;
    expect(result).toBe(expectedResult * direction);
  });

  it('should use sortHandler to compare null.', () => {
    const direction = 1; // descending order
    const comparator = TableUtility.sortHandler('amount', direction);
    const aProperty = {
      amount: null
    };
    const bProperty = {
      amount: null
    };
    const result = comparator(aProperty, bProperty);
    expect(result).toBe(-1);
  });

  it('should use sortHandler to compare null and 0.', () => {
    const direction = 1; // descending order
    const comparator = TableUtility.sortHandler('amount', direction);
    const aProperty = {
      amount: null
    };
    const bProperty = {
      amount: 0
    };
    let result = comparator(aProperty, bProperty);
    expect(result).toBe(-1 * direction);

    result = comparator(bProperty, aProperty);
    expect(result).toBe(direction);
  });

  it('should use validateDateRange to give an error on null inputs', () => {
    const datePipe: DatePipe = new DatePipe('en-US');
    const startDate = new Date(2018, 0, 1);
    const endDate = new Date(2019, 0, 1);
    let results = TableUtility.validateDateRange(datePipe, null, startDate, endDate);
    expect(results.calendar).toBe(0);
    expect(results.errors.length).toBe(1);
    results = TableUtility.validateDateRange(datePipe, [new Date()], startDate, endDate);
    expect(results.calendar).toBe(1);
    expect(results.errors.length).toBe(1);
    let inputRange = [
      null,
      new Date(2018, 5, 1)
    ];
    results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(0);
    expect(results.errors.length).toBe(1);
    inputRange = [
      new Date(2018, 5, 1),
      null
    ];
    results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(1);
    expect(results.errors.length).toBe(1);
    inputRange = [
      null,
      null
    ];
    results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(0);
    expect(results.errors.length).toBe(2);
  });

  it('should use validateDateRange to give an error on start date after end date', () => {
    const datePipe: DatePipe = new DatePipe('en-US');
    const startDate = new Date(2018, 0, 1);
    const endDate = new Date(2019, 0, 1);
    const inputRange = [
      new Date(2018, 5, 1),
      new Date(2018, 4, 1),
    ];
    const results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(0);
    expect(results.errors.length).toBe(1);
  });

  it('should use validateDateRange to give an error on start date before valid start date and end date after valid end date', () => {
    const datePipe: DatePipe = new DatePipe('en-US');
    const startDate = new Date(2018, 0, 1);
    const endDate = new Date(2019, 0, 1);
    let inputRange = [
      new Date(2017, 5, 1),
      new Date(2019, 4, 1),
    ];
    let results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(0);
    expect(results.errors.length).toBe(2);
    inputRange = [
      new Date(2018, 5, 1),
      new Date(2019, 4, 1),
    ];
    results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(1);
    expect(results.errors.length).toBe(1);
  });

  it('should use validateDateRange to validate input date range', () => {
    const datePipe: DatePipe = new DatePipe('en-US');
    const startDate = new Date(2018, 0, 1);
    const endDate = new Date(2019, 0, 1);
    const inputRange = [
      new Date(2018, 5, 1),
      new Date(2018, 6, 1),
    ];
    let results = TableUtility.validateDateRange(datePipe, inputRange, startDate, endDate);
    expect(results.calendar).toBe(-1);
    expect(results.errors.length).toBe(0);

    results = TableUtility.validateDateRange(datePipe, inputRange, null, endDate);
    expect(results.calendar).toBe(-1);
    expect(results.errors.length).toBe(1);

    results = TableUtility.validateDateRange(datePipe, inputRange, startDate, null);
    expect(results.calendar).toBe(-1);
    expect(results.errors.length).toBe(1);
  });
});
