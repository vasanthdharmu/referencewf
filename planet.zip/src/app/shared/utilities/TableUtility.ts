
 export interface IValidateDateRangeResults {
    calendar: number;
    errors: string[];
  }

export class TableUtility {
  static sortHandler(property: string, direction: number) {
    let locan;
    return (a, b) => {
      if ((!a[property] && a[property] !== 0) || (!b[property] && b[property] !== 0)) {
        if (!a[property] && a[property] !== 0) {
          locan = -1;
        } else {
          locan = 1;
        }
      } else {
        if (typeof(a[property]) === 'number') {
          if (a[property] < b[property]) {
            locan = -1;
          } else {
            locan = 1;
          }
        } else {
          locan = a[property].localeCompare(b[property]);
        }
      }
      return locan * direction;
    }
  }

  static validateDateRange(datePipe: any, inputRange: Date[], validStartDate: Date, validEndDate: Date): IValidateDateRangeResults {
    // tslint:disable-next-line:prefer-const
    let errors = [];
    let calendar = -1;
    if (!inputRange || inputRange.length < 2) {
      // tslint:disable-next-line:max-line-length
      errors.push(`Please select a date range that is on or after ${datePipe.transform(validStartDate, 'M/d/yyyy')} and on or before ${datePipe.transform(validEndDate, 'M/d/yyyy')}.`);
      if (inputRange && inputRange.length === 1) {
        calendar = 1;
      } else {
        calendar = 0;
      }
    } else if (validStartDate && validEndDate) {
      if (inputRange[0] === null) {
        errors.push('Please select a start date.');
        calendar = 0;
      }
      if (inputRange[1] === null) {
        errors.push('Please select an end date.');
        if (calendar === -1) {
          calendar = 1;
        }
      }
      if (inputRange[0] && inputRange[1] && inputRange[0].getTime() > inputRange[1].getTime()) {
        errors.push('The start date has to be on or before the end date.');
        calendar = 0;
      }
      if (inputRange[0] && inputRange[0].getTime() < validStartDate.getTime()) {
        errors.push('The start date has to be on or after ' + datePipe.transform(validStartDate, 'M/d/yyyy') + '.');
        calendar = 0;
      }
      if (inputRange[1] && inputRange[1].getTime() > validEndDate.getTime()) {
        errors.push('The end date has to be on or before ' + datePipe.transform(validEndDate, 'M/d/yyyy') + '.');
        if (calendar === -1) {
          calendar = 1;
        }
      }
    } else {
      calendar = -1;
      errors.push('There is currently no data available for the plan.');
    }
    return {
      errors: errors,
      calendar: calendar
    };
  }
}
