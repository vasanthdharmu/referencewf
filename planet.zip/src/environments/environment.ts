// By convention, do not include the trailing slash
import { buildInfo } from '@deploy/build-info';

export const environment = {
  production: false,
  contentMock: true,
  rpApiMock: true,  // set this to false to get the API data from backend
  contentBaseUrl: '/cms/int', // 'https://cm.standard.com/cms/int' for INT
  mockPath: '', // '/ng/plannet-web',
  // rpApiBaseUrl: 'https://portalint.standard.com',
  rpApiBaseUrl: '/rp-plan-api/v1',
  apiPrefix: '/',
  systemBase: '/',
  images: '/assets/img/',

  buildInfo: buildInfo,
  appCode: 'myhome',
  portalHost: 'https://intportalweb.standard.com',
  drupalEnv: 'int',
  drupalHost: 'https://cm.standard.com',
  wwwHost: 'https://www.standard.com',
  cmHost: 'https://cm.standard.com/admin/content',
  connectionHost: 'https://intconnect.standard.com',

  // Timeout time for authenticated pages -- differs per environment for functional testing purposes
  // 5 minutes locally
  timeoutTimeInSeconds: 300,
  timeoutWarningTimeInSeconds: 120,

  // URLS
  loginPageUrl: 'https://loginint.standard.com',
  portalIframeUrl: 'https://intportalweb.standard.com/w/s/services/amu/amu-admin/',
  collectMissingUrl: 'https://intportalweb.standard.com/w/s/collectmissing',
  logoutUrl: 'https://intportalweb.standard.com/w/p/logout',
  firstLoginUrl: 'https://intportalweb.standard.com/w/s/services/supporting/accountsetup',
  manageProfileUrl: 'https://intportalweb.standard.com/w/s/myprofile',
  myHomeUrl: '/',
  pscAllPlansUrl: 'https://intportalweb.standard.com/w/s/services/psc/viewallplans',
  contactUs: 'https://intportalweb.standard.com/w/s/services/supporting/contactus',
  customerSupportUrl: 'https://www.standard.com/individual/contact-us',
  manageServicesUrl: 'https://intportalweb.standard.com/w/s/myservices/',

  // Endpoint
  themeEndpoint: 'https://cm.standard.com/theme/int/myhome?_format=json',
  webUserContextEndpoint: 'https://intportalweb.standard.com/pna/web-user-context',
  // tslint:disable-next-line:max-line-length
  pscRateOfReturnDetailsUrl: 'https://www3.standard.com/w/s/services/psc/info/related?current=true&urile=wcm%3Apath%3ARetirementPlans/service/secondary_content/related-info/rp_psc_content_rate_of_return',
  pscPanelEndpoint: 'https://intportalweb.standard.com/rp-portal-api/my-home-psc-summary',
  pscSupplementalDataUrl: './assets/default/cm-myhome-panel-psc-dev.json',
  myhomeContentEndpoint: 'https://cm.standard.com/myhome/int',
  myhomeRightNavEndpoint: 'https://cm.standard.com/myhome/int/tasks',
  myhomePageEndpoint: 'https://cm.standard.com/ng-page/int',
  myhomePanelsEndpoint: './assets/default/cm-myhome-panels-dev.json',
  myhomePanelTasksEndpoint: './assets/default/cm-myhome-panel-tasks-dev.json',
  pageEndpoint: 'https://cm.standard.com/ng-page/int',
  pageRightNavEndpoint: 'https://cm.standard.com/ng-page/tasks/int/',
  pageFooterLinksEndpoint: 'https://cm.standard.com/ng-page/footer-links/int',
  themeDefaultEndpoint: 'https://cm.standard.com/theme/int/myhome?_format=json',
  themeFooterLinksEndpoint: 'https://cm.standard.com/theme/footer-links/int/myhome?_format=json',
  ebMemberPortalEndpoint: '../../assets/mock/eb-member-portal-api.mock.json',
  claimsIntakePanelEndpoint: './assets/default/claims-intake-panel.json',
  claimsIntakePanelTasksEndpoint: './assets/default/claims-intake-panel-tasks.json',
  headerMessagesEndpoint: './assets/default/cm-headermessage-default-myhome.json',

  logoImageUrl: '',
  logoImageClickUrl: '',
  myInformationUrl: '',
  changePasswordUrl: '',
  loginActivityUrl: ''
};
